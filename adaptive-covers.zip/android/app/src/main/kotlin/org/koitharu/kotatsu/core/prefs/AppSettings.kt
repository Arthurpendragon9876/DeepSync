package org.koitharu.kotatsu.core.prefs

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import androidx.annotation.FloatRange
import androidx.annotation.IntRange
import androidx.appcompat.app.AppCompatDelegate
import androidx.collection.ArraySet
import androidx.core.content.edit
import androidx.core.os.LocaleListCompat
import androidx.documentfile.provider.DocumentFile
import androidx.preference.PreferenceManager
import dagger.hilt.android.qualifiers.ApplicationContext
import eu.kanade.tachiyomi.util.lang.Hash
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.onStart
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.koitharu.kotatsu.mihon.model.ExternalRepoInfo
import org.koitharu.kotatsu.settings.sources.catalog.ExtensionInstallMode
import org.koitharu.kotatsu.settings.sources.catalog.ExtensionStoreRegistryState
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.ContentWarning
import org.koitharu.kotatsu.core.model.ZoomMode
import org.koitharu.kotatsu.core.network.DoHProvider
import org.koitharu.kotatsu.core.prefs.DetailsUiMode.COMPACT
import org.koitharu.kotatsu.core.util.ext.connectivityManager
import org.koitharu.kotatsu.core.util.ext.getEnumValue
import org.koitharu.kotatsu.home.ui.model.HomeBannerStyle
import org.koitharu.kotatsu.home.ui.model.HomeMetadata
import org.koitharu.kotatsu.home.ui.model.HomeMode
import org.koitharu.kotatsu.home.ui.model.ModeOverrideArea
import org.koitharu.kotatsu.home.ui.model.SuggestionsSource
import org.koitharu.kotatsu.core.util.ext.observeChanges
import org.koitharu.kotatsu.core.util.ext.putAll
import org.koitharu.kotatsu.core.util.ext.putEnumValue
import org.koitharu.kotatsu.core.util.ext.takeIfReadable
import org.koitharu.kotatsu.core.util.ext.toUriOrNull
import org.koitharu.kotatsu.explore.data.SourcesSortOrder
import org.koitharu.kotatsu.favourites.domain.model.CategoriesOrder
import org.koitharu.kotatsu.list.domain.ListSortOrder
import org.koitharu.kotatsu.parsers.model.SortOrder
import org.koitharu.kotatsu.parsers.util.find
import org.koitharu.kotatsu.parsers.util.mapNotNullToSet
import org.koitharu.kotatsu.parsers.util.mapToSet
import org.koitharu.kotatsu.parsers.util.nullIfEmpty
import org.koitharu.kotatsu.reader.domain.ReaderColorFilter
import java.io.File
import java.net.Proxy
import java.util.UUID
import java.util.EnumSet
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppSettings @Inject constructor(@ApplicationContext context: Context) {

	private val prefs = PreferenceManager.getDefaultSharedPreferences(context)
	private val json = Json { ignoreUnknownKeys = true }
	private val onboardingInstallIdFile = File(context.noBackupFilesDir, "onboarding_install_id")
	private val connectivityManager = context.connectivityManager
	private val mangaListBadgesDefault = ArraySet(context.resources.getStringArray(R.array.values_list_badges_default))

	init {
		if (!prefs.getBoolean(KEY_PRELOAD_POLICIES_RESET, false)) {
			prefs.edit {
				putString(KEY_PREFETCH_CONTENT, "1")
				putBoolean(KEY_PRELOAD_POLICIES_RESET, true)
			}
		}
		// One-time: turn "Pin navigation UI" on for everyone updating; user can turn it off afterwards.
		if (!prefs.getBoolean(KEY_NAV_PINNED_RESET, false)) {
			prefs.edit {
				putBoolean(KEY_NAV_PINNED, true)
				putBoolean(KEY_NAV_PINNED_RESET, true)
			}
		}
	}
	private val onboardingInstallId by lazy {
		runCatching {
			onboardingInstallIdFile.parentFile?.mkdirs()
			if (onboardingInstallIdFile.exists()) {
				onboardingInstallIdFile.readText().trim().ifBlank { throw IllegalStateException() }
			} else {
				val value = UUID.randomUUID().toString()
				onboardingInstallIdFile.writeText(value)
				value
			}
		}.getOrElse {
			UUID.randomUUID().toString()
		}
	}

	var listMode: ListMode
		get() = prefs.getEnumValue(KEY_LIST_MODE, ListMode.GRID)
		set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE, value) }

	val theme: Int
		get() = prefs.getString(KEY_THEME, null)?.toIntOrNull()
			?: AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM

	fun setTheme(mode: Int) = prefs.edit {
		putString(KEY_THEME, mode.toString())
	}

	val colorScheme: ColorScheme
		get() = prefs.getEnumValue(KEY_COLOR_THEME, ColorScheme.default)

	fun setColorScheme(value: ColorScheme) = prefs.edit {
		putEnumValue(KEY_COLOR_THEME, value)
	}

	val isAmoledTheme: Boolean
		get() = prefs.getBoolean(KEY_THEME_AMOLED, false)

	fun setAmoledTheme(enabled: Boolean) = prefs.edit {
		putBoolean(KEY_THEME_AMOLED, enabled)
	}

	val isStatusBarHidden: Boolean
		get() = prefs.getBoolean(KEY_HIDE_STATUS_BAR, false)

	var isOnboardingCompleted: Boolean
		get() = prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)
			&& prefs.getString(KEY_ONBOARDING_INSTALL_ID, null) == onboardingInstallId
		set(value) = prefs.edit {
			putBoolean(KEY_ONBOARDING_COMPLETED, value)
			if (value) {
				putString(KEY_ONBOARDING_INSTALL_ID, onboardingInstallId)
			} else {
				remove(KEY_ONBOARDING_INSTALL_ID)
			}
		}

	var mainNavItems: List<NavItem>
		get() {
			val raw = prefs.getString(KEY_NAV_MAIN, null)?.split(',')
			val items = if (raw.isNullOrEmpty()) {
				listOf(NavItem.HOME, NavItem.FAVORITES, NavItem.HISTORY, NavItem.EXPLORE)
			} else {
				raw.mapNotNull { x -> NavItem.entries.find(x) }.ifEmpty { listOf(NavItem.EXPLORE) }
			}
			return items.take(4)
		}
		set(value) {
			prefs.edit {
				putString(KEY_NAV_MAIN, value.joinToString(",") { it.name })
			}
		}

	val isNavLabelsVisible: Boolean
		get() = prefs.getBoolean(KEY_NAV_LABELS, true)

	val isNavBarPinned: Boolean
		get() = prefs.getBoolean(KEY_NAV_PINNED, true)

	val isBarBlurEnabled: Boolean
		get() = prefs.getBoolean(KEY_BAR_BLUR, true)

	val isLegacyNavigationBar: Boolean
		get() = prefs.getBoolean(KEY_NAV_LEGACY, false)

	val isMainFabEnabled: Boolean
		get() = prefs.getBoolean(KEY_MAIN_FAB, true)

	/**
	 * Version name of the app update whose home screen prompt was dismissed. Stored rather than a
	 * plain flag so a newer release brings the prompt back on its own.
	 */
	var dismissedUpdateVersion: String?
		get() = prefs.getString(KEY_UPDATE_PROMPT_DISMISSED, null)
		set(value) = prefs.edit { putString(KEY_UPDATE_PROMPT_DISMISSED, value) }

	var gridSize: Int
		get() = prefs.getInt(KEY_GRID_SIZE, 100)
		set(value) = prefs.edit { putInt(KEY_GRID_SIZE, value) }

	// Global UI scale as a percent (85 = smaller, 100 = default, 115 = larger). Applied by overriding
	// densityDpi in BaseActivity.attachBaseContext, so it scales everything. It sits on top of the
	// automatic per-screen baseline there, so 100 means "the reference look" on every device.
	var uiScalePercent: Int
		get() = prefs.getInt(KEY_UI_SCALE, 100)
		set(value) = prefs.edit { putInt(KEY_UI_SCALE, value) }

	var isTitleOverCover: Boolean
		get() = prefs.getBoolean(KEY_TITLE_OVER_COVER, true)
		set(value) = prefs.edit { putBoolean(KEY_TITLE_OVER_COVER, value) }

	/** Web pages (chapter, title) open in the phone's browser instead of the built-in WebView. */
	val isOpenInExternalBrowser: Boolean
		get() = prefs.getBoolean(KEY_OPEN_EXTERNAL_BROWSER, false)

	var isTitleTapToReadEnabled: Boolean
		get() = prefs.getBoolean(KEY_TITLE_TAP_TO_READ, false)
		set(value) = prefs.edit { putBoolean(KEY_TITLE_TAP_TO_READ, value) }

	var isListCheckpointEnabled: Boolean
		get() = prefs.getBoolean(KEY_LIST_CHECKPOINT, true)
		set(value) = prefs.edit { putBoolean(KEY_LIST_CHECKPOINT, value) }

	/** Opaque record of where the user was in the list identified by [scope]. */
	fun getListCheckpoint(scope: String): String? {
		val key = KEY_LIST_CHECKPOINT + '_' + scope
		return try {
			prefs.getString(key, null)
		} catch (e: ClassCastException) {
			// An earlier build stored a bare manga id under this key - drop it and start over.
			prefs.edit { remove(key) }
			null
		}
	}

	fun setListCheckpoint(scope: String, value: String) {
		prefs.edit { putString(KEY_LIST_CHECKPOINT + '_' + scope, value) }
	}

	var isDuplicateCheckEnabled: Boolean
		get() = prefs.getBoolean(KEY_CHECK_DUPLICATES, true)
		set(value) = prefs.edit { putBoolean(KEY_CHECK_DUPLICATES, value) }

	/** Whether replacing a duplicate carries reading progress, bookmarks and trackers over. */
	var isDuplicateProgressMigrated: Boolean
		get() = prefs.getBoolean(KEY_MIGRATE_DUPLICATE_PROGRESS, true)
		set(value) = prefs.edit { putBoolean(KEY_MIGRATE_DUPLICATE_PROGRESS, value) }

	var isGridSpacingIncreased: Boolean
		get() = prefs.getBoolean(KEY_GRID_SPACING_INCREASED, false)
		set(value) = prefs.edit { putBoolean(KEY_GRID_SPACING_INCREASED, value) }

	var gridSizePages: Int
		get() = prefs.getInt(KEY_GRID_SIZE_PAGES, 100)
		set(value) = prefs.edit { putInt(KEY_GRID_SIZE_PAGES, value) }

	val isQuickFilterEnabled: Boolean
		get() = prefs.getBoolean(KEY_QUICK_FILTER, true)

	val isBackdropEnabled: Boolean
		get() = prefs.getBoolean(KEY_DETAILS_BACKDROP, true)

	var backdropBlurAmount: Int
		get() {
			val raw = prefs.getInt(KEY_DETAILS_BACKDROP_BLUR_AMOUNT, 2)
			return when {
				raw <= 0 -> 0
				raw == 1 -> 1
				else -> 2
			}
		}
		set(value) = prefs.edit { putInt(KEY_DETAILS_BACKDROP_BLUR_AMOUNT, value) }

	var historyListMode: ListMode
		get() = prefs.getEnumValue(KEY_LIST_MODE_HISTORY, listMode)
		set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE_HISTORY, value) }

	var suggestionsListMode: ListMode
		get() = prefs.getEnumValue(KEY_LIST_MODE_SUGGESTIONS, listMode)
		set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE_SUGGESTIONS, value) }

	var favoritesListMode: ListMode
		get() = prefs.getEnumValue(KEY_LIST_MODE_FAVORITES, listMode)
		set(value) = prefs.edit { putEnumValue(KEY_LIST_MODE_FAVORITES, value) }

	/**
	 * The most adult [ContentWarning] whose extensions are shown: all of them, up to Mixed, or SFW only.
	 * Falls back to the old single "Disable NSFW" switch, which meant SFW only.
	 */
	var contentFilter: ContentWarning
		get() = prefs.getString(KEY_CONTENT_FILTER, null)?.let { x -> ContentWarning.entries.find { it.name == x } }
			?: if (prefs.getBoolean(KEY_DISABLE_NSFW_LEGACY, false)) ContentWarning.SAFE else ContentWarning.NSFW
		set(value) = prefs.edit {
			putString(KEY_CONTENT_FILTER, value.name)
			remove(KEY_DISABLE_NSFW_LEGACY)
		}

	/** Adult manga are hidden wherever 18+ extensions are. */
	val isNsfwContentDisabled: Boolean
		get() = contentFilter < ContentWarning.NSFW

	var appLocales: LocaleListCompat
		get() {
			val raw = prefs.getString(KEY_APP_LOCALE, null)
			return LocaleListCompat.forLanguageTags(raw)
		}
		set(value) {
			prefs.edit {
				putString(KEY_APP_LOCALE, value.toLanguageTags())
			}
		}

	var isReaderDoubleOnLandscape: Boolean
		get() = prefs.getBoolean(KEY_READER_DOUBLE_PAGES, false)
		set(value) = prefs.edit { putBoolean(KEY_READER_DOUBLE_PAGES, value) }

	var isReaderDoubleOnFoldable: Boolean
		get() = prefs.getBoolean(KEY_READER_DOUBLE_FOLDABLE, false)
		set(value) = prefs.edit { putBoolean(KEY_READER_DOUBLE_FOLDABLE, value) }

	@get:FloatRange(0.0, 1.0)
	var readerDoublePagesSensitivity: Float
		get() = prefs.getFloat(KEY_READER_DOUBLE_PAGES_SENSITIVITY, 0.5f)
		set(@FloatRange(0.0, 1.0) value) = prefs.edit { putFloat(KEY_READER_DOUBLE_PAGES_SENSITIVITY, value) }

	val readerScreenOrientation: Int
		get() = prefs.getString(KEY_READER_ORIENTATION, null)?.toIntOrNull()
			?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

	val isReaderVolumeButtonsEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_VOLUME_BUTTONS, false)

	var epubFontSize: Int
		get() = prefs.getInt(KEY_EPUB_FONT_SIZE, 100)
		set(value) = prefs.edit { putInt(KEY_EPUB_FONT_SIZE, value.coerceIn(50, 200)) }

	var epubFontFamily: String
		get() = prefs.getString(KEY_EPUB_FONT_FAMILY, "serif") ?: "serif"
		set(value) = prefs.edit { putString(KEY_EPUB_FONT_FAMILY, value) }

	var epubLineHeight: Int
		get() = prefs.getInt(KEY_EPUB_LINE_HEIGHT, 160)
		set(value) = prefs.edit { putInt(KEY_EPUB_LINE_HEIGHT, value.coerceIn(100, 240)) }

	var epubParagraphSpacing: Int
		get() = prefs.getInt(KEY_EPUB_PARAGRAPH_SPACING, 0)
		set(value) = prefs.edit { putInt(KEY_EPUB_PARAGRAPH_SPACING, value.coerceIn(-32, 48)) }

	var epubHorizontalPadding: Int
		get() = prefs.getInt(KEY_EPUB_HORIZONTAL_PADDING, 20)
		set(value) = prefs.edit { putInt(KEY_EPUB_HORIZONTAL_PADDING, value.coerceIn(0, 64)) }

	var epubVerticalPadding: Int
		get() = prefs.getInt(KEY_EPUB_VERTICAL_PADDING, 112).coerceIn(0, 112)
		set(value) = prefs.edit { putInt(KEY_EPUB_VERTICAL_PADDING, value.coerceIn(0, 112)) }

	var epubTextAlign: String
		get() = prefs.getString(KEY_EPUB_TEXT_ALIGN, "justify") ?: "justify"
		set(value) = prefs.edit { putString(KEY_EPUB_TEXT_ALIGN, value) }

	/**
	 * Novel page turning: "scroll" or "paged". Reading direction is a separate axis
	 * ([isEpubRtl]) so RTL works in scroll mode too.
	 */
	var epubReadingMode: String
		get() = if (rawEpubReadingMode.startsWith("paged")) "paged" else "scroll"
		set(value) = prefs.edit { putString(KEY_EPUB_READING_MODE, value) }

	/**
	 * Right-to-left reading. Defaults from the legacy combined "paged_rtl" value, so books already
	 * set to RTL paged stay RTL without a migration pass.
	 */
	var isEpubRtl: Boolean
		get() = prefs.getBoolean(KEY_EPUB_RTL, rawEpubReadingMode == "paged_rtl")
		set(value) = prefs.edit { putBoolean(KEY_EPUB_RTL, value) }

	/**
	 * How scroll mode moves between chapters: "continuous" (one endless scroll, a transition card between
	 * chapters) or "overscroll" (one chapter at a time, pull past its end for the next one).
	 */
	var epubScrollStyle: String
		get() = if (prefs.getString(KEY_EPUB_SCROLL_STYLE, "continuous") == "overscroll") "overscroll" else "continuous"
		set(value) = prefs.edit { putString(KEY_EPUB_SCROLL_STYLE, value) }

	/** Absolute path of the reader's custom background picture (a copy kept in app storage), empty = none. */
	var epubBackgroundImage: String
		get() = prefs.getString(KEY_EPUB_BACKGROUND_IMAGE, "").orEmpty()
		set(value) = prefs.edit { putString(KEY_EPUB_BACKGROUND_IMAGE, value) }

	/** Blur of the custom background picture, 0 (sharp)..25. Only used while a picture is set. */
	var epubBackgroundBlur: Int
		get() = prefs.getInt(KEY_EPUB_BACKGROUND_BLUR, 0).coerceIn(0, 25)
		set(value) = prefs.edit { putInt(KEY_EPUB_BACKGROUND_BLUR, value.coerceIn(0, 25)) }

	/** Saved reader presets made by the user, a JSON array (see NovelPresetStore). */
	var epubCustomPresets: String
		get() = prefs.getString(KEY_EPUB_CUSTOM_PRESETS, "[]").orEmpty()
		set(value) = prefs.edit { putString(KEY_EPUB_CUSTOM_PRESETS, value) }

	private val rawEpubReadingMode: String
		get() = prefs.getString(KEY_EPUB_READING_MODE, "scroll") ?: "scroll"

	/** Speech rate for the novel text-to-speech, 0.25f..3f where 1f is the engine default. */
	/** Exact engine voice name picked in the TTS settings; null = automatic best voice. */
	var epubTtsVoiceName: String?
		get() = prefs.getString(KEY_EPUB_TTS_VOICE_NAME, null)
		set(value) = prefs.edit { if (value == null) remove(KEY_EPUB_TTS_VOICE_NAME) else putString(KEY_EPUB_TTS_VOICE_NAME, value) }

	/** Shows the floating Listen button in the novel reader; off until the user turns it on in the reader settings. */
	var isEpubTtsEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_TTS_ENABLED, false)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_TTS_ENABLED, value) }

	/** Keep the spoken sentence on screen while listening. */
	var isEpubTtsFollowEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_TTS_FOLLOW, true)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_TTS_FOLLOW, value) }

	/** Continue with the next chapter when the current one has been read out. */
	var isEpubTtsAutoAdvance: Boolean
		get() = prefs.getBoolean(KEY_EPUB_TTS_AUTO_ADVANCE, true)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_TTS_AUTO_ADVANCE, value) }

	var epubTtsSpeed: Float
		get() = prefs.getFloat(KEY_EPUB_TTS_SPEED, 1f).coerceIn(0.25f, 3f)
		set(value) = prefs.edit { putFloat(KEY_EPUB_TTS_SPEED, value) }

	/** Pitch for the novel text-to-speech, 0.5f..2f where 1f is the engine default. */
	var epubTtsPitch: Float
		get() = prefs.getFloat(KEY_EPUB_TTS_PITCH, 1f).coerceIn(0.5f, 2f)
		set(value) = prefs.edit { putFloat(KEY_EPUB_TTS_PITCH, value) }

	/**
	 * Which of the offered voices is selected, as an index rather than a name: the offer is the best
	 * few voices of whatever language is being read, so the same slot keeps working in every book.
	 */
	/** Voice names the user linked to each voice slot of [language] (comma-separated, empty = automatic). */
	fun getTtsSlotVoices(language: String): List<String> =
		prefs.getString(KEY_EPUB_TTS_SLOT_VOICES + language, null)?.split(',').orEmpty()

	fun setTtsSlotVoice(language: String, slot: Int, voiceName: String?) {
		val names = getTtsSlotVoices(language).toMutableList()
		while (names.size <= slot) names += ""
		names[slot] = voiceName.orEmpty()
		prefs.edit { putString(KEY_EPUB_TTS_SLOT_VOICES + language, names.joinToString(",")) }
	}

	var epubTtsVoiceIndex: Int
		get() = prefs.getInt(KEY_EPUB_TTS_VOICE, 0)
		set(value) = prefs.edit { putInt(KEY_EPUB_TTS_VOICE, value) }

	var isEpubPagedTapGesturesEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_PAGED_TAP_GESTURES, false)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_PAGED_TAP_GESTURES, value) }

	var isEpubPublisherStyleEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_PUBLISHER_STYLE, false)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_PUBLISHER_STYLE, value) }

	/** Explore puts the novel sources on the left (and opens there) instead of manga. */
	var isNovelTabFirst: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_NOVEL_TAB_FIRST), false)
		set(value) = prefs.edit { putBoolean(areaWriteKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_NOVEL_TAB_FIRST), value) }

	var isEpubBionicReadingEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_BIONIC_READING, false)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_BIONIC_READING, value) }

	// "system" | "white" | "gray" | "black" | "custom" - page colors of the EPUB reader only
	var epubTheme: String
		get() = prefs.getString(KEY_EPUB_THEME, "system") ?: "system"
		set(value) = prefs.edit { putString(KEY_EPUB_THEME, value) }

	var epubCustomBackgroundColor: Int
		get() = prefs.getInt(KEY_EPUB_CUSTOM_BACKGROUND_COLOR, 0xFFFFFFFF.toInt())
		set(value) = prefs.edit { putInt(KEY_EPUB_CUSTOM_BACKGROUND_COLOR, value) }

	var epubCustomTextColor: Int
		get() = prefs.getInt(KEY_EPUB_CUSTOM_TEXT_COLOR, 0xFF1B1B1F.toInt())
		set(value) = prefs.edit { putInt(KEY_EPUB_CUSTOM_TEXT_COLOR, value) }

	var epubCustomHighlightColor: Int
		get() = prefs.getInt(KEY_EPUB_CUSTOM_HIGHLIGHT_COLOR, 0xFFFFD54F.toInt())
		set(value) = prefs.edit { putInt(KEY_EPUB_CUSTOM_HIGHLIGHT_COLOR, value) }

	var epubCustomFontName: String
		get() = prefs.getString(KEY_EPUB_CUSTOM_FONT_NAME, "").orEmpty()
		set(value) = prefs.edit { putString(KEY_EPUB_CUSTOM_FONT_NAME, value) }

	var epubCustomFontRevision: Int
		get() = prefs.getInt(KEY_EPUB_CUSTOM_FONT_REVISION, 0)
		set(value) = prefs.edit { putInt(KEY_EPUB_CUSTOM_FONT_REVISION, value) }

	/** Extra tracking in hundredths of an em (-5..15). */
	var epubLetterSpacing: Int
		get() = prefs.getInt(KEY_EPUB_LETTER_SPACING, 0).coerceIn(-5, 15)
		set(value) = prefs.edit { putInt(KEY_EPUB_LETTER_SPACING, value.coerceIn(-5, 15)) }

	/** First-line paragraph indent in half-em steps (0..8, so 0..4 em). */
	var epubParagraphIndent: Int
		get() = prefs.getInt(KEY_EPUB_PARAGRAPH_INDENT, 0).coerceIn(0, 8)
		set(value) = prefs.edit { putInt(KEY_EPUB_PARAGRAPH_INDENT, value.coerceIn(0, 8)) }

	/** Novery-style "Chapter N / title / N of total" block above each chapter in scroll mode. */
	var isEpubChapterHeaderEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_CHAPTER_HEADER, true)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_CHAPTER_HEADER, value) }

	/** Header title shows just the chapter's name ("Chapter 12: Name" -> "Name"); off shows the title as the book gives it. */
	var isEpubHeaderNameOnly: Boolean
		get() = prefs.getBoolean(KEY_EPUB_HEADER_NAME_ONLY, true)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_HEADER_NAME_ONLY, value) }

	/**
	 * Drops the chapter's own title line from the top of the text when the header already shows it:
	 * "off", "number", "name" or "both" (see ChapterTitles.Redundancy).
	 */
	var epubRemoveRedundancy: String
		get() = prefs.getString(KEY_EPUB_REMOVE_REDUNDANCY, "off")
			?.takeIf { it == "number" || it == "name" || it == "both" } ?: "off"
		set(value) = prefs.edit { putString(KEY_EPUB_REMOVE_REDUNDANCY, value) }

	var isEpubHyphenationEnabled: Boolean
		get() = prefs.getBoolean(KEY_EPUB_HYPHENATION, false)
		set(value) = prefs.edit { putBoolean(KEY_EPUB_HYPHENATION, value) }

	/** Maximum width of the text column in dp, 0 = use the full screen width (tablets/landscape). */
	var epubMaxTextWidth: Int
		get() = prefs.getInt(KEY_EPUB_MAX_TEXT_WIDTH, 0).let { if (it == 0) 0 else it.coerceIn(320, 900) }
		set(value) = prefs.edit { putInt(KEY_EPUB_MAX_TEXT_WIDTH, if (value <= 0) 0 else value.coerceIn(320, 900)) }

	val isReaderRotateWideEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_ROTATE_WIDE, false)

	val isReaderRotateWideInverted: Boolean
		get() = prefs.getBoolean(KEY_READER_ROTATE_WIDE_INVERT, false)

	val isReaderZoomButtonsEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_ZOOM_BUTTONS, false)

	val isReaderControlAlwaysLTR: Boolean
		get() = prefs.getBoolean(KEY_READER_CONTROL_LTR, false)

	val isReaderNavigationInverted: Boolean
		get() = prefs.getBoolean(KEY_READER_NAVIGATION_INVERTED, false)

	val isReaderFullscreenEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_FULLSCREEN, true)

	val isReaderOptimizationEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_OPTIMIZE, false)

	val isReaderUpscaleEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_UPSCALE, false)

	var isChapterJumpDialogEnabled: Boolean
		get() = prefs.getBoolean(KEY_CHAPTER_JUMP_DIALOG, true)
		set(value) = prefs.edit { putBoolean(KEY_CHAPTER_JUMP_DIALOG, value) }

	/**
	 * The reader bars' layout: every control in the user's order, with the slot it sits in (left or
	 * right side of the top or bottom bar) and whether it is shown. Hidden controls keep their place
	 * so re-enabling one puts it back where it was.
	 * Serialized as a comma-separated list of `NAME@SLOT`, hidden ones prefixed with '-'.
	 * Builds that only had a bottom bar stored a plain ordered list of names under
	 * [KEY_READER_CONTROLS] (and before that an unordered set under [KEY_READER_CONTROLS_LEGACY]);
	 * they are read until the layout is first saved, so an update keeps a customised bar.
	 */
	var readerBarLayout: ReaderBarLayout
		get() {
			val stored = prefs.getString(KEY_READER_BAR_LAYOUT, null)
			if (stored != null) {
				return ReaderBars.parse(stored, { name -> ReaderControl.entries.find(name) }, { name -> ReaderBarSlot.entries.find(name) })
			}
			// Nothing stored under either older format: a fresh install.
			val old = singleListReaderControls() ?: return ReaderBars.DEFAULT
			return ReaderBars.fromSingleList(old)
		}
		set(value) = prefs.edit {
			putString(KEY_READER_BAR_LAYOUT, ReaderBars.serialize(value))
		}

	/**
	 * The novel reader's bars, customised from "Customise novel reader bars". Stored like
	 * [readerBarLayout] (`NAME@SLOT`, hidden ones prefixed with '-'), under its own key so manga and
	 * novels can look different.
	 */
	var novelBarLayout: NovelBarLayout
		get() {
			val stored = prefs.getString(KEY_NOVEL_BAR_LAYOUT, null) ?: return NovelBars.DEFAULT
			return NovelBars.parse(stored, { name -> NovelControl.entries.find(name) }, { name -> ReaderBarSlot.entries.find(name) })
		}
		set(value) = prefs.edit {
			putString(KEY_NOVEL_BAR_LAYOUT, NovelBars.serialize(value))
		}

	/** The previous, bottom-bar-only format: controls in order, hidden ones prefixed with '-'. */
	private fun singleListReaderControls(): List<Pair<ReaderControl, Boolean>>? {
		val stored = prefs.getString(KEY_READER_CONTROLS, null)
			?.split(',')
			?.mapNotNull { token ->
				val name = token.trim()
				val control = ReaderControl.entries.find(name.removePrefix("-")) ?: return@mapNotNull null
				control to !name.startsWith('-')
			}
			?.distinctBy { it.first }
			.orEmpty()
		return stored.ifEmpty { legacyReaderControlsLayout() }
	}

	// Pre-ordering builds stored an unordered string set under a different key; read it once so an
	// update does not silently reset a customised bar.
	private fun legacyReaderControlsLayout(): List<Pair<ReaderControl, Boolean>>? {
		val legacy = runCatching {
			prefs.getStringSet(KEY_READER_CONTROLS_LEGACY, null)
		}.getOrNull() ?: return null
		return ReaderControl.entries.filter { it.name in legacy }.map { it to true }
	}

	val isOfflineCheckDisabled: Boolean
		get() = prefs.getBoolean(KEY_OFFLINE_DISABLED, false)

	var isAllFavouritesVisible: Boolean
		get() = prefs.getBoolean(KEY_ALL_FAVOURITES_VISIBLE, true)
		set(value) = prefs.edit { putBoolean(KEY_ALL_FAVOURITES_VISIBLE, value) }

	/** When true, favourite categories stay visible in every mode (Manga/Anime/Novel) even if empty there. */
	var isShowEmptyModeCategories: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.FAVOURITES, KEY_SHOW_EMPTY_MODE_CATEGORIES), false)
		set(value) = prefs.edit { putBoolean(areaWriteKey(ModeOverrideArea.FAVOURITES, KEY_SHOW_EMPTY_MODE_CATEGORIES), value) }

	val isTrackerEnabled: Boolean
		get() = prefs.getBoolean(KEY_TRACKER_ENABLED, true)

	val isTrackerWifiOnly: Boolean
		get() = prefs.getBoolean(KEY_TRACKER_WIFI_ONLY, false)

	val trackerFrequencyFactor: Float
		get() = prefs.getString(KEY_TRACKER_FREQUENCY, null)?.toFloatOrNull() ?: 1f

	val isTrackerNsfwDisabled: Boolean
		get() = prefs.getBoolean(KEY_TRACKER_NO_NSFW, false)

	/** Off by default: the "couldn't check these" notification is noise for most users. */
	val isTrackerFailureNotificationEnabled: Boolean
		get() = prefs.getBoolean(KEY_TRACKER_FAILURE_NOTIFICATION, false)

	/** Entries the tracker should not spend a network request on, see [SMART_UPDATE_SKIP_COMPLETED] etc. */
	val trackerSmartUpdateRules: Set<String>
		get() = prefs.getStringSet(KEY_TRACKER_SMART_UPDATE, null).orEmpty()

	val isFeedSwipeGesturesEnabled: Boolean
		get() = prefs.getBoolean(KEY_FEED_SWIPE_GESTURES, true)

	var isFeedUnreadOnly: Boolean
		get() = prefs.getBoolean(KEY_FEED_UNREAD_ONLY, false)
		set(value) = prefs.edit { putBoolean(KEY_FEED_UNREAD_ONLY, value) }

	/** Mark the Feed tab with a plain dot instead of the exact number of unread updates. */
	val isFeedCounterAsDot: Boolean
		get() = prefs.getBoolean(KEY_FEED_COUNTER_DOT, false)

	val trackerDownloadStrategy: TrackerDownloadStrategy
		get() = prefs.getEnumValue(KEY_TRACKER_DOWNLOAD, TrackerDownloadStrategy.DISABLED)

	fun consumeLegacyTrackerDownloadStrategy(): Boolean {
		val strategy = trackerDownloadStrategy
		if (strategy != TrackerDownloadStrategy.DISABLED) {
			prefs.edit { remove(KEY_TRACKER_DOWNLOAD) }
		}
		return strategy == TrackerDownloadStrategy.DOWNLOADED
	}

	val readerAnimation: ReaderAnimation
		get() = prefs.getEnumValue(KEY_READER_ANIMATION, ReaderAnimation.DEFAULT)

	val readerBackground: ReaderBackground
		get() = prefs.getEnumValue(KEY_READER_BACKGROUND, ReaderBackground.DEFAULT)

	val defaultReaderMode: ReaderMode
		get() = prefs.getEnumValue(KEY_READER_MODE, ReaderMode.STANDARD)

	val isReaderModeDetectionEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_MODE_DETECT, true)

	var isHistoryGroupingEnabled: Boolean
		get() = prefs.getBoolean(KEY_HISTORY_GROUPING, true)
		set(value) = prefs.edit { putBoolean(KEY_HISTORY_GROUPING, value) }

	var isUpdatedGroupingEnabled: Boolean
		get() = prefs.getBoolean(KEY_UPDATED_GROUPING, true)
		set(value) = prefs.edit { putBoolean(KEY_UPDATED_GROUPING, value) }

	// A single on/off toggle now: on = show the read-percentage pill, off = no indicator.
	var progressIndicatorMode: ProgressIndicatorMode
		get() {
			val value = try {
				prefs.getString(KEY_PROGRESS_INDICATORS, null)
			} catch (e: ClassCastException) {
				null
			}
			if (value == null) {
				val legacyEnabled = try {
					prefs.getBoolean(KEY_PROGRESS_INDICATORS, true)
				} catch (e: ClassCastException) {
					true
				}
				return if (legacyEnabled) ProgressIndicatorMode.PERCENT_READ else ProgressIndicatorMode.NONE
			}
			return prefs.getEnumValue(KEY_PROGRESS_INDICATORS, ProgressIndicatorMode.PERCENT_READ)
		}
		set(value) = prefs.edit { putEnumValue(KEY_PROGRESS_INDICATORS, value) }

	var detailsUiMode: DetailsUiMode
		get() = prefs.getEnumValue(KEY_DETAILS_UI, COMPACT)
		set(value) = prefs.edit { putEnumValue(KEY_DETAILS_UI, value) }

	var incognitoModeForNsfw: TriStateOption
		get() = prefs.getEnumValue(KEY_INCOGNITO_NSFW, TriStateOption.ASK)
		set(value) = prefs.edit { putEnumValue(KEY_INCOGNITO_NSFW, value) }

	var isIncognitoModeEnabled: Boolean
		get() = prefs.getBoolean(KEY_INCOGNITO_MODE, false)
		set(value) = prefs.edit { putBoolean(KEY_INCOGNITO_MODE, value) }

	val isReaderMultiTaskEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_MULTITASK, false)

	var isChaptersReverse: Boolean
		get() = prefs.getBoolean(KEY_REVERSE_CHAPTERS, false)
		set(value) = prefs.edit { putBoolean(KEY_REVERSE_CHAPTERS, value) }

	// --- Advanced novel settings (novel downloads + translation) ---
	var isNovelThrottleEnabled: Boolean
		get() = prefs.getBoolean(KEY_NOVEL_THROTTLE, true)
		set(value) = prefs.edit { putBoolean(KEY_NOVEL_THROTTLE, value) }

	/** Requests to one novel source that may go through back to back before the delay is enforced. */
	var novelRequestsBeforeDelay: Int
		get() = prefs.getInt(KEY_NOVEL_BURST, 5).coerceIn(1, 20)
		set(value) = prefs.edit { putInt(KEY_NOVEL_BURST, value) }

	/** Delay between novel requests once the burst is used up, in milliseconds. */
	var novelRequestDelayMs: Int
		get() = prefs.getInt(KEY_NOVEL_DELAY, 1000).coerceIn(0, 10_000)
		set(value) = prefs.edit { putInt(KEY_NOVEL_DELAY, value) }

	var novelParallelUpdates: Int
		get() = prefs.getInt(KEY_NOVEL_PARALLEL_UPDATES, 5).coerceIn(1, 15)
		set(value) = prefs.edit { putInt(KEY_NOVEL_PARALLEL_UPDATES, value) }

	var novelConcurrentMassImports: Int
		get() = prefs.getInt(KEY_NOVEL_MASS_IMPORTS, 5).coerceIn(1, 30)
		set(value) = prefs.edit { putInt(KEY_NOVEL_MASS_IMPORTS, value) }

	/** Skip the rest of a source's urls after this many consecutive detail-fetch failures; 0 disables. */
	var novelSkipAfterErrors: Int
		get() = prefs.getInt(KEY_NOVEL_SKIP_ERRORS, 2).coerceIn(0, 20)
		set(value) = prefs.edit { putInt(KEY_NOVEL_SKIP_ERRORS, value) }

	/** Per-source delay overrides (source name -> ms); they win over the global delay. */
	var novelDelayOverrides: Map<String, Int>
		get() = prefs.getString(KEY_NOVEL_OVERRIDES, null).orEmpty().split(';').mapNotNull {
			val i = it.lastIndexOf('=')
			if (i <= 0) null else it.substring(0, i) to (it.substring(i + 1).toIntOrNull() ?: return@mapNotNull null)
		}.toMap()
		set(value) = prefs.edit {
			putString(KEY_NOVEL_OVERRIDES, value.entries.joinToString(";") { "${it.key}=${it.value}" })
		}

	/** Translate novel chapters in the reader (and, with [isNovelAutoTranslateDownloads], as they download). */
	var isNovelTranslationEnabled: Boolean
		get() = prefs.getBoolean(KEY_NOVEL_TRANSLATE, false)
		set(value) = prefs.edit { putBoolean(KEY_NOVEL_TRANSLATE, value) }

	/** Language the chapters are written in, or "auto". */
	var novelTranslationSource: String
		get() = prefs.getString(KEY_NOVEL_TRANSLATE_SOURCE, null) ?: "auto"
		set(value) = prefs.edit { putString(KEY_NOVEL_TRANSLATE_SOURCE, value) }

	var novelTranslationTarget: String
		get() = prefs.getString(KEY_NOVEL_TRANSLATE_TARGET, null) ?: "en"
		set(value) = prefs.edit { putString(KEY_NOVEL_TRANSLATE_TARGET, value) }

	val isNovelAutoTranslateDownloads: Boolean
		get() = prefs.getBoolean(KEY_NOVEL_TRANSLATE_AUTO_DOWNLOADS, false)

	var isChaptersGridView: Boolean
		get() = prefs.getBoolean(KEY_GRID_VIEW_CHAPTERS, false)
		set(value) = prefs.edit { putBoolean(KEY_GRID_VIEW_CHAPTERS, value) }

	// Per-manga, because only a handful of sources hand back a badly ordered chapter list.
	// Two flags rather than one value, so the "sort by name" choices people already made still apply.
	fun getChaptersSortOrder(mangaId: Long): ChaptersSortOrder = when {
		prefs.getBoolean(KEY_SORT_CHAPTERS_BY_DATE + mangaId, false) -> ChaptersSortOrder.DATE
		prefs.getBoolean(KEY_SORT_CHAPTERS_BY_NAME + mangaId, false) -> ChaptersSortOrder.NAME
		else -> ChaptersSortOrder.SOURCE
	}

	fun setChaptersSortOrder(mangaId: Long, value: ChaptersSortOrder) {
		prefs.edit {
			remove(KEY_SORT_CHAPTERS_BY_NAME + mangaId)
			remove(KEY_SORT_CHAPTERS_BY_DATE + mangaId)
			when (value) {
				ChaptersSortOrder.SOURCE -> Unit
				ChaptersSortOrder.NAME -> putBoolean(KEY_SORT_CHAPTERS_BY_NAME + mangaId, true)
				ChaptersSortOrder.DATE -> putBoolean(KEY_SORT_CHAPTERS_BY_DATE + mangaId, true)
			}
		}
	}

	/**
	 * Settings ▸ Extensions ▸ Default browse order. Picking it rewrites every installed extension's
	 * stored sort; this copy is what extensions installed afterwards fall back to.
	 */
	var defaultBrowseSortOrder: SortOrder
		get() = prefs.getEnumValue(KEY_DEFAULT_BROWSE_SORT, SortOrder.POPULARITY)
			.takeIf { it == SortOrder.POPULARITY || it == SortOrder.UPDATED } ?: SortOrder.POPULARITY
		set(value) = prefs.edit { putEnumValue(KEY_DEFAULT_BROWSE_SORT, value) }

	val zoomMode: ZoomMode
		get() = prefs.getEnumValue(KEY_ZOOM_MODE, ZoomMode.FIT_CENTER)

	val trackSources: Set<String>
		get() = prefs.getStringSet(KEY_TRACK_SOURCES, null) ?: setOf(TRACK_FAVOURITES)

	var isAppProtectionEnabled: Boolean
		get() = prefs.getBoolean(KEY_PROTECT_APP, false)
		set(value) = prefs.edit { putBoolean(KEY_PROTECT_APP, value) }

	var appProtectionTimeout: AppProtectionTimeout
		get() = prefs.getEnumValue(KEY_PROTECT_APP_TIMEOUT, AppProtectionTimeout.INSTANT)
		set(value) = prefs.edit { putEnumValue(KEY_PROTECT_APP_TIMEOUT, value) }

	val appProtectionTimeoutMillis: Long
		get() = appProtectionTimeout.timeoutMillis

	/** Salted SHA-256 of the custom unlock PIN; null means the lock uses device/biometric auth. */
	val appPasswordHash: String?
		get() = prefs.getString(KEY_APP_PASSWORD, null)

	/** True when the app lock uses a custom PIN rather than device/biometric auth. */
	val isAppPasswordSet: Boolean
		get() = !appPasswordHash.isNullOrEmpty()

	/** Store a new unlock PIN as a salted SHA-256 hash. Never backed up (see [SENSITIVE_BACKUP_KEYS]). */
	fun setAppPassword(pin: String) {
		val salt = UUID.randomUUID().toString()
		prefs.edit {
			putString(KEY_APP_PASSWORD_SALT, salt)
			putString(KEY_APP_PASSWORD, Hash.sha256(salt + pin))
		}
	}

	fun clearAppPassword() = prefs.edit {
		remove(KEY_APP_PASSWORD)
		remove(KEY_APP_PASSWORD_SALT)
	}

	fun verifyAppPassword(pin: String): Boolean {
		val salt = prefs.getString(KEY_APP_PASSWORD_SALT, null) ?: return false
		val hash = prefs.getString(KEY_APP_PASSWORD, null) ?: return false
		return Hash.sha256(salt + pin) == hash
	}

	/**
	 * Ids of installed novel (text) extension sources, remembered from the last extension scan.
	 * Loading extensions needs a classloader pass, so right after launch a novel already in the
	 * library would otherwise look like a manga source and open in the image reader.
	 */
	var novelSourceIds: Set<Long>
		get() = prefs.getStringSet(KEY_NOVEL_SOURCE_IDS, emptySet())
			.orEmpty()
			.mapNotNullToSet { it.toLongOrNull() }
		set(value) = prefs.edit {
			putStringSet(KEY_NOVEL_SOURCE_IDS, value.mapToSet { it.toString() })
		}

	// ---- Deepsync Home ------------------------------------------------------------------------

	var homeMode: HomeMode
		get() = prefs.getEnumValue(KEY_HOME_MODE, HomeMode.MANGA)
		set(value) = prefs.edit { putEnumValue(KEY_HOME_MODE, value) }

	/** Which half of Streaming mode is showing: anime, or TV & Movies. Set from the mode fan. */
	var streamingKind: org.koitharu.kotatsu.home.ui.model.StreamingKind
		get() = prefs.getEnumValue(KEY_STREAMING_KIND, streamingDefault ?: org.koitharu.kotatsu.home.ui.model.StreamingKind.ANIME)
		set(value) = prefs.edit { putEnumValue(KEY_STREAMING_KIND, value) }

	/**
	 * What Streaming opens on, or null when the default is off. Off: the mode fan splits Streaming into Anime and
	 * TV & Movies. On: the fan shows that kind directly (its own icon and name) and never splits.
	 * Set in Home layout settings.
	 */
	var streamingDefault: org.koitharu.kotatsu.home.ui.model.StreamingKind?
		get() = prefs.getEnumValue(KEY_STREAMING_DEFAULT, org.koitharu.kotatsu.home.ui.model.StreamingKind::class.java)
		set(value) = prefs.edit { putEnumValue(KEY_STREAMING_DEFAULT, value) }

	/**
	 * "Custom homepage for each mode": Manga, Novel and Streaming each keep their own Home settings (the
	 * ones read through [homeReadKey] / written through [homeWriteKey] below): tracker, source catalogue,
	 * banner, carousels, custom carousel and filters. A mode that has not been set yet starts from the
	 * shared value, so turning this on changes nothing until something is edited. Off: one set for all.
	 */
	var isHomePerMode: Boolean
		get() = isModeOverridden(ModeOverrideArea.HOME)
		set(value) = setModeOverridden(ModeOverrideArea.HOME, value)

	// ---- Override global defaults ---------------------------------------------------------------
	// Settings > Override global defaults: every [ModeOverrideArea] has a switch. While it is on, the settings
	// of that area are kept once per mode; a mode that was never edited keeps following the shared value, so
	// turning an area on changes nothing until something is edited. Off: one shared value for all modes.

	/**
	 * Master switch of Settings > Override global defaults. Off (the default): every area uses its shared value, whatever
	 * its own switch says. The per-area switches and the per-mode values are kept for when this is turned on again.
	 */
	var isModeOverridesEnabled: Boolean
		get() = prefs.getBoolean(KEY_MODE_OVERRIDES_ENABLED, false)
		set(value) = prefs.edit { putBoolean(KEY_MODE_OVERRIDES_ENABLED, value) }

	fun isModeOverridden(area: ModeOverrideArea): Boolean =
		isModeOverridesEnabled && prefs.getBoolean(area.key, false)

	fun setModeOverridden(area: ModeOverrideArea, value: Boolean) {
		prefs.edit {
			putBoolean(area.key, value)
			// An area switched on from somewhere else (the Home banner settings) has to take effect
			if (value) putBoolean(KEY_MODE_OVERRIDES_ENABLED, true)
		}
	}

	/** The key a setting of [area] is written to for [mode]: the mode's own key while the area is overridden. */
	private fun areaWriteKey(area: ModeOverrideArea, base: String, mode: HomeMode = homeMode): String =
		if (isModeOverridden(area)) perModeKey(base, mode) else base

	/** The key it is read from: the mode's own key once set, otherwise the shared one. */
	private fun areaReadKey(area: ModeOverrideArea, base: String, mode: HomeMode = homeMode): String {
		if (!isModeOverridden(area)) return base
		val own = perModeKey(base, mode)
		return if (prefs.contains(own)) own else base
	}

	/** A switch of [area] as it reads in [mode]. Used by Settings > Override global defaults to edit any mode. */
	fun getModeBoolean(area: ModeOverrideArea, base: String, default: Boolean, mode: HomeMode): Boolean =
		prefs.getBoolean(areaReadKey(area, base, mode), default)

	fun setModeBoolean(area: ModeOverrideArea, base: String, mode: HomeMode, value: Boolean) {
		prefs.edit { putBoolean(areaWriteKey(area, base, mode), value) }
	}

	/** One value for the three tracking-prompt switches, so a mode never ends up with a mixed combination. */
	fun getModeTrackingChoice(mode: HomeMode): TrackingChoice {
		val ask = getModeBoolean(ModeOverrideArea.SERVICES, KEY_SCROBBLING_ASK, true, mode)
		val best = getModeBoolean(ModeOverrideArea.SERVICES, KEY_SCROBBLING_AUTO_TRACK_BEST, false, mode)
		val exact = getModeBoolean(ModeOverrideArea.SERVICES, KEY_SCROBBLING_AUTO_LINK, true, mode)
		return when {
			best -> TrackingChoice.CLOSEST
			ask -> TrackingChoice.ASK
			exact -> TrackingChoice.EXACT
			else -> TrackingChoice.ASK
		}
	}

	fun setModeTrackingChoice(mode: HomeMode, choice: TrackingChoice) {
		val area = ModeOverrideArea.SERVICES
		prefs.edit {
			putBoolean(areaWriteKey(area, KEY_SCROBBLING_ASK, mode), choice == TrackingChoice.ASK)
			putBoolean(areaWriteKey(area, KEY_SCROBBLING_AUTO_TRACK_BEST, mode), choice == TrackingChoice.CLOSEST)
			putBoolean(areaWriteKey(area, KEY_SCROBBLING_AUTO_LINK, mode), choice == TrackingChoice.EXACT)
		}
	}

	/** What happens when a title that is not tracked yet is opened. */
	enum class TrackingChoice { ASK, CLOSEST, EXACT }

	/** Where Suggestions gets its titles in [mode]. */
	fun suggestionsSourceFor(mode: HomeMode): SuggestionsSource =
		prefs.getEnumValue(areaReadKey(ModeOverrideArea.SUGGESTIONS, KEY_SUGGESTIONS_SOURCE, mode), SuggestionsSource.SOURCES)

	fun setSuggestionsSourceFor(mode: HomeMode, source: SuggestionsSource) {
		prefs.edit { putEnumValue(areaWriteKey(ModeOverrideArea.SUGGESTIONS, KEY_SUGGESTIONS_SOURCE, mode), source) }
	}

	/**
	 * Which tracker Explore's Discover browses in [mode]. [HomeMetadata.SOURCES] here only means "same as Home":
	 * Discover always needs a tracker, so it then uses the one Home would use (never the source catalogue).
	 */
	fun exploreProviderFor(mode: HomeMode): HomeMetadata =
		prefs.getEnumValue(areaReadKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_PROVIDER, mode), HomeMetadata.SOURCES)

	fun setExploreProviderFor(mode: HomeMode, provider: HomeMetadata) {
		prefs.edit { putEnumValue(areaWriteKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_PROVIDER, mode), provider) }
	}

	/** The tracker Discover uses for the mode being shown: its own choice, else Home's tracker. Never the sources. */
	var exploreMetadata: HomeMetadata
		get() = exploreProviderFor(homeMode).takeIf { it != HomeMetadata.SOURCES } ?: homeMetadataProvider
		set(value) = setExploreProviderFor(homeMode, value)

	/**
	 * Whether a title opened from Discover shows the tracker's page (true) or goes to the source (false) in [mode].
	 * Until chosen it follows Home's "covers and info" choice.
	 */
	fun isExploreInfoFromTrackerFor(mode: HomeMode): Boolean {
		val key = areaReadKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_INFO_TRACKER, mode)
		return if (prefs.contains(key)) prefs.getBoolean(key, true) else if (mode == homeMode) isMetadataFromTracker else true
	}

	fun setExploreInfoFromTrackerFor(mode: HomeMode, value: Boolean) {
		prefs.edit { putBoolean(areaWriteKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_INFO_TRACKER, mode), value) }
	}

	var isExploreInfoFromTracker: Boolean
		get() = isExploreInfoFromTrackerFor(homeMode)
		set(value) = setExploreInfoFromTrackerFor(homeMode, value)

	/** Suggestions for the mode being shown. */
	var suggestionsSource: SuggestionsSource
		get() = suggestionsSourceFor(homeMode)
		set(value) = setSuggestionsSourceFor(homeMode, value)

	/** Updates page: titles of every mode (true, how it always was) or only the mode being shown. */
	val isUpdatesAllModes: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.UPDATES, KEY_UPDATES_ALL_MODES), true)

	/** Feed page: updates of every mode (true) or only the mode being shown (false, how it always was). */
	val isFeedAllModes: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.UPDATES, KEY_FEED_ALL_MODES), false)

	/** History page: entries of every mode (true) or only the mode being shown (false, how it always was). */
	val isHistoryAllModes: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.HISTORY, KEY_HISTORY_ALL_MODES), false)

	private fun homeWriteKey(base: String): String = areaWriteKey(ModeOverrideArea.HOME, base)

	private fun homeReadKey(base: String): String = areaReadKey(ModeOverrideArea.HOME, base)

	var homeBannerStyle: HomeBannerStyle
		get() = prefs.getEnumValue(homeReadKey(KEY_HOME_BANNER_STYLE), HomeBannerStyle.PANELS)
		set(value) = prefs.edit { putEnumValue(homeWriteKey(KEY_HOME_BANNER_STYLE), value) }

	/**
	 * The titles Home's banner showed last (JSON), kept so Settings > Home layout can draw the real banner
	 * with real covers. Written by the Home screen, read by the layout preview.
	 */
	var homeHeroSnapshot: String?
		get() = prefs.getString(KEY_HOME_HERO_SNAPSHOT, null)
		set(value) = prefs.edit { putString(KEY_HOME_HERO_SNAPSHOT, value) }

	var isHomeBannerAutoRotate: Boolean
		get() = prefs.getBoolean(homeReadKey(KEY_HOME_BANNER_ROTATE), true)
		set(value) = prefs.edit { putBoolean(homeWriteKey(KEY_HOME_BANNER_ROTATE), value) }

	/**
	 * Which tracker supplies Home's rows, search and the details shown for a title. Always a tracker, never
	 * [HomeMetadata.SOURCES]: whether the sources replace it is [isHomeSourceCatalogue].
	 */
	var homeMetadataProvider: HomeMetadata
		get() {
			val own = prefs.getEnumValue(homeReadKey(KEY_HOME_PROVIDER), HomeMetadata.SOURCES)
			// Older versions kept one choice (sources or a tracker) under the old key
			val legacy = prefs.getEnumValue(KEY_HOME_METADATA, HomeMetadata.SOURCES)
			return when {
				own != HomeMetadata.SOURCES -> own
				legacy != HomeMetadata.SOURCES -> legacy
				else -> HomeMetadata.ANILIST
			}
		}
		set(value) = prefs.edit { putEnumValue(homeWriteKey(KEY_HOME_PROVIDER), if (value == HomeMetadata.SOURCES) HomeMetadata.ANILIST else value) }

	/** "Source catalogue": Home lists what the installed sources offer instead of a tracker's catalogue. */
	var isHomeSourceCatalogue: Boolean
		get() = if (prefs.contains(homeReadKey(KEY_HOME_CATALOGUE))) {
			prefs.getBoolean(homeReadKey(KEY_HOME_CATALOGUE), false)
		} else {
			prefs.getEnumValue(KEY_HOME_METADATA, HomeMetadata.SOURCES) == HomeMetadata.SOURCES
		}
		set(value) = prefs.edit { putBoolean(homeWriteKey(KEY_HOME_CATALOGUE), value) }

	/** What Home, search and details actually use: [HomeMetadata.SOURCES] while the catalogue is on. */
	var homeMetadata: HomeMetadata
		get() = if (isHomeSourceCatalogue) HomeMetadata.SOURCES else homeMetadataProvider
		set(value) {
			if (value == HomeMetadata.SOURCES) {
				isHomeSourceCatalogue = true
			} else {
				homeMetadataProvider = value
				isHomeSourceCatalogue = false
			}
		}

	/**
	 * Where covers and info on a title's page come from: the tracker (true) or the source (false). A title
	 * that is tracked uses the tracker it is tracked on; others are matched on the chosen tracker.
	 * Until the user decides, it follows the old behaviour: the tracker, unless the source catalogue was on.
	 */
	var isMetadataFromTracker: Boolean
		get() = if (prefs.contains(homeReadKey(KEY_METADATA_FROM_TRACKER))) {
			prefs.getBoolean(homeReadKey(KEY_METADATA_FROM_TRACKER), true)
		} else {
			!isHomeSourceCatalogue
		}
		set(value) = prefs.edit { putBoolean(homeWriteKey(KEY_METADATA_FROM_TRACKER), value) }

	/** Source names Home reads from in [mode]. Empty means every enabled source of that kind. */
	fun getHomeSources(mode: HomeMode): Set<String> =
		prefs.getStringSet(homeSourcesKey(mode), emptySet()).orEmpty().toSet()

	fun setHomeSources(mode: HomeMode, names: Set<String>) {
		prefs.edit { putStringSet(homeSourcesKey(mode), names) }
	}

	var homeGenresInclude: Set<String>
		get() = prefs.getStringSet(homeReadKey(KEY_HOME_GENRES_INCLUDE), emptySet()).orEmpty().toSet()
		set(value) = prefs.edit { putStringSet(homeWriteKey(KEY_HOME_GENRES_INCLUDE), value) }

	var homeGenresExclude: Set<String>
		get() = prefs.getStringSet(homeReadKey(KEY_HOME_GENRES_EXCLUDE), emptySet()).orEmpty().toSet()
		set(value) = prefs.edit { putStringSet(homeWriteKey(KEY_HOME_GENRES_EXCLUDE), value) }

	/** Extra to the global content filter: hides NSFW titles on Home only. */
	var isHomeHideNsfw: Boolean
		get() = prefs.getBoolean(homeReadKey(KEY_HOME_HIDE_NSFW), false)
		set(value) = prefs.edit { putBoolean(homeWriteKey(KEY_HOME_HIDE_NSFW), value) }

	/** Favourites categories shown as carousels on Home, by category id. */
	var homeFavCategories: Set<Long>
		get() = prefs.getStringSet(homeReadKey(KEY_HOME_FAV_CATEGORIES), emptySet()).orEmpty().mapNotNullToSet { it.toLongOrNull() }
		set(value) = prefs.edit { putStringSet(homeWriteKey(KEY_HOME_FAV_CATEGORIES), value.mapToSet { it.toString() }) }

	/**
	 * Home carousels the user switched off, by [org.koitharu.kotatsu.home.ui.model.HomeCarousel.key].
	 * Empty means every carousel is on, which is also what a fresh install gets.
	 */
	var homeHiddenCarousels: Set<String>
		get() = prefs.getStringSet(homeReadKey(KEY_HOME_HIDDEN_CAROUSELS), emptySet()).orEmpty().toSet()
		set(value) = prefs.edit { putStringSet(homeWriteKey(KEY_HOME_HIDDEN_CAROUSELS), value) }

	/**
	 * The three ways an untracked title gets tracked are mutually exclusive: ask, link the closest match
	 * silently, or link exact titles silently. The settings screen keeps them exclusive when toggled, but
	 * older installs can have several stored as on, so the getters resolve that: closest match wins over
	 * ask, and ask wins over exact-title linking.
	 *
	 * Ask "track this title?" when a chapter of an untracked title is opened.
	 */
	val isScrobblingAskEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_ASK), true) &&
			!prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_AUTO_TRACK_BEST), false)

	/**
	 * Link every new title to the closest match on the tracker without asking. While on, the "Save progress?"
	 * sheet never appears.
	 */
	val isScrobblingAutoTrackBestEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_AUTO_TRACK_BEST), false)

	/** Manga the user chose "Never for this title" for. */
	var scrobblingNeverAsk: Set<Long>
		get() = prefs.getStringSet(KEY_SCROBBLING_NEVER_ASK, emptySet()).orEmpty().mapNotNullToSet { it.toLongOrNull() }
		set(value) = prefs.edit { putStringSet(KEY_SCROBBLING_NEVER_ASK, value.mapToSet { it.toString() }) }

	/** Trackers (HomeMetadata names) whose catalogues global search includes next to the sources. */
	var globalSearchTrackers: Set<String>
		get() = when {
			prefs.contains(KEY_GLOBAL_SEARCH_TRACKERS) ->
				prefs.getStringSet(KEY_GLOBAL_SEARCH_TRACKERS, emptySet()).orEmpty()
			// Never chosen: search the tracker Home already uses, unless Home runs on the sources
			!isHomeSourceCatalogue -> setOf(homeMetadataProvider.name)
			else -> emptySet()
		}
		set(value) = prefs.edit { putStringSet(KEY_GLOBAL_SEARCH_TRACKERS, value) }

	/** Explore opens on its Discover (tracker) page rather than the Sources page. */
	var isExploreDiscoverDefault: Boolean
		// Until chosen, follow Home: Discover is only useful once a tracker (not the source catalogue) is in use
		get() = if (prefs.contains(areaReadKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_DISCOVER_DEFAULT))) {
			prefs.getBoolean(areaReadKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_DISCOVER_DEFAULT), true)
		} else {
			!isHomeSourceCatalogue
		}
		set(value) = prefs.edit { putBoolean(areaWriteKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_DISCOVER_DEFAULT), value) }

	/** Explore's Discover page lists titles as rows instead of a poster grid. */
	var isExploreListView: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_LIST_VIEW), false)
		set(value) = prefs.edit { putBoolean(areaWriteKey(ModeOverrideArea.EXPLORE, KEY_EXPLORE_LIST_VIEW), value) }

	var isGlobalSearchNovelScope: Boolean
		get() = prefs.getBoolean(KEY_GLOBAL_SEARCH_NOVEL_SCOPE, false)
		set(value) = prefs.edit { putBoolean(KEY_GLOBAL_SEARCH_NOVEL_SCOPE, value) }

	var isSearchPinnedOnly: Boolean
		get() = prefs.getBoolean(KEY_SEARCH_PINNED_ONLY, false)
		set(value) = prefs.edit { putBoolean(KEY_SEARCH_PINNED_ONLY, value) }

	var isSearchLocalOnly: Boolean
		get() = prefs.getBoolean(KEY_SEARCH_LOCAL_ONLY, false)
		set(value) = prefs.edit { putBoolean(KEY_SEARCH_LOCAL_ONLY, value) }

	var isShizukuInstallerEnabled: Boolean
		get() = prefs.getBoolean(KEY_SHIZUKU_INSTALLER, false)
		set(value) = prefs.edit {
			putBoolean(KEY_SHIZUKU_INSTALLER, value)
			if (!value) putBoolean(KEY_AUTO_UPDATE_EXTENSIONS, false)
			if (value) putBoolean(KEY_PRIVATE_INSTALLER, false)
		}

	var isPrivateInstallEnabled: Boolean
		get() = prefs.getBoolean(KEY_PRIVATE_INSTALLER, false)
		set(value) = prefs.edit {
			putBoolean(KEY_PRIVATE_INSTALLER, value)
			if (value) putBoolean(KEY_SHIZUKU_INSTALLER, false)
		}

	var isAutoUpdateExtensionsEnabled: Boolean
		get() = prefs.getBoolean(KEY_AUTO_UPDATE_EXTENSIONS, false)
		set(value) = prefs.edit { putBoolean(KEY_AUTO_UPDATE_EXTENSIONS, value) }

	/**
	 * Last computed "extension updates available" result, persisted like Mihon's extension update
	 * count so the indicator survives a cold start where the store catalog isn't loaded yet.
	 */
	var hasExtensionUpdates: Boolean
		get() = prefs.getBoolean(KEY_EXTENSION_UPDATES_AVAILABLE, false)
		set(value) = prefs.edit { putBoolean(KEY_EXTENSION_UPDATES_AVAILABLE, value) }

	var isExtensionUpdateNotificationsEnabled: Boolean
		get() = prefs.getBoolean(KEY_EXTENSION_UPDATE_NOTIFICATIONS, true)
		set(value) = prefs.edit { putBoolean(KEY_EXTENSION_UPDATE_NOTIFICATIONS, value) }

	var lastExtensionUpdateNotificationTime: Long
		get() = prefs.getLong(KEY_LAST_EXTENSION_UPDATE_NOTIFICATION_TIME, 0L)
		set(value) = prefs.edit { putLong(KEY_LAST_EXTENSION_UPDATE_NOTIFICATION_TIME, value) }

	val searchSuggestionTypes: Set<SearchSuggestionType>
		get() = prefs.getStringSet(KEY_SEARCH_SUGGESTION_TYPES, null)?.let { stringSet ->
			stringSet.mapNotNullTo(EnumSet.noneOf(SearchSuggestionType::class.java)) { x ->
				enumValueOf<SearchSuggestionType>(x)
			}
		} ?: EnumSet.allOf(SearchSuggestionType::class.java)

	val isExitConfirmationEnabled: Boolean
		get() = prefs.getBoolean(KEY_EXIT_CONFIRM, false)

	val isDynamicShortcutsEnabled: Boolean
		get() = prefs.getBoolean(KEY_SHORTCUTS, true)

	val isPagesTabEnabled: Boolean
		get() = prefs.getBoolean(KEY_PAGES_TAB, true)

	val defaultDetailsTab: Int
		get() = if (isPagesTabEnabled) {
			val raw = prefs.getString(KEY_DETAILS_TAB, null)?.toIntOrNull() ?: -1
			if (raw == -1) {
				lastDetailsTab
			} else {
				raw
			}.coerceIn(0, 2)
		} else {
			0
		}

	var lastDetailsTab: Int
		get() = prefs.getInt(KEY_DETAILS_LAST_TAB, 0)
		set(value) = prefs.edit { putInt(KEY_DETAILS_LAST_TAB, value) }

	val isContentPrefetchEnabled: Boolean
		get() {
			if (isBackgroundNetworkRestricted()) {
				return false
			}
			val policy = NetworkPolicy.from(prefs.getString(KEY_PREFETCH_CONTENT, null), NetworkPolicy.ALWAYS)
			return policy.isNetworkAllowed(connectivityManager)
		}

	var sourcesSortOrder: SourcesSortOrder
		get() = prefs.getEnumValue(KEY_SOURCES_ORDER, SourcesSortOrder.ALPHABETIC)
		set(value) = prefs.edit { putEnumValue(KEY_SOURCES_ORDER, value) }

	var isSourcesGridMode: Boolean
		get() = prefs.getBoolean(KEY_SOURCES_GRID, true)
		set(value) = prefs.edit { putBoolean(KEY_SOURCES_GRID, value) }

	/** Extensions in a row of Explore's grid (3, 4 or 5). */
	val sourcesGridColumns: Int
		get() = prefs.getInt(KEY_SOURCES_GRID_COLUMNS, 4)

	/**
	 * The active language chosen per logical source (a package + source-name pair) for
	 * multi-language extensions. Each entry is encoded as "lang\npkgName\nsourceName" (newline
	 * delimited; none of the parts can contain a newline), so a single source collapses its
	 * language variants into one Explore entity and the user picks exactly one active language
	 * for it. Unset sources fall back to the install-time default (app language -> English ->
	 * any), resolved at read time.
	 */
	var mihonPerExtActiveLangs: Set<String>
		get() = prefs.getStringSet(KEY_MIHON_PER_EXT_ACTIVE_LANG, emptySet()).orEmpty()
		set(value) = prefs.edit { putStringSet(KEY_MIHON_PER_EXT_ACTIVE_LANG, value) }

	fun getMihonActiveLang(pkgName: String, sourceName: String): String? {
		val suffix = "\n" + mihonSourceKey(pkgName, sourceName)
		return mihonPerExtActiveLangs.firstOrNull { it.endsWith(suffix) }
			?.substringBefore('\n')
			?.takeIf { it.isNotEmpty() }
	}

	fun setMihonActiveLang(pkgName: String, sourceName: String, lang: String) {
		val suffix = "\n" + mihonSourceKey(pkgName, sourceName)
		mihonPerExtActiveLangs = mihonPerExtActiveLangs.filterNot { it.endsWith(suffix) }.toSet() + (lang + suffix)
	}

	private fun mihonSourceKey(pkgName: String, sourceName: String): String = "$pkgName\n$sourceName"

	/** Package names of extensions hidden from Explore. They remain in the extension manager. */
	var mihonHiddenPackages: Set<String>
		get() = prefs.getStringSet(KEY_MIHON_HIDDEN_PACKAGES, emptySet()).orEmpty()
		set(value) = prefs.edit { putStringSet(KEY_MIHON_HIDDEN_PACKAGES, value) }

	/** BCP-47 codes of source languages hidden from Explore. Empty means "show everything". */
	var hiddenSourceLanguages: Set<String>
		get() = prefs.getStringSet(KEY_HIDDEN_SOURCE_LANGUAGES, emptySet()).orEmpty()
		set(value) = prefs.edit { putStringSet(KEY_HIDDEN_SOURCE_LANGUAGES, value) }

	/** LNReader plugin ids hidden from Explore. Mirrors [mihonHiddenPackages] for novel plugins. */
	var lnHiddenPlugins: Set<String>
		get() = prefs.getStringSet(KEY_LN_HIDDEN_PLUGINS, emptySet()).orEmpty()
		set(value) = prefs.edit { putStringSet(KEY_LN_HIDDEN_PLUGINS, value) }

	fun isMihonPackageHidden(pkgName: String): Boolean = pkgName in mihonHiddenPackages

	fun setMihonPackageHidden(pkgName: String, hidden: Boolean) {
		val updated = mihonHiddenPackages.toMutableSet()
		if (hidden) updated.add(pkgName) else updated.remove(pkgName)
		mihonHiddenPackages = updated
	}

	var externalExtensionsRepoUrl: String?
		get() = prefs.getString(KEY_EXTERNAL_EXTENSIONS_REPO_URL, null)?.takeIf { it.isNotBlank() }
		set(value) = prefs.edit {
			if (value.isNullOrBlank()) {
				remove(KEY_EXTERNAL_EXTENSIONS_REPO_URL)
			} else {
				putString(KEY_EXTERNAL_EXTENSIONS_REPO_URL, value.trim())
			}
		}

	// Legacy single-store ownership, read once by ExtensionStoreRegistry migration.
	private val extensionRepoMap: Map<String, String>
		get() = prefs.getStringSet(KEY_MIHON_EXTENSION_REPOS, emptySet()).orEmpty()
			.mapNotNull { entry ->
				val sep = entry.indexOf('\t')
				if (sep <= 0) null else entry.substring(0, sep) to entry.substring(sep + 1)
			}.toMap()

	fun getExtensionRepoUrls(): Map<String, String> = extensionRepoMap

	// Legacy repo metadata, read once by ExtensionStoreRegistry migration.
	val externalRepoInfos: List<ExternalRepoInfo>
		get() = prefs.getString(KEY_MIHON_REPO_INFOS, null)
			?.let { runCatching { json.decodeFromString<List<ExternalRepoInfo>>(it) }.getOrNull() }
			?: emptyList()

	var extensionStoreRegistryState: ExtensionStoreRegistryState
		get() = prefs.getString(KEY_EXTENSION_STORE_REGISTRY, null)
			?.let { runCatching { json.decodeFromString<ExtensionStoreRegistryState>(it) }.getOrNull() }
			?: ExtensionStoreRegistryState()
		set(value) = prefs.edit {
			putString(KEY_EXTENSION_STORE_REGISTRY, json.encodeToString(value))
		}

	var isExtensionStoreMigrationComplete: Boolean
		get() = prefs.getBoolean(KEY_EXTENSION_STORE_MIGRATED, false)
		set(value) = prefs.edit { putBoolean(KEY_EXTENSION_STORE_MIGRATED, value) }

	fun getExtensionStoreLabel(packageName: String, signatures: Collection<String>): String? {
		val state = extensionStoreRegistryState
		val mode = if (isPrivateInstallEnabled) ExtensionInstallMode.SANDBOX else ExtensionInstallMode.SYSTEM
		state.ownerships.firstOrNull { it.mode == mode && it.packageName == packageName }
			?.storeId
			?.let { id -> state.stores.firstOrNull { it.id == id } }
			?.let { return it.displayName }
		return state.stores.filter { store ->
			store.fingerprint?.let { fingerprint ->
				signatures.any { it.equals(fingerprint, ignoreCase = true) }
			} == true
		}.singleOrNull()?.displayName
	}


	val isPagesNumbersEnabled: Boolean
		get() = prefs.getBoolean(KEY_PAGES_NUMBERS, false)

	val screenshotsPolicy: ScreenshotsPolicy
		get() = prefs.getEnumValue(KEY_SCREENSHOTS_POLICY, ScreenshotsPolicy.ALLOW)

	val isAdBlockEnabled: Boolean
		get() = prefs.getBoolean(KEY_ADBLOCK, false)

	var userSpecifiedMangaDirectories: Set<File>
		get() {
			val set = prefs.getStringSet(KEY_LOCAL_MANGA_DIRS, emptySet()).orEmpty()
			return set.mapNotNullToSet { File(it).takeIfReadable() }
		}
		set(value) {
			val set = value.mapToSet { it.absolutePath }
			prefs.edit { putStringSet(KEY_LOCAL_MANGA_DIRS, set) }
		}

	var mangaStorageDir: File?
		get() = prefs.getString(KEY_LOCAL_STORAGE, null)?.let {
			File(it)
		}?.takeIf { it.exists() && it in userSpecifiedMangaDirectories }
		set(value) = prefs.edit {
			if (value == null) {
				remove(KEY_LOCAL_STORAGE)
			} else {
				val userDirs = userSpecifiedMangaDirectories
				if (value !in userDirs) {
					userSpecifiedMangaDirectories = userDirs + value
				}
				putString(KEY_LOCAL_STORAGE, value.path)
			}
		}

	var allowDownloadOnMeteredNetwork: TriStateOption
		get() = prefs.getEnumValue(KEY_DOWNLOADS_METERED_NETWORK, TriStateOption.ASK)
		set(value) = prefs.edit { putEnumValue(KEY_DOWNLOADS_METERED_NETWORK, value) }

	val preferredDownloadFormat: DownloadFormat
		get() = prefs.getEnumValue(KEY_DOWNLOADS_FORMAT, DownloadFormat.AUTOMATIC)

	var isSuggestionsEnabled: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS, false)
		set(value) = prefs.edit { putBoolean(KEY_SUGGESTIONS, value) }

	val isSuggestionsWiFiOnly: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS_WIFI_ONLY, false)

	val isSuggestionsExcludeNsfw: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS_EXCLUDE_NSFW, false)

	val isSuggestionsExcludeNovels: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS_EXCLUDE_NOVELS, true)

	val isSuggestionsExcludeManga: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS_EXCLUDE_MANGA, false)

	val isSuggestionsExcludeAnime: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS_EXCLUDE_ANIME, false)

	val isSuggestionsNotificationAvailable: Boolean
		get() = prefs.getBoolean(KEY_SUGGESTIONS_NOTIFICATIONS, false)

	val suggestionsTagsBlacklist: Set<String>
		get() {
			val string = prefs.getString(KEY_SUGGESTIONS_EXCLUDE_TAGS, null)?.trimEnd(' ', ',')
			if (string.isNullOrEmpty()) {
				return emptySet()
			}
			// Excluding "Yaoi" also has to drop "BL" and "Boys' Love": sources name the same thing differently
			return string.split(',').map { it.trim() }.filter { it.isNotEmpty() }
				.flatMapTo(HashSet()) { word -> setOf(word) + org.koitharu.kotatsu.metadata.DiscoverTags.synonymsOf(word) }
		}

	val isReaderBarEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_BAR, true)

	/** Whether long-pressing a tap-grid area runs its long-press action (page save/share/copy etc.). */
	val isReaderLongPressEnabled: Boolean
		get() = prefs.getBoolean(KEY_READER_LONG_PRESS, true)

	val isReaderKeepScreenOn: Boolean
		get() = prefs.getBoolean(KEY_READER_SCREEN_ON, true)

	var readerColorFilter: ReaderColorFilter?
		get() = runCatching {
			ReaderColorFilter(
				brightness = prefs.getFloat(KEY_CF_BRIGHTNESS, ReaderColorFilter.EMPTY.brightness),
				contrast = prefs.getFloat(KEY_CF_CONTRAST, ReaderColorFilter.EMPTY.contrast),
				isInverted = prefs.getBoolean(KEY_CF_INVERTED, ReaderColorFilter.EMPTY.isInverted),
				isGrayscale = prefs.getBoolean(KEY_CF_GRAYSCALE, ReaderColorFilter.EMPTY.isGrayscale),
				isBookBackground = prefs.getBoolean(KEY_CF_BOOK, ReaderColorFilter.EMPTY.isBookBackground),
			).takeUnless { it.isEmpty }
		}.getOrNull()
		set(value) {
			prefs.edit {
				if (value != null) {
					putFloat(KEY_CF_BRIGHTNESS, value.brightness)
					putFloat(KEY_CF_CONTRAST, value.contrast)
					putBoolean(KEY_CF_INVERTED, value.isInverted)
					putBoolean(KEY_CF_GRAYSCALE, value.isGrayscale)
					putBoolean(KEY_CF_BOOK, value.isBookBackground)
				} else {
					remove(KEY_CF_BRIGHTNESS)
					remove(KEY_CF_CONTRAST)
					remove(KEY_CF_INVERTED)
					remove(KEY_CF_GRAYSCALE)
					remove(KEY_CF_BOOK)
				}
			}
		}

	val imagesProxy: Int
		get() {
			val raw = prefs.getString(KEY_IMAGES_PROXY, null)?.toIntOrNull()
			return raw ?: if (prefs.getBoolean(KEY_IMAGES_PROXY_OLD, false)) 0 else -1
		}

	val dnsOverHttps: DoHProvider
		get() = prefs.getEnumValue(KEY_DOH, DoHProvider.NONE)

	/**
	 * User-supplied override for the User-Agent header sent by Mihon/Tachiyomi extensions.
	 * `null` when the user hasn't set one, in which case the extension layer falls back to the
	 * device WebView's User-Agent (so it matches the UA that solves Cloudflare challenges) and
	 * finally to [DEFAULT_MIHON_USER_AGENT]. Mirrors Mihon's "Default user agent string" option.
	 */
	val mihonUserAgentOverride: String?
		get() = prefs.getString(KEY_MIHON_USER_AGENT, null)
			?.trim()
			?.takeIf { it.isNotEmpty() }

	var isSSLBypassEnabled: Boolean
		get() = prefs.getBoolean(KEY_SSL_BYPASS, false)
		set(value) = prefs.edit { putBoolean(KEY_SSL_BYPASS, value) }

	val proxyType: Proxy.Type
		get() {
			val raw = prefs.getString(KEY_PROXY_TYPE, null) ?: return Proxy.Type.DIRECT
			return enumValues<Proxy.Type>().find { it.name == raw } ?: Proxy.Type.DIRECT
		}

	val proxyAddress: String?
		get() = prefs.getString(KEY_PROXY_ADDRESS, null)

	val proxyPort: Int
		get() = prefs.getString(KEY_PROXY_PORT, null)?.toIntOrNull() ?: 0

	val proxyLogin: String?
		get() = prefs.getString(KEY_PROXY_LOGIN, null)?.nullIfEmpty()

	val proxyPassword: String?
		get() = prefs.getString(KEY_PROXY_PASSWORD, null)?.nullIfEmpty()

	var localListOrder: SortOrder
		get() = prefs.getEnumValue(KEY_LOCAL_LIST_ORDER, SortOrder.NEWEST)
		set(value) = prefs.edit { putEnumValue(KEY_LOCAL_LIST_ORDER, value) }

	var historySortOrder: ListSortOrder
		get() = prefs.getEnumValue(KEY_HISTORY_ORDER, ListSortOrder.LAST_READ)
		set(value) = prefs.edit { putEnumValue(KEY_HISTORY_ORDER, value) }

	var allFavoritesSortOrder: ListSortOrder
		get() = prefs.getEnumValue(KEY_FAVORITES_ORDER, ListSortOrder.NEWEST)
		set(value) = prefs.edit { putEnumValue(KEY_FAVORITES_ORDER, value) }

	/** Sort given to new categories; picking one also rewrites every existing category's sort. */
	var defaultCategorySortOrder: ListSortOrder
		get() = prefs.getEnumValue(KEY_CATEGORY_DEFAULT_ORDER, ListSortOrder.NEWEST)
		set(value) = prefs.edit { putEnumValue(KEY_CATEGORY_DEFAULT_ORDER, value) }

	/** Order of the favourite categories everywhere they are listed. */
	var favouriteCategoriesOrder: CategoriesOrder
		get() = prefs.getEnumValue(KEY_CATEGORIES_ORDER, CategoriesOrder.RANDOM)
		set(value) = prefs.edit { putEnumValue(KEY_CATEGORIES_ORDER, value) }

	// comma-joined in pin order, oldest pin first
	fun getPinnedFavourites(categoryId: Long): List<Long> =
		prefs.getString(KEY_FAVORITES_PINNED + categoryId, null)
			?.split(',')
			?.mapNotNull { it.toLongOrNull() }
			.orEmpty()

	fun setPinnedFavourites(categoryId: Long, ids: List<Long>) {
		prefs.edit { putString(KEY_FAVORITES_PINNED + categoryId, ids.joinToString(",")) }
	}

	val isRelatedMangaEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_RELATED_MANGA), true)

	/** Link every manga that is read to each signed-in tracker automatically (exact title matches only). */
	val isScrobblingAutoLinkEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_AUTO_LINK), true) &&
			!prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_AUTO_TRACK_BEST), false) &&
			!prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_ASK), true)

	val isScrobblingProgressSyncEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_SCROBBLING_PROGRESS_SYNC), true)

	/** Keep progress in step between the signed-in trackers on a schedule (the furthest one wins). */
	val isTrackerAutoSyncEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_TRACKER_AUTO_SYNC), true)

	/** Epoch millis of the last finished tracker synchronisation, 0 if there has not been one. */
	var trackerLastSync: Long
		get() = prefs.getLong(KEY_TRACKER_LAST_SYNC, 0L)
		set(value) = prefs.edit { putLong(KEY_TRACKER_LAST_SYNC, value) }

	val isWebtoonZoomEnabled: Boolean
		get() = prefs.getBoolean(KEY_WEBTOON_ZOOM, true)

	var isWebtoonGapsEnabled: Boolean
		get() = prefs.getBoolean(KEY_WEBTOON_GAPS, false)
		set(value) = prefs.edit { putBoolean(KEY_WEBTOON_GAPS, value) }

	var isWebtoonPullGestureEnabled: Boolean
		get() = prefs.getBoolean(KEY_WEBTOON_PULL_GESTURE, false)
		set(value) = prefs.edit { putBoolean(KEY_WEBTOON_PULL_GESTURE, value) }

	@get:FloatRange(from = 0.0, to = 0.5)
	val defaultWebtoonZoomOut: Float
		get() = prefs.getInt(KEY_WEBTOON_ZOOM_OUT, 0).coerceIn(0, 50) / 100f

	@get:FloatRange(from = 0.0, to = 1.0)
	var readerAutoscrollSpeed: Float
		// 0 is unreachable from the slider and used to mean "never configured", which left the
		// timer permanently disabled — fold it into the default instead.
		get() = prefs.getFloat(KEY_READER_AUTOSCROLL_SPEED, 0f)
			.takeIf { it > 0f }?.coerceAtMost(1f) ?: DEFAULT_AUTOSCROLL_SPEED
		set(@FloatRange(from = 0.0, to = 1.0) value) = prefs.edit {
			putFloat(
				KEY_READER_AUTOSCROLL_SPEED,
				value,
			)
		}

	/** Seconds a page stays on screen while autoscroll runs in the paged reader modes. */
	@get:IntRange(from = 1, to = 10)
	var readerAutoscrollPageDelay: Int
		get() = prefs.getInt(KEY_READER_AUTOSCROLL_PAGE_DELAY, DEFAULT_AUTOSCROLL_PAGE_DELAY)
			.coerceIn(1, 10)
		set(value) = prefs.edit { putInt(KEY_READER_AUTOSCROLL_PAGE_DELAY, value.coerceIn(1, 10)) }

	var isReaderAutoscrollFabVisible: Boolean
		get() = prefs.getBoolean(KEY_READER_AUTOSCROLL_FAB, true)
		set(value) = prefs.edit { putBoolean(KEY_READER_AUTOSCROLL_FAB, value) }

	/**
	 * Sticky "the reader wants text-to-speech" flag. Set when TTS is started, cleared only when it is
	 * explicitly stopped, so the quick-start button survives leaving the book or the app.
	 */
	var isReaderTtsFabVisible: Boolean
		get() = prefs.getBoolean(KEY_READER_TTS_FAB, false)
		set(value) = prefs.edit { putBoolean(KEY_READER_TTS_FAB, value) }

	// Page preloading is always on (no user setting): the only thing that turns it off is the system
	// restricting our background data.
	val isPagesPreloadEnabled: Boolean
		get() = !isBackgroundNetworkRestricted()

	val is32BitColorsEnabled: Boolean
		get() = prefs.getBoolean(KEY_32BIT_COLOR, false)

	val isDiscordRpcEnabled: Boolean
		get() = prefs.getBoolean(KEY_DISCORD_RPC, false)

	val isDiscordRpcSkipNsfw: Boolean
		get() = prefs.getBoolean(KEY_DISCORD_RPC_SKIP_NSFW, false)

	var discordToken: String?
		get() = prefs.getString(KEY_DISCORD_TOKEN, null)?.trim()?.nullIfEmpty()
		set(value) = prefs.edit { putString(KEY_DISCORD_TOKEN, value?.nullIfEmpty()) }

	val isWebhooksEnabled: Boolean
		get() = prefs.getBoolean(KEY_WEBHOOKS_ENABLED, false)

	/** A Discord webhook URL carries its own token, so treat it as a secret (see [SENSITIVE_BACKUP_KEYS]). */
	val webhookDiscordUrl: String?
		get() = prefs.getString(KEY_WEBHOOK_DISCORD_URL, null)?.trim()?.nullIfEmpty()

	val webhookJsonUrl: String?
		get() = prefs.getString(KEY_WEBHOOK_JSON_URL, null)?.trim()?.nullIfEmpty()

	fun isWebhookEventEnabled(key: String): Boolean = prefs.getBoolean(key, true)

	var isVerboseLoggingEnabled: Boolean
		get() = prefs.getBoolean(KEY_VERBOSE_LOGGING, false)
		set(value) = prefs.edit { putBoolean(KEY_VERBOSE_LOGGING, value) }

	val isReadingTimeEstimationEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_READING_TIME), true)

	val isEyeReminderEnabled: Boolean
		get() = prefs.getBoolean(KEY_EYE_REMINDER, false)

	val eyeReminderIntervalSeconds: Int
		get() = prefs.getInt(KEY_EYE_REMINDER_INTERVAL, EYE_REMINDER_DEFAULT_INTERVAL)

	val isPagesSavingAskEnabled: Boolean
		get() = prefs.getBoolean(KEY_PAGES_SAVE_ASK, true)

	val isStatsEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_STATS_ENABLED), true)

	/** Records anime watch time for the watching statistics; separate from the reading statistics switch. */
	val isWatchStatsEnabled: Boolean
		get() = prefs.getBoolean(areaReadKey(ModeOverrideArea.SERVICES, KEY_WATCH_STATS_ENABLED), true)

	/**
	 * Reader Next / Previous goes 1, 2, 3: one copy per chapter number, and in-between chapters (1.1, 1.2) are
	 * skipped when their whole chapter exists. A 2.1 with no chapter 2 is kept.
	 */
	val isSkipDuplicateChaptersEnabled: Boolean
		get() = prefs.getBoolean(KEY_SKIP_DUPLICATE_CHAPTERS, false)

	/**
	 * Covers that are wider than tall (the posters some streaming sources ship) are shown as wide cards instead of
	 * being cropped into the usual portrait shape.
	 */
	val isAdaptiveCoversEnabled: Boolean
		get() = prefs.getBoolean(KEY_ADAPTIVE_COVERS, false)

	val isAutoLocalChaptersCleanupEnabled: Boolean
		get() = prefs.getBoolean(KEY_CHAPTERS_CLEAR_AUTO, false)

	/**
	 * How many chapters behind the current reading position are kept when read chapters are
	 * deleted. 0 deletes the previous chapter as soon as the next one is opened.
	 */
	val localChaptersCleanupKeep: Int
		get() = prefs.getInt(KEY_CHAPTERS_CLEAR_KEEP, 2).coerceIn(0, 3)

	fun isPagesCropEnabled(mode: ReaderMode): Boolean {
		val rawValue = prefs.getStringSet(KEY_READER_CROP, emptySet())
		if (rawValue.isNullOrEmpty()) {
			return false
		}
		val needle = if (mode == ReaderMode.WEBTOON) READER_CROP_WEBTOON else READER_CROP_PAGED
		return needle.toString() in rawValue
	}

	fun isTipEnabled(tip: String): Boolean {
		return prefs.getStringSet(KEY_TIPS_CLOSED, emptySet())?.contains(tip) != true
	}

	fun closeTip(tip: String) {
		val closedTips = prefs.getStringSet(KEY_TIPS_CLOSED, emptySet()).orEmpty()
		if (tip in closedTips) {
			return
		}
		prefs.edit { putStringSet(KEY_TIPS_CLOSED, closedTips + tip) }
	}

	fun isIncognitoModeEnabled(isNsfw: Boolean): Boolean {
		return isIncognitoModeEnabled || (isNsfw && incognitoModeForNsfw == TriStateOption.ENABLED)
	}

	fun getPagesSaveDir(context: Context): DocumentFile? =
		prefs.getString(KEY_PAGES_SAVE_DIR, null)?.toUriOrNull()?.let {
			DocumentFile.fromTreeUri(context, it)?.takeIf { it.canWrite() }
		}

	val isPeriodicalBackupEnabled: Boolean
		get() = prefs.getBoolean(KEY_BACKUP_PERIODICAL_ENABLED, false)

	var periodicalBackupDirectory: Uri?
		get() = prefs.getString(KEY_BACKUP_PERIODICAL_OUTPUT, null)?.toUriOrNull()
		set(value) = prefs.edit {
			if (value != null) putString(KEY_BACKUP_PERIODICAL_OUTPUT, value.toString())
			else remove(KEY_BACKUP_PERIODICAL_OUTPUT)
		}

	val periodicalBackupFrequencyMillis: Long
		get() {
			if (!isPeriodicalBackupEnabled) return 0L
			return when (prefs.getString(KEY_BACKUP_PERIODICAL_FREQ, "3")?.toIntOrNull() ?: 3) {
				0 -> 6 * 60 * 60 * 1000L
				1 -> 24 * 60 * 60 * 1000L
				2 -> 2 * 24 * 60 * 60 * 1000L
				3 -> 7 * 24 * 60 * 60 * 1000L
				4 -> 14 * 24 * 60 * 60 * 1000L
				5 -> 30 * 24 * 60 * 60 * 1000L
				else -> 7 * 24 * 60 * 60 * 1000L
			}
		}

	val periodicalBackupMaxCount: Int
		get() {
			if (!prefs.getBoolean(KEY_BACKUP_PERIODICAL_TRIM, true)) return Int.MAX_VALUE
			return prefs.getInt(KEY_BACKUP_PERIODICAL_COUNT, 10).coerceAtLeast(1)
		}

	fun setPagesSaveDir(uri: Uri?) {
		prefs.edit { putString(KEY_PAGES_SAVE_DIR, uri?.toString()) }
	}

	fun getMangaListBadges(): Int {
		val raw = prefs.getStringSet(KEY_MANGA_LIST_BADGES, mangaListBadgesDefault).orEmpty()
		var result = 0
		for (item in raw) {
			result = result or item.toInt()
		}
		return result
	}

	fun subscribe(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
		prefs.registerOnSharedPreferenceChangeListener(listener)
	}

	fun unsubscribe(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
		prefs.unregisterOnSharedPreferenceChangeListener(listener)
	}

	fun observeChanges() = prefs.observeChanges()

	fun observe(vararg keys: String): Flow<String?> = prefs.observeChanges()
		.filter { changed -> changed == null || keys.any { isChangeOf(changed, it) } }
		.onStart { emit(null) }
		.flowOn(Dispatchers.IO)

	fun getAllValues(): Map<String, *> = prefs.all

	// NOTE: intentionally does NOT clear() existing prefs. A restore should merge the backed-up
	// values over the current ones, not wipe everything first — clearing dropped local-only prefs
	// (e.g. the per-install onboarding state) and sent the app back to the welcome screen.
	fun upsertAll(m: Map<String, *>) = prefs.edit {
		putAll(m)
	}

	private fun isBackgroundNetworkRestricted(): Boolean {
		return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			connectivityManager.restrictBackgroundStatus == ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED
		} else {
			false
		}
	}

	/**
	 * The UI scale slider used to be the only way to cure the oversized layout on a narrow screen, and
	 * it now multiplies with the automatic baseline that cures it for everyone — so an old value would
	 * stack on top of the baseline and render about a third too small. Hand the slider back to its
	 * default exactly once, on every screen, so what everyone sees after updating is the scaling the
	 * layouts are actually designed around.
	 */
	private fun migrateUiScale() {
		if (prefs.contains(KEY_UI_SCALE_RESET)) {
			return
		}
		prefs.edit {
			putBoolean(KEY_UI_SCALE_RESET, true)
			remove(KEY_UI_SCALE)
		}
	}

	private fun migrateBackdropBlur() {
		val oldKey = "details_backdrop_blur"
		if (!prefs.contains(oldKey)) return
		prefs.edit {
			if (!prefs.contains(KEY_DETAILS_BACKDROP_BLUR_AMOUNT))
				putInt(KEY_DETAILS_BACKDROP_BLUR_AMOUNT, if (prefs.getBoolean(oldKey, true)) 60 else 0)
			remove(oldKey)
		}
	}

	init {
		migrateBackdropBlur()
		migrateUiScale()
	}

	companion object {

		/**
		 * Default User-Agent for Mihon extensions. Kept in sync with Mihon's own default so that
		 * sources gated behind UA-based anti-bot checks (e.g. Kagane) behave identically.
		 */
		const val DEFAULT_MIHON_USER_AGENT =
			"Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36"

		const val TRACK_HISTORY = "history"
		const val TRACK_FAVOURITES = "favourites"

		const val SMART_UPDATE_SKIP_COMPLETED = "completed"
		const val SMART_UPDATE_SKIP_UNSTARTED = "unstarted"
		const val SMART_UPDATE_SKIP_UNREAD = "unread"

		const val KEY_ADBLOCK = "adblock"
		const val KEY_LIST_MODE = "list_mode_2"
		const val KEY_TITLE_OVER_COVER = "title_over_cover"
		const val KEY_TITLE_TAP_TO_READ = "title_tap_to_read"
		const val KEY_OPEN_EXTERNAL_BROWSER = "open_external_browser"
		const val KEY_LIST_CHECKPOINT = "list_checkpoint"
		const val KEY_CHECK_DUPLICATES = "check_duplicates"
		const val KEY_MIGRATE_DUPLICATE_PROGRESS = "migrate_duplicate_progress"
		const val KEY_GRID_SPACING_INCREASED = "grid_spacing_increased"
		const val KEY_LIST_MODE_HISTORY = "list_mode_history"
		const val KEY_LIST_MODE_FAVORITES = "list_mode_favorites"
		const val KEY_LIST_MODE_SUGGESTIONS = "list_mode_suggestions"
		const val KEY_THEME = "theme"
		const val KEY_COLOR_THEME = "color_theme"
		const val KEY_THEME_AMOLED = "amoled_theme"
		const val KEY_HAPTIC_FEEDBACK = "haptic_feedback"
		const val KEY_HIDE_STATUS_BAR = "hide_status_bar"
		const val KEY_OFFLINE_DISABLED = "no_offline"
		const val KEY_PAGES_CACHE_CLEAR = "pages_cache_clear"
		const val KEY_HTTP_CACHE_CLEAR = "http_cache_clear"
		const val KEY_COOKIES_CLEAR = "cookies_clear"
		const val KEY_CHAPTERS_CLEAR = "chapters_clear"
		const val KEY_CHAPTERS_CLEAR_AUTO = "chapters_clear_auto"
		const val KEY_CHAPTERS_CLEAR_KEEP = "chapters_clear_keep"
		const val KEY_THUMBS_CACHE_CLEAR = "thumbs_cache_clear"
		const val KEY_SEARCH_HISTORY_CLEAR = "search_history_clear"
		const val KEY_UPDATES_FEED_CLEAR = "updates_feed_clear"
		const val KEY_GRID_SIZE = "grid_size"
		const val KEY_ADAPTIVE_COVERS = "adaptive_covers"
		const val KEY_UI_SCALE = "ui_scale"
		// Bumped from "ui_scale_migrated": that pass skipped wide screens, so the reset has to run once
		// more to reach the phones it left alone.
		const val KEY_UI_SCALE_RESET = "ui_scale_reset_v2"
		const val KEY_GRID_SIZE_PAGES = "grid_size_pages"
		const val KEY_LOCAL_STORAGE = "local_storage"
		const val KEY_READER_DOUBLE_PAGES = "reader_double_pages"
		const val KEY_READER_DOUBLE_PAGES_SENSITIVITY = "reader_double_pages_sensitivity_2"
		const val KEY_READER_DOUBLE_FOLDABLE = "reader_double_foldable"
		const val KEY_READER_ZOOM_BUTTONS = "reader_zoom_buttons"
		const val KEY_READER_CONTROL_LTR = "reader_taps_ltr"
		const val KEY_READER_NAVIGATION_INVERTED = "reader_navigation_inverted"
		const val KEY_READER_FULLSCREEN = "reader_fullscreen"
		const val KEY_READER_VOLUME_BUTTONS = "reader_volume_buttons"
		const val KEY_READER_ORIENTATION = "reader_orientation"
		const val KEY_TRACKER_ENABLED = "tracker_enabled"
		const val KEY_TRACKER_WIFI_ONLY = "tracker_wifi"
		const val KEY_TRACKER_FREQUENCY = "tracker_freq"
		const val KEY_TRACK_SOURCES = "track_sources"
		const val KEY_TRACKER_NO_NSFW = "tracker_no_nsfw"
		const val KEY_TRACKER_FAILURE_NOTIFICATION = "tracker_failed_notification"
		const val KEY_TRACKER_SMART_UPDATE = "tracker_smart_update"
		const val KEY_FEED_SWIPE_GESTURES = "feed_swipe_gestures"
		const val KEY_FEED_COUNTER_DOT = "feed_counter_dot"
		const val KEY_FEED_UNREAD_ONLY = "feed_unread_only"
		const val KEY_TRACKER_DOWNLOAD = "tracker_download"
		const val KEY_READER_ANIMATION = "reader_animation2"
		const val KEY_READER_CONTROLS = "reader_controls_order"
		const val KEY_READER_BAR_LAYOUT = "reader_bar_layout"
		const val KEY_NOVEL_BAR_LAYOUT = "novel_bar_layout"
		private const val KEY_READER_CONTROLS_LEGACY = "reader_controls"
		const val KEY_READER_MODE = "reader_mode"
		const val KEY_EXPLORE_NOVEL_TAB_FIRST = "explore_novel_tab_first"
		const val KEY_EPUB_FONT_SIZE = "epub_font_size"
		const val KEY_EPUB_FONT_FAMILY = "epub_font_family"
		const val KEY_EPUB_LINE_HEIGHT = "epub_line_height"
		const val KEY_EPUB_PARAGRAPH_SPACING = "epub_paragraph_spacing"
		const val KEY_EPUB_HORIZONTAL_PADDING = "epub_horizontal_padding"
		const val KEY_EPUB_VERTICAL_PADDING = "epub_vertical_padding"
		const val KEY_EPUB_TEXT_ALIGN = "epub_text_align"
		const val KEY_EPUB_READING_MODE = "epub_reading_mode"
		const val KEY_EPUB_RTL = "epub_rtl"
		const val KEY_EPUB_SCROLL_STYLE = "epub_scroll_style"
		const val KEY_EPUB_BACKGROUND_IMAGE = "epub_background_image"
		const val KEY_EPUB_BACKGROUND_BLUR = "epub_background_blur"
		const val KEY_EPUB_CUSTOM_PRESETS = "epub_custom_presets"
		const val KEY_EPUB_PAGED_TAP_GESTURES = "epub_paged_tap_gestures"
		const val KEY_EPUB_TTS_SPEED = "epub_tts_speed"
		const val KEY_EPUB_TTS_VOICE_NAME = "epub_tts_voice_name"
		const val KEY_EPUB_TTS_SLOT_VOICES = "epub_tts_slot_voices_"
		const val KEY_EPUB_TTS_ENABLED = "epub_tts_enabled"
		const val KEY_EPUB_TTS_FOLLOW = "epub_tts_follow"
		const val KEY_EPUB_TTS_AUTO_ADVANCE = "epub_tts_auto_advance"
		const val KEY_EPUB_TTS_VOICE = "epub_tts_voice_index"
		const val KEY_EPUB_TTS_PITCH = "epub_tts_pitch"
		const val KEY_EPUB_PUBLISHER_STYLE = "epub_publisher_style"
		const val KEY_EPUB_BIONIC_READING = "epub_bionic_reading"
		const val KEY_EPUB_THEME = "epub_theme"
		const val KEY_EPUB_LETTER_SPACING = "epub_letter_spacing"
		const val KEY_EPUB_PARAGRAPH_INDENT = "epub_paragraph_indent"
		const val KEY_EPUB_HYPHENATION = "epub_hyphenation"
		const val KEY_EPUB_CHAPTER_HEADER = "epub_chapter_header"
		const val KEY_EPUB_HEADER_NAME_ONLY = "epub_header_name_only"
		const val KEY_EPUB_REMOVE_REDUNDANCY = "epub_remove_redundancy"
		const val KEY_EPUB_MAX_TEXT_WIDTH = "epub_max_text_width"
		const val KEY_EPUB_CUSTOM_BACKGROUND_COLOR = "epub_custom_background_color"
		const val KEY_EPUB_CUSTOM_TEXT_COLOR = "epub_custom_text_color"
		const val KEY_EPUB_CUSTOM_HIGHLIGHT_COLOR = "epub_custom_highlight_color"
		const val KEY_EPUB_CUSTOM_FONT_NAME = "epub_custom_font_name"
		const val KEY_EPUB_CUSTOM_FONT_REVISION = "epub_custom_font_revision"
		const val EPUB_CUSTOM_FONT_FILE = "epub_custom_font"
		const val KEY_READER_MODE_DETECT = "reader_mode_detect"
		const val KEY_READER_CROP = "reader_crop"
		const val KEY_READER_ROTATE_WIDE = "reader_rotate_wide"
		const val KEY_READER_ROTATE_WIDE_INVERT = "reader_rotate_wide_invert"
		const val KEY_PROTECT_APP = "protect_app"
		const val KEY_PROTECT_APP_TIMEOUT = "protect_app_timeout"
		const val KEY_APP_PASSWORD = "app_password"
		const val KEY_APP_PASSWORD_SALT = "app_password_salt"
		private const val KEY_APP_PASSWORD_NUMERIC_OLD = "app_password_num"
		private const val KEY_PROTECT_APP_BIOMETRIC_OLD = "protect_app_bio"
		const val KEY_ZOOM_MODE = "zoom_mode"
		const val KEY_HISTORY_GROUPING = "history_grouping"
		const val KEY_UPDATED_GROUPING = "updated_grouping"
		const val KEY_PROGRESS_INDICATORS = "reading_indicator_enabled"
		const val KEY_DETAILS_UI = "details_ui"
		const val KEY_REVERSE_CHAPTERS = "reverse_chapters"
		const val KEY_GRID_VIEW_CHAPTERS = "grid_view_chapters"
		const val KEY_NOVEL_THROTTLE = "novel_throttle_enabled"
		const val KEY_NOVEL_BURST = "novel_requests_before_delay"
		const val KEY_NOVEL_DELAY = "novel_request_delay_ms"
		const val KEY_NOVEL_PARALLEL_UPDATES = "novel_parallel_updates"
		const val KEY_NOVEL_MASS_IMPORTS = "novel_concurrent_mass_imports"
		const val KEY_NOVEL_SKIP_ERRORS = "novel_skip_on_errors"
		const val KEY_NOVEL_OVERRIDES = "novel_delay_overrides"
		const val KEY_NOVEL_TRANSLATE = "novel_translation_enabled"
		const val KEY_NOVEL_TRANSLATE_ENGINE = "novel_translation_engine"
		const val KEY_NOVEL_TRANSLATE_SOURCE = "novel_translation_source_lang"
		const val KEY_NOVEL_TRANSLATE_TARGET = "novel_translation_target_lang"
		const val KEY_NOVEL_TRANSLATE_AUTO_DL = "novel_translation_auto_download"
		const val KEY_NOVEL_TRANSLATE_AUTO_DOWNLOADS = "novel_translation_auto_translate_downloads"
		const val KEY_SORT_CHAPTERS_BY_NAME = "sort_chapters_by_name_"
		const val KEY_SORT_CHAPTERS_BY_DATE = "sort_chapters_by_date_"
		const val KEY_DEFAULT_BROWSE_SORT = "default_browse_sort"
		const val KEY_INCOGNITO_NSFW = "incognito_nsfw"
		const val KEY_PAGES_NUMBERS = "pages_numbers"
		const val KEY_SCREENSHOTS_POLICY = "screenshots_policy"
		const val KEY_SUGGESTIONS = "suggestions"
		const val KEY_SUGGESTIONS_WIFI_ONLY = "suggestions_wifi"
		const val KEY_SUGGESTIONS_EXCLUDE_NSFW = "suggestions_exclude_nsfw"
		const val KEY_SUGGESTIONS_EXCLUDE_NOVELS = "suggestions_exclude_novels"
		const val KEY_SUGGESTIONS_EXCLUDE_MANGA = "suggestions_exclude_manga"
		const val KEY_SUGGESTIONS_EXCLUDE_ANIME = "suggestions_exclude_anime"
		const val KEY_SUGGESTIONS_EXCLUDE_TAGS = "suggestions_exclude_tags"
		const val KEY_SUGGESTIONS_NOTIFICATIONS = "suggestions_notifications"
		const val KEY_DOWNLOADS_METERED_NETWORK = "downloads_metered_network"
		const val KEY_DOWNLOADS_FORMAT = "downloads_format"
		const val KEY_ALL_FAVOURITES_VISIBLE = "all_favourites_visible"
		const val KEY_SHOW_EMPTY_MODE_CATEGORIES = "show_empty_mode_categories"
		const val KEY_DOH = "doh"
		const val KEY_MIHON_USER_AGENT = "mihon_user_agent"
		const val KEY_EXIT_CONFIRM = "exit_confirm"
		const val KEY_INCOGNITO_MODE = "incognito"
		const val KEY_READER_MULTITASK = "reader_multitask"
		const val KEY_READER_BAR = "reader_bar"
		const val KEY_CHAPTER_JUMP_DIALOG = "chapter_jump_dialog"
		const val KEY_READER_BACKGROUND = "reader_background"
		const val KEY_READER_SCREEN_ON = "reader_screen_on"
		const val KEY_READER_LONG_PRESS = "reader_long_press_actions"
		const val KEY_SHORTCUTS = "dynamic_shortcuts"
		const val KEY_READER_OPTIMIZE = "reader_optimize"
		const val KEY_READER_UPSCALE = "reader_upscale"
		const val KEY_LOCAL_LIST_ORDER = "local_order"
		const val KEY_HISTORY_ORDER = "history_order"
		const val KEY_FAVORITES_ORDER = "fav_order"
		const val KEY_CATEGORY_DEFAULT_ORDER = "category_default_order"
		const val KEY_CATEGORIES_ORDER = "categories_order"
		const val KEY_FAVORITES_PINNED = "fav_pinned_order_"
		const val KEY_WEBTOON_GAPS = "webtoon_gaps"
		const val KEY_WEBTOON_ZOOM = "webtoon_zoom"
		const val KEY_WEBTOON_ZOOM_OUT = "webtoon_zoom_out"
		const val KEY_WEBTOON_PULL_GESTURE = "webtoon_pull_gesture"
		const val KEY_PREFETCH_CONTENT = "prefetch_content"
		const val KEY_APP_LOCALE = "app_locale"
		const val KEY_SOURCES_GRID = "sources_grid"
		const val KEY_SOURCES_GRID_COLUMNS = "sources_grid_columns"
		const val KEY_TIPS_CLOSED = "tips_closed"
		const val KEY_SSL_BYPASS = "ssl_bypass"
		const val DEFAULT_AUTOSCROLL_SPEED = 0.5f
		const val DEFAULT_AUTOSCROLL_PAGE_DELAY = 5

		const val KEY_READER_AUTOSCROLL_SPEED = "as_speed"
		const val KEY_READER_AUTOSCROLL_PAGE_DELAY = "as_page_delay"
		const val KEY_READER_AUTOSCROLL_FAB = "as_fab"
		const val KEY_READER_TTS_FAB = "tts_fab"
		const val KEY_PROXY_TYPE = "proxy_type_2"
		const val KEY_PROXY_ADDRESS = "proxy_address"
		const val KEY_PROXY_PORT = "proxy_port"
		const val KEY_PROXY_LOGIN = "proxy_login"
		const val KEY_PROXY_PASSWORD = "proxy_password"
		const val KEY_IMAGES_PROXY = "images_proxy_2"
		const val KEY_LOCAL_MANGA_DIRS = "local_manga_dirs"
		const val KEY_CONTENT_FILTER = "content_filter"
		const val KEY_DISABLE_NSFW_LEGACY = "no_nsfw"
		const val KEY_RELATED_MANGA = "related_manga"
		const val KEY_SCROBBLING_PROGRESS_SYNC = "scrobbling_progress_sync"
		const val KEY_SCROBBLING_AUTO_LINK = "scrobbling_auto_link"
		const val KEY_NAV_MAIN = "nav_main"
		const val KEY_NAV_LABELS = "nav_labels"
		const val KEY_NAV_PINNED = "nav_pinned"
		const val KEY_NAV_LEGACY = "nav_legacy"
		const val KEY_BAR_BLUR = "bar_blur"
		const val KEY_MAIN_FAB = "main_fab"
		const val KEY_UPDATE_PROMPT_DISMISSED = "update_prompt_dismissed"
		const val KEY_32BIT_COLOR = "enhanced_colors"
		const val KEY_SOURCES_ORDER = "sources_sort_order"
		const val KEY_MIHON_PER_EXT_ACTIVE_LANG = "mihon_per_ext_active_lang"
		const val KEY_MIHON_HIDDEN_PACKAGES = "mihon_hidden_packages"
		const val KEY_HIDDEN_SOURCE_LANGUAGES = "hidden_source_languages"
		const val KEY_LN_HIDDEN_PLUGINS = "ln_hidden_plugins"
		const val KEY_EXTERNAL_EXTENSIONS_REPO_URL = "external_extensions_repo_url"
		const val KEY_MIHON_EXTENSION_REPOS = "mihon_extension_repos"
		const val KEY_MIHON_REPO_INFOS = "mihon_repo_infos"
		const val KEY_EXTENSION_STORE_REGISTRY = "extension_store_registry"
		const val KEY_EXTENSION_STORE_MIGRATED = "extension_store_migrated"
		const val KEY_CF_BRIGHTNESS = "cf_brightness"
		const val KEY_CF_CONTRAST = "cf_contrast"
		const val KEY_CF_INVERTED = "cf_inverted"
		const val KEY_CF_GRAYSCALE = "cf_grayscale"
		const val KEY_CF_BOOK = "cf_book"
		const val KEY_PAGES_TAB = "pages_tab"
		const val KEY_DETAILS_TAB = "details_tab"
		const val KEY_DETAILS_LAST_TAB = "details_last_tab"
		const val KEY_DETAILS_BACKDROP = "details_backdrop"
		const val KEY_DETAILS_BACKDROP_BLUR_AMOUNT = "details_backdrop_blur_amount"
		const val KEY_VERBOSE_LOGGING = "verbose_logging"
		const val KEY_READING_TIME = "reading_time"
		const val KEY_EYE_REMINDER = "eye_reminder"
		const val KEY_EYE_REMINDER_INTERVAL = "eye_reminder_interval"
		const val EYE_REMINDER_DEFAULT_INTERVAL = 20 * 60
		const val KEY_PAGES_SAVE_DIR = "pages_dir"
		const val KEY_PAGES_SAVE_ASK = "pages_dir_ask"
		const val KEY_STATS_ENABLED = "stats_on"
		const val KEY_WATCH_STATS_ENABLED = "watch_stats_on"
		const val KEY_SKIP_DUPLICATE_CHAPTERS = "skip_duplicate_chapters"
		const val KEY_SEARCH_SUGGESTION_TYPES = "search_suggest_types"
		const val KEY_QUICK_FILTER = "quick_filter"
		const val KEY_COLLAPSE_DESCRIPTION = "description_collapse"
		const val KEY_MANGA_LIST_BADGES = "manga_list_badges"
		const val KEY_NOVEL_SOURCE_IDS = "novel_source_ids"
		const val KEY_HOME_MODE = "home_mode"
		const val KEY_STREAMING_KIND = "streaming_kind"
		const val KEY_STREAMING_DEFAULT = "streaming_default"
		const val KEY_HOME_BANNER_STYLE = "home_banner_style"
		const val KEY_HOME_BANNER_ROTATE = "home_banner_rotate"
		const val KEY_HOME_HERO_SNAPSHOT = "home_hero_snapshot"
		const val KEY_HOME_METADATA = "home_metadata"
		const val KEY_HOME_PROVIDER = "home_metadata_provider"
		const val KEY_HOME_CATALOGUE = "home_source_catalogue"
		const val KEY_HOME_SOURCES_MANGA = "home_sources_manga"
		const val KEY_HOME_SOURCES_ANIME = "home_sources_anime"
		const val KEY_HOME_SOURCES_NOVEL = "home_sources_novel"
		const val KEY_HOME_GENRES_INCLUDE = "home_genres_include"
		const val KEY_HOME_GENRES_EXCLUDE = "home_genres_exclude"
		const val KEY_HOME_HIDE_NSFW = "home_hide_nsfw"
		const val KEY_METADATA_FROM_TRACKER = "metadata_from_tracker"
		const val KEY_HOME_FAV_CATEGORIES = "home_fav_categories"
		const val KEY_MODE_OVERRIDES_ENABLED = "mode_overrides_enabled"
		const val KEY_HOME_HIDDEN_CAROUSELS = "home_hidden_carousels"
		const val KEY_HOME_PER_MODE = "home_per_mode"
		const val KEY_UPDATES_ALL_MODES = "updates_all_modes"
		const val KEY_FEED_ALL_MODES = "feed_all_modes"
		const val KEY_HISTORY_ALL_MODES = "history_all_modes"
		const val KEY_SUGGESTIONS_SOURCE = "suggestions_source"
		const val KEY_EXPLORE_PROVIDER = "explore_metadata_provider"
		const val KEY_EXPLORE_INFO_TRACKER = "explore_info_from_tracker"

		/** Separates a per-mode Home setting's key from the mode it belongs to: `home_hidden_carousels__anime`. */
		private const val PER_MODE_SEPARATOR = "__"

		/** The Home settings that [isHomePerMode] splits by mode. */
		private val PER_MODE_KEYS = setOf(
			KEY_HOME_BANNER_STYLE, KEY_HOME_BANNER_ROTATE, KEY_HOME_PROVIDER, KEY_HOME_CATALOGUE,
			KEY_METADATA_FROM_TRACKER, KEY_HOME_GENRES_INCLUDE, KEY_HOME_GENRES_EXCLUDE, KEY_HOME_HIDE_NSFW,
			KEY_HOME_FAV_CATEGORIES, KEY_HOME_HIDDEN_CAROUSELS,
			// Settings > Override global defaults
			KEY_EXPLORE_NOVEL_TAB_FIRST, KEY_EXPLORE_DISCOVER_DEFAULT, KEY_EXPLORE_LIST_VIEW,
			KEY_EXPLORE_PROVIDER, KEY_EXPLORE_INFO_TRACKER,
			KEY_SHOW_EMPTY_MODE_CATEGORIES,
			KEY_UPDATES_ALL_MODES, KEY_FEED_ALL_MODES, KEY_HISTORY_ALL_MODES, KEY_SUGGESTIONS_SOURCE,
			KEY_RELATED_MANGA, KEY_STATS_ENABLED, KEY_WATCH_STATS_ENABLED, KEY_READING_TIME,
			KEY_SCROBBLING_PROGRESS_SYNC, KEY_SCROBBLING_AUTO_LINK, KEY_SCROBBLING_ASK,
			KEY_SCROBBLING_AUTO_TRACK_BEST, KEY_TRACKER_AUTO_SYNC,
		)

		/** The switches of [ModeOverrideArea]: flipping one, or changing the mode, changes what every per-mode setting reads as. */
		private val OVERRIDE_SWITCH_KEYS: Set<String> = ModeOverrideArea.entries.mapTo(HashSet()) { it.key }

		fun perModeKey(base: String, mode: HomeMode): String = base + PER_MODE_SEPARATOR + mode.name.lowercase()

		/**
		 * Whether a preference change reported as [changed] concerns [key]: the key itself, its per-mode
		 * copy (so observers of the shared key keep working), or the per-mode switch / the mode itself, which
		 * change what every per-mode setting reads as.
		 */
		fun isChangeOf(changed: String?, key: String): Boolean = changed == key ||
			(changed != null && changed.startsWith(key + PER_MODE_SEPARATOR)) ||
			((changed == KEY_HOME_MODE || (changed != null && changed in OVERRIDE_SWITCH_KEYS)) && key in PER_MODE_KEYS)
		const val KEY_SCROBBLING_ASK = "scrobbling_ask"
		const val KEY_TRACKER_AUTO_SYNC = "tracker_auto_sync"
		const val KEY_TRACKER_LAST_SYNC = "tracker_last_sync"
		const val KEY_SCROBBLING_AUTO_TRACK_BEST = "scrobbling_auto_track_best"
		const val KEY_SCROBBLING_NEVER_ASK = "scrobbling_never_ask"

		fun homeSourcesKey(mode: HomeMode): String =
			when (mode) {
				HomeMode.NOVEL -> KEY_HOME_SOURCES_NOVEL
				HomeMode.ANIME -> KEY_HOME_SOURCES_ANIME
				else -> KEY_HOME_SOURCES_MANGA
			}

		const val KEY_GLOBAL_SEARCH_NOVEL_SCOPE = "global_search_novel_scope"
		const val KEY_GLOBAL_SEARCH_TRACKERS = "global_search_trackers"
		const val KEY_EXPLORE_DISCOVER_DEFAULT = "explore_discover_default"
		const val KEY_EXPLORE_LIST_VIEW = "explore_list_view"
		const val KEY_SEARCH_PINNED_ONLY = "search_pinned_only"
		const val KEY_SEARCH_LOCAL_ONLY = "search_local_only"
		const val KEY_SHIZUKU_INSTALLER = "shizuku_installer"
		const val KEY_PRIVATE_INSTALLER = "private_installer"
		const val KEY_AUTO_UPDATE_EXTENSIONS = "auto_update_extensions"
		const val KEY_EXTENSION_UPDATE_NOTIFICATIONS = "extension_update_notifications"
		const val KEY_EXTENSION_UPDATES_AVAILABLE = "extension_updates_available"
		const val KEY_LAST_EXTENSION_UPDATE_NOTIFICATION_TIME = "last_extension_update_notification_time"
		const val KEY_DISCORD_RPC = "discord_rpc"
		const val KEY_DISCORD_RPC_SKIP_NSFW = "discord_rpc_skip_nsfw"
		const val KEY_DISCORD_TOKEN = "discord_token"
		const val KEY_WEBHOOKS_ENABLED = "webhooks_enabled"
		const val KEY_WEBHOOK_DISCORD_URL = "webhook_discord_url"
		const val KEY_WEBHOOK_JSON_URL = "webhook_json_url"
		const val KEY_WEBHOOK_EVENT_LIBRARY = "webhook_event_library"
		const val KEY_WEBHOOK_EVENT_SYNC = "webhook_event_sync"
		const val KEY_WEBHOOK_EVENT_BACKUP = "webhook_event_backup"
		const val KEY_ONBOARDING_COMPLETED = "onboarding_completed"
		const val KEY_ONBOARDING_INSTALL_ID = "onboarding_install_id"

		/**
		 * Keys that must never leave the device: credentials, app-lock state and per-install ids.
		 * Stripped from local backups and cloud sync, both when writing and when applying.
		 */
		val SENSITIVE_BACKUP_KEYS = setOf(
			KEY_APP_PASSWORD,
			KEY_APP_PASSWORD_SALT,
			KEY_APP_PASSWORD_NUMERIC_OLD,
			KEY_PROTECT_APP,
			KEY_PROTECT_APP_TIMEOUT,
			KEY_PROTECT_APP_BIOMETRIC_OLD,
			KEY_PROXY_PASSWORD,
			KEY_PROXY_LOGIN,
			KEY_INCOGNITO_MODE,
			KEY_ONBOARDING_COMPLETED,
			KEY_ONBOARDING_INSTALL_ID,
			// Webhook URLs are secrets and stay on this device: never in a backup or in cloud sync.
			KEY_WEBHOOKS_ENABLED,
			KEY_WEBHOOK_DISCORD_URL,
			KEY_WEBHOOK_JSON_URL,
			KEY_WEBHOOK_EVENT_LIBRARY,
			KEY_WEBHOOK_EVENT_SYNC,
			KEY_WEBHOOK_EVENT_BACKUP,
		)

		/**
		 * Kept out of Drive sync (but not backups): every user-facing setting syncs except app lock
		 * ([SENSITIVE_BACKUP_KEYS]). What stays here only makes sense on this device (storage folders,
		 * installer capabilities, a font file) or is written by the app itself (caches, one-shot flags),
		 * where syncing would make background writes look like user edits.
		 */
		private val SYNC_LOCAL_KEYS = setOf(
			KEY_UI_SCALE_RESET,
			KEY_NAV_PINNED_RESET,
			KEY_LOCAL_STORAGE,
			KEY_LOCAL_MANGA_DIRS,
			KEY_PAGES_SAVE_DIR,
			KEY_EPUB_CUSTOM_FONT_NAME,
			KEY_EPUB_CUSTOM_FONT_REVISION,
			KEY_BACKUP_PERIODICAL_ENABLED,
			KEY_BACKUP_PERIODICAL_OUTPUT,
			KEY_BACKUP_PERIODICAL_FREQ,
			KEY_BACKUP_PERIODICAL_TRIM,
			KEY_BACKUP_PERIODICAL_COUNT,
			KEY_SHIZUKU_INSTALLER,
			KEY_PRIVATE_INSTALLER,
			KEY_DISCORD_TOKEN,
			KEY_EXTENSION_UPDATES_AVAILABLE,
			KEY_LAST_EXTENSION_UPDATE_NOTIFICATION_TIME,
			KEY_TRACKER_LAST_SYNC,
			KEY_MIHON_REPO_INFOS,
			KEY_EXTENSION_STORE_REGISTRY, // synced store by store instead (SyncedStores)
			KEY_EXTENSION_STORE_MIGRATED,
			KEY_NOVEL_SOURCE_IDS,
			KEY_DETAILS_LAST_TAB,
			KEY_APP_VERSION,
			KEY_UPDATE_PROMPT_DISMISSED,
			KEY_PRELOAD_POLICIES_RESET,
		)

		fun isSyncableKey(key: String): Boolean = key !in SENSITIVE_BACKUP_KEYS &&
			key !in SYNC_LOCAL_KEYS &&
			!key.startsWith(KEY_LIST_CHECKPOINT + '_') // per-list scroll positions

		// keys for non-persistent preferences
		const val KEY_APP_VERSION = "app_version"
		const val KEY_CLEAR_MANGA_DATA = "manga_data_clear"
		const val KEY_WEBVIEW_CLEAR = "webview_clear"
		const val KEY_BACKUP_PERIODICAL_ENABLED = "backup_periodic"
		const val KEY_BACKUP_PERIODICAL_OUTPUT = "backup_periodic_output"
		const val KEY_BACKUP_PERIODICAL_FREQ = "backup_periodic_freq"
		const val KEY_BACKUP_PERIODICAL_TRIM = "backup_periodic_trim"
		const val KEY_BACKUP_PERIODICAL_COUNT = "backup_periodic_count"

		// old keys are for migration only
		private const val KEY_IMAGES_PROXY_OLD = "images_proxy"
		private const val KEY_PRELOAD_POLICIES_RESET = "preload_policies_reset_v1"
		private const val KEY_NAV_PINNED_RESET = "nav_pinned_reset_v1"

		// values
		private const val READER_CROP_PAGED = 1
		private const val READER_CROP_WEBTOON = 2
	}
}
