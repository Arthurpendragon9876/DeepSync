package org.koitharu.kotatsu.favourites.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RawQuery
import androidx.room.RoomWarnings
import androidx.room.Upsert
import androidx.sqlite.db.SimpleSQLiteQuery
import androidx.sqlite.db.SupportSQLiteQuery
import kotlinx.coroutines.flow.Flow
import org.koitharu.kotatsu.favourites.domain.model.CategoriesOrder

@Dao
abstract class FavouriteCategoriesDao {

	@Query("SELECT * FROM favourite_categories WHERE category_id = :id AND deleted_at = 0")
	abstract suspend fun find(id: Int): FavouriteCategoryEntity

	@Query("SELECT * FROM favourite_categories WHERE deleted_at = 0 ORDER BY sort_key")
	abstract suspend fun findAll(): List<FavouriteCategoryEntity>

	/** All rows INCLUDING soft-deleted tombstones — used by cloud sync to propagate deletions. */
	@Query("SELECT * FROM favourite_categories")
	abstract suspend fun findAllForSync(): List<FavouriteCategoryEntity>

	suspend fun findAll(order: CategoriesOrder): List<FavouriteCategoryEntity> =
		findAllImpl(buildQuery(order, onlyVisible = false))

	fun observeAll(order: CategoriesOrder, onlyVisible: Boolean): Flow<List<FavouriteCategoryEntity>> =
		observeAllImpl(buildQuery(order, onlyVisible))

	@Query("SELECT * FROM favourite_categories WHERE category_id = :id AND deleted_at = 0")
	abstract fun observe(id: Long): Flow<FavouriteCategoryEntity?>

	@Insert(onConflict = OnConflictStrategy.ABORT)
	abstract suspend fun insert(category: FavouriteCategoryEntity): Long

	suspend fun delete(id: Long) = setDeletedAt(id, System.currentTimeMillis())

	@Query("UPDATE favourite_categories SET title = :title, `order` = :order, `track` = :tracker, download_new_chapters = :downloadNewChapters, `show_in_lib` = :onShelf WHERE category_id = :id")
	abstract suspend fun update(
		id: Long,
		title: String,
		order: String,
		tracker: Boolean,
		downloadNewChapters: Boolean,
		onShelf: Boolean,
	)

	@Query("UPDATE favourite_categories SET `order` = :order WHERE category_id = :id")
	abstract suspend fun updateOrder(id: Long, order: String)

	@Query("UPDATE favourite_categories SET `order` = :order WHERE deleted_at = 0")
	abstract suspend fun updateOrderForAll(order: String)

	@Query("UPDATE favourite_categories SET `track` = :isEnabled WHERE category_id = :id")
	abstract suspend fun updateTracking(id: Long, isEnabled: Boolean)

	@Query("UPDATE favourite_categories SET download_new_chapters = :isEnabled WHERE category_id = :id")
	abstract suspend fun updateNewChaptersDownload(id: Long, isEnabled: Boolean)

	@Query("UPDATE favourite_categories SET `show_in_lib` = :isEnabled WHERE category_id = :id")
	abstract suspend fun updateVisibility(id: Long, isEnabled: Boolean)

	@Query("UPDATE favourite_categories SET sort_key = :sortKey WHERE category_id = :id")
	abstract suspend fun updateSortKey(id: Long, sortKey: Int)

	@Query("DELETE FROM favourite_categories WHERE deleted_at != 0 AND deleted_at < :maxDeletionTime")
	abstract suspend fun gc(maxDeletionTime: Long)

	@Query("SELECT MAX(sort_key) FROM favourite_categories WHERE deleted_at = 0")
	protected abstract suspend fun getMaxSortKey(): Int?

	@Query("UPDATE favourite_categories SET download_new_chapters = 0 WHERE deleted_at = 0")
	abstract suspend fun clearNewChaptersDownload()

	@Query("UPDATE favourite_categories SET download_new_chapters = 1 WHERE `track` = 1 AND deleted_at = 0")
	abstract suspend fun enableNewChaptersDownloadForTracked()

	@SuppressWarnings(RoomWarnings.QUERY_MISMATCH) // for the new_chapters column
	@Query("SELECT favourite_categories.*, (SELECT SUM(chapters_new) FROM tracks WHERE tracks.manga_id IN (SELECT manga_id FROM favourites WHERE favourites.category_id = favourite_categories.category_id)) AS new_chapters FROM favourite_categories WHERE track = 1 AND show_in_lib = 1 AND deleted_at = 0 AND new_chapters > 0 ORDER BY new_chapters DESC LIMIT :limit")
	abstract suspend fun getMostUpdatedCategories(limit: Int): List<FavouriteCategoryEntity>

	suspend fun getNextSortKey(): Int {
		return (getMaxSortKey() ?: 0) + 1
	}

	@Upsert
	abstract suspend fun upsert(entity: FavouriteCategoryEntity)

	@Query("UPDATE favourite_categories SET deleted_at = :deletedAt WHERE category_id = :id")
	protected abstract suspend fun setDeletedAt(id: Long, deletedAt: Long)

	// favourites is observed too: the size order changes as manga are added or removed
	@RawQuery(observedEntities = [FavouriteCategoryEntity::class, FavouriteEntity::class])
	protected abstract fun observeAllImpl(query: SupportSQLiteQuery): Flow<List<FavouriteCategoryEntity>>

	@RawQuery
	protected abstract suspend fun findAllImpl(query: SupportSQLiteQuery): List<FavouriteCategoryEntity>

	private fun buildQuery(order: CategoriesOrder, onlyVisible: Boolean): SupportSQLiteQuery {
		val direction = if (order.isAscending) "ASC" else "DESC"
		val orderBy = when (order.type) {
			CategoriesOrder.Type.RANDOM -> "sort_key"
			CategoriesOrder.Type.NAME -> "title COLLATE NOCASE $direction, sort_key"
			CategoriesOrder.Type.SIZE -> "(SELECT COUNT(*) FROM favourites WHERE favourites.category_id = " +
				"favourite_categories.category_id AND favourites.deleted_at = 0) $direction, sort_key"

			CategoriesOrder.Type.CREATED -> "created_at $direction, sort_key"
		}
		val visibility = if (onlyVisible) " AND show_in_lib = 1" else ""
		return SimpleSQLiteQuery("SELECT * FROM favourite_categories WHERE deleted_at = 0$visibility ORDER BY $orderBy")
	}
}
