package org.koitharu.kotatsu.search.ui.multi

import android.app.Activity
import android.os.Build
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import org.koitharu.kotatsu.core.ui.menu.MenuPopup
import androidx.core.view.MenuProvider
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.nav.router
import org.koitharu.kotatsu.search.domain.SearchKind

class SearchMenuProvider(
	private val activity: SearchActivity,
	private val viewModel: SearchViewModel,
) : MenuProvider {

	override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
		menuInflater.inflate(R.menu.opt_search_kind, menu)
	}

	override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
		if (menuItem.itemId == R.id.action_search_kind) {
			// Shown by hand instead of as a <menu> submenu: a submenu of an action bar item pops up
			// without an anchor, so it lands and animates from the wrong spot. Every other overflow
			// in the app goes through MenuPopup on its own button.
			activity.findViewById<View>(R.id.action_search_kind)?.let(::showFilterPopup)
			return true
		}
		when (menuItem.itemId) {
			R.id.action_filter_pinned_only -> {
				menuItem.isChecked = !menuItem.isChecked
				viewModel.setPinnedOnly(menuItem.isChecked)
				return true
			}

			R.id.action_filter_local_only -> {
				menuItem.isChecked = !menuItem.isChecked
				viewModel.setLocalOnly(menuItem.isChecked)
				return true
			}
		}

		val newKind = when (menuItem.itemId) {
			R.id.action_kind_simple -> SearchKind.SIMPLE
			R.id.action_kind_title -> SearchKind.TITLE
			R.id.action_kind_author -> SearchKind.AUTHOR
			R.id.action_kind_tag -> SearchKind.TAG
			else -> return false
		}
		if (newKind != viewModel.kind) {
			activity.router.openSearch(
				query = viewModel.query,
				kind = newKind,
			)
			activity.overrideSearchKindTransition()
			activity.finishAfterTransition()
		}
		return true
	}

	private fun showFilterPopup(anchor: View) {
		val popup = MenuPopup(anchor)
		popup.inflate(R.menu.popup_search_kind)
		val menu = popup.menu
		menu.findItem(
			when (viewModel.kind) {
				SearchKind.SIMPLE -> R.id.action_kind_simple
				SearchKind.TITLE -> R.id.action_kind_title
				SearchKind.AUTHOR -> R.id.action_kind_author
				SearchKind.TAG -> R.id.action_kind_tag
			},
		)?.isChecked = true
		menu.findItem(R.id.action_filter_pinned_only)?.run {
			isChecked = viewModel.isPinnedOnly
			// Pinned sources are not searched at all in local-only mode.
			isEnabled = !viewModel.isLocalOnly
		}
		menu.findItem(R.id.action_filter_local_only)?.isChecked = viewModel.isLocalOnly
		popup.setOnMenuItemClickListener(::onMenuItemSelected)
		popup.show()
	}

	private fun SearchActivity.overrideSearchKindTransition() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
			overrideActivityTransition(
				Activity.OVERRIDE_TRANSITION_OPEN,
				R.anim.m3_fade_through_enter,
				R.anim.m3_fade_through_exit,
			)
		} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			@Suppress("DEPRECATION")
			overridePendingTransition(
				R.anim.m3_fade_through_enter,
				R.anim.m3_fade_through_exit,
				0,
			)
		} else {
			@Suppress("DEPRECATION")
			overridePendingTransition(
				R.anim.m3_fade_through_enter,
				R.anim.m3_fade_through_exit,
			)
		}
	}
}
