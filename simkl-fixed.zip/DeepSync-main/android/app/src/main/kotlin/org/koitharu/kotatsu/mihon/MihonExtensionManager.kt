package org.koitharu.kotatsu.mihon

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import eu.kanade.tachiyomi.source.CatalogueSource
import eu.kanade.tachiyomi.source.Source
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.koitharu.kotatsu.extensions.runtime.ExternalExtensionManagerFacade
import org.koitharu.kotatsu.mihon.model.MihonLoadResult
import org.koitharu.kotatsu.mihon.model.MihonMangaSource
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.observeAsFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MihonExtensionManager @Inject constructor(
	@ApplicationContext private val context: Context,
	private val loader: MihonExtensionLoader,
	private val settings: AppSettings,
) {

	companion object {
		@Volatile
		private var activeInstance: MihonExtensionManager? = null

		fun getById(sourceId: Long): MihonMangaSource? = activeInstance?.getMihonMangaSourceById(sourceId)

		fun getByName(name: String): MihonMangaSource? = activeInstance?.getMihonMangaSourceByName(name)

		/**
		 * Whether a source id belongs to a novel extension, answerable before extensions finish
		 * loading. Falls back to the remembered ids from the previous scan.
		 */
		fun isNovelSourceId(sourceId: Long): Boolean {
			val instance = activeInstance ?: return false
			instance.getMihonMangaSourceById(sourceId)?.let { return it.isNovel }
			return sourceId in instance.knownNovelSourceIds
		}
	}

	/** Snapshot of [AppSettings.novelSourceIds], refreshed after every extension scan. */
	@Volatile
	private var knownNovelSourceIds: Set<Long> = settings.novelSourceIds

	private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
	private val refreshMutex = Mutex()

	private val facade = ExternalExtensionManagerFacade<
		MihonLoadResult,
		MihonLoadResult.Success,
		MihonLoadResult.Error,
		Source,
		CatalogueSource,
		MihonMangaSource,
	>(
		context = context,
		scope = scope,
		loadResults = { ctx -> loader.loadExtensions(ctx, settings.isPrivateInstallEnabled) },
		isExtensionPackage = { ctx, pkgName -> MihonExtensionLoader.isExtensionPackage(ctx, pkgName) },
		successOf = { it as? MihonLoadResult.Success },
		errorOf = { it as? MihonLoadResult.Error },
		untrustedPackageNameOf = { (it as? MihonLoadResult.Untrusted)?.pkgName },
		successSources = { it.sources },
		successPackageName = { it.pkgName },
		successContentWarning = { it.contentWarning },
		successCatalogueSources = { it.catalogueSources },
		sourceId = { it.id },
		asCatalogueSource = { it as? CatalogueSource },
		catalogueSourceName = { it.name },
		catalogueSourceLang = { it.lang },
		buildWrappedSource = { catalogueSource, pkgName, contentWarning, hasLanguageSuffix ->
			MihonMangaSource(catalogueSource, pkgName, contentWarning, hasLanguageSuffix)
		},
		sourceNamePrefix = "MIHON_",
		errorPackageName = { it.pkgName },
		errorMessage = { it.message },
		errorThrowable = { it.exception },
	)

	val installedExtensions: StateFlow<List<MihonLoadResult.Success>> = facade.installedExtensions
	val failedExtensions: StateFlow<List<MihonLoadResult.Error>> = facade.failedExtensions
	val isLoading: StateFlow<Boolean> = facade.isLoading
	val isReady: StateFlow<Boolean> = facade.isReady

	init {
		activeInstance = this
		scope.launch {
			settings.observeAsFlow(AppSettings.KEY_PRIVATE_INSTALLER) { isPrivateInstallEnabled }
				.drop(1)
				.collect {
					loadExtensions()
				}
		}
	}

	fun initialize() {
		facade.initialize()
	}

	suspend fun loadExtensions() {
		refreshMutex.withLock {
			facade.loadExtensions()
			rememberNovelSources()
		}
	}

	private fun rememberNovelSources() {
		val ids = facade.getWrappedSources().filter { it.isNovel }.mapTo(HashSet()) { it.sourceId }
		knownNovelSourceIds = ids
		if (settings.novelSourceIds != ids) {
			settings.novelSourceIds = ids
		}
	}

	suspend fun ensureReady(forceRefresh: Boolean = false) {
		initialize()
		if (forceRefresh) {
			loadExtensions()
			return
		}
		if (!isReady.value && !isLoading.value) {
			loadExtensions()
		}
		if (isLoading.value) {
			isLoading.filter { !it }.first()
		}
		if (!isReady.value) {
			loadExtensions()
		}
	}

	fun getCatalogueSources(): List<CatalogueSource> = facade.getCatalogueSources()

	fun getMihonMangaSources(): List<MihonMangaSource> = facade.getWrappedSources()

	fun getSourceById(sourceId: Long): Source? = facade.getSourceById(sourceId)

	fun getCatalogueSourceById(sourceId: Long): CatalogueSource? = facade.getCatalogueSourceById(sourceId)

	fun getMihonMangaSourceById(sourceId: Long): MihonMangaSource? = facade.getWrappedSourceById(sourceId)

	fun getMihonMangaSourceByName(name: String): MihonMangaSource? {
		val exact = facade.getWrappedSourceByName(name)
		if (exact != null) return exact
		val sourceId = name.removePrefix("MIHON_").substringBefore(':').toLongOrNull() ?: return null
		return facade.getWrappedSourceById(sourceId)
	}

	fun getSourcesByLanguage(): Map<String, List<CatalogueSource>> = facade.getSourcesByLanguage()

	fun getSourceCount(): Int = facade.getSourceCount()

	fun hasExtensions(): Boolean = facade.hasExtensions()
}
