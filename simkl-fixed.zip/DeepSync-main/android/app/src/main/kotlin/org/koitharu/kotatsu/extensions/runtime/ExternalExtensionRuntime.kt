package org.koitharu.kotatsu.extensions.runtime

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Locale
import org.koitharu.kotatsu.core.model.ContentWarning

/**
 * The BCP-47 code for an extension's declared language, or null if it isn't one we can resolve.
 *
 * Mihon indexes declare codes ("en", "pt-BR"); LNReader indexes declare names, either English
 * ("English") or the autonym ("português (Brasil)"). Everything downstream — the catalog's language
 * filter above all — compares codes, so names have to be looked back up.
 */
fun getExternalExtensionLangCodeOrNull(lang: String): String? {
	val value = lang.trim().trim('‎', '‏')
	return when {
		value.isEmpty() -> null
		// A code has to look like one. Length alone isn't enough: "ไทย" is three chars and Android turns
		// any unknown 2-8 letter subtag into the label "Various languages" instead of failing.
		LANG_CODE_REGEX matches value -> value
		else -> langCodesByName[value.lowercase(Locale.ROOT)]
	}
}

private val LANG_CODE_REGEX = Regex("[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})*")

/** Same, falling back to the declared value so an unknown language still filters consistently. */
fun getExternalExtensionLangCode(lang: String): String = getExternalExtensionLangCodeOrNull(lang) ?: lang

/** Display label for a language declared as either a code or a name. */
fun getExternalExtensionLanguageLabel(lang: String): String =
	getExternalExtensionLangCodeOrNull(lang)?.let(::getExternalExtensionLanguageDisplayName) ?: lang

/**
 * The exact set of names LNReader plugins can declare, from its `languagesMapping` table
 * (`src/utils/constants/languages.ts`). Most are autonyms Android's own locale data does not produce
 * verbatim — comma-separated lists ("中文, 汉语, 漢語"), or a different wording ("Bahasa Indonesia" vs
 * Android's "Indonesia") — so they are matched from this table first and the locale sweep below only
 * covers names from other index formats.
 *
 * Note LNReader keys Arabic as "ab" (Abkhazian) in that file; the name is what plugins ship, and it
 * maps to the correct code here.
 */
private val LNREADER_LANG_CODES = mapOf(
	"bahasa indonesia" to "id",
	"english" to "en",
	"español" to "es",
	"français" to "fr",
	"polski" to "pl",
	"português" to "pt",
	"tiếng việt" to "vi",
	"türkçe" to "tr",
	"русский" to "ru",
	"українська" to "uk",
	"العربية" to "ar",
	"ไทย" to "th",
	"中文, 汉语, 漢語" to "zh",
	"日本語" to "ja",
	"조선말, 한국어" to "ko",
	"multi" to "all",
)

private val langCodesByName: Map<String, String> by lazy {
	val map = HashMap<String, String>(LNREADER_LANG_CODES)
	for (locale in Locale.getAvailableLocales()) {
		if (locale.language.isEmpty()) continue
		// Language-only names first ("Portuguese"), then the country-qualified ones ("Portuguese
		// (Brazil)"), whose value has to keep the region so it matches Mihon's "pt-BR".
		map.putIfAbsent(locale.getDisplayLanguage(Locale.ENGLISH).lowercase(Locale.ROOT), locale.language)
		map.putIfAbsent(locale.getDisplayLanguage(locale).lowercase(Locale.ROOT), locale.language)
		map.putIfAbsent(locale.getDisplayName(Locale.ENGLISH).lowercase(Locale.ROOT), locale.toLanguageTag())
		map.putIfAbsent(locale.getDisplayName(locale).lowercase(Locale.ROOT), locale.toLanguageTag())
	}
	map
}

fun getExternalExtensionLanguageDisplayName(langCode: String): String {
	return when (langCode.lowercase(Locale.ROOT)) {
		"all" -> "Multi"
		else -> runCatching { Locale.forLanguageTag(langCode).getDisplayLanguage(Locale.getDefault()) }
			.getOrNull()
			?.takeIf { it.isNotBlank() }
			?: langCode.uppercase(Locale.ROOT)
	}
}

/**
 * Returns the language's own name (autonym) — e.g. "Français", "日本語", "Español" — instead of
 * the name translated into the device language. Used wherever an extension's language is shown
 * natively (source settings language picker, browse top-bar subheading).
 */
fun getExternalExtensionLanguageAutonym(langCode: String): String {
	return when (langCode.lowercase(Locale.ROOT)) {
		"all" -> "Multi"
		else -> runCatching {
			val locale = Locale.forLanguageTag(langCode)
			locale.getDisplayLanguage(locale).replaceFirstChar { it.uppercase(locale) }
		}.getOrNull()
			?.takeIf { it.isNotBlank() }
			?: langCode.uppercase(Locale.ROOT)
	}
}

fun registerExternalExtensionPackageObserver(
	context: Context,
	scope: CoroutineScope,
	isRelevantPackage: (String) -> Boolean,
	onPackageChanged: suspend () -> Unit,
): BroadcastReceiver {
	val receiver = object : BroadcastReceiver() {
		override fun onReceive(context: Context?, intent: Intent?) {
			val pkgName = intent?.data?.schemeSpecificPart
			// Like Mihon, only extension packages matter: any app update on the device used to
			// trigger a full extension reload while the user was browsing.
			scope.launch {
				if (pkgName == null || isRelevantPackage(pkgName)) {
					onPackageChanged()
				}
			}
		}
	}
	ContextCompat.registerReceiver(
		context,
		receiver,
		IntentFilter().apply {
			addAction(Intent.ACTION_PACKAGE_ADDED)
			addAction(Intent.ACTION_PACKAGE_REPLACED)
			addAction(Intent.ACTION_PACKAGE_REMOVED)
			addAction(Intent.ACTION_PACKAGE_FULLY_REMOVED)
			addDataScheme("package")
		},
		ContextCompat.RECEIVER_EXPORTED,
	)
	return receiver
}

data class ProcessedExternalExtensions<SuccessT, ErrorT, SourceT, WrappedSourceT>(
	val successful: List<SuccessT>,
	val failed: List<ErrorT>,
	val sourceById: Map<Long, SourceT>,
	val wrappedSourceById: Map<Long, WrappedSourceT>,
	val untrustedPackages: List<String>,
)

fun <ResultT, SuccessT, ErrorT, SourceT, CatalogueSourceT : SourceT, WrappedSourceT> processExternalExtensionResults(
	results: List<ResultT>,
	successOf: (ResultT) -> SuccessT?,
	errorOf: (ResultT) -> ErrorT?,
	untrustedPackageNameOf: (ResultT) -> String?,
	successSources: (SuccessT) -> List<SourceT>,
	successPackageName: (SuccessT) -> String,
	successContentWarning: (SuccessT) -> ContentWarning,
	sourceId: (SourceT) -> Long,
	asCatalogueSource: (SourceT) -> CatalogueSourceT?,
	catalogueSourceName: (CatalogueSourceT) -> String,
	buildWrappedSource: (CatalogueSourceT, String, ContentWarning, Boolean) -> WrappedSourceT,
	onError: (ErrorT) -> Unit = {},
	onUntrusted: (String) -> Unit = {},
): ProcessedExternalExtensions<SuccessT, ErrorT, SourceT, WrappedSourceT> {
	val successful = mutableListOf<SuccessT>()
	val failed = mutableListOf<ErrorT>()
	val sourceById = linkedMapOf<Long, SourceT>()
	val catalogueSources = mutableListOf<Triple<CatalogueSourceT, String, ContentWarning>>()
	val untrustedPackages = mutableListOf<String>()

	results.forEach { result ->
		val success = successOf(result)
		val error = errorOf(result)
		val untrustedPackage = untrustedPackageNameOf(result)
		when {
			success != null -> {
				successful += success
				successSources(success).forEach { source ->
					sourceById[sourceId(source)] = source
					asCatalogueSource(source)?.let {
						catalogueSources += Triple(it, successPackageName(success), successContentWarning(success))
					}
				}
			}
			error != null -> {
				failed += error
				onError(error)
			}
			untrustedPackage != null -> {
				untrustedPackages += untrustedPackage
				onUntrusted(untrustedPackage)
			}
		}
	}

	val nameCount = catalogueSources.groupingBy { catalogueSourceName(it.first) }.eachCount()
	val wrappedSourceById = linkedMapOf<Long, WrappedSourceT>()
	catalogueSources.forEach { (catalogueSource, pkgName, contentWarning) ->
		wrappedSourceById[sourceId(catalogueSource)] = buildWrappedSource(
			catalogueSource,
			pkgName,
			contentWarning,
			(nameCount[catalogueSourceName(catalogueSource)] ?: 0) > 1,
		)
	}

	return ProcessedExternalExtensions(successful, failed, sourceById, wrappedSourceById, untrustedPackages)
}

class ExternalExtensionManagerRuntime<ResultT, SuccessT, ErrorT, SourceT, WrappedSourceT>(
	private val context: Context,
	private val scope: CoroutineScope,
) {
	private val _installedExtensions = MutableStateFlow<List<SuccessT>>(emptyList())
	val installedExtensions: StateFlow<List<SuccessT>> = _installedExtensions.asStateFlow()

	private val _failedExtensions = MutableStateFlow<List<ErrorT>>(emptyList())
	val failedExtensions: StateFlow<List<ErrorT>> = _failedExtensions.asStateFlow()

	private val _isLoading = MutableStateFlow(false)
	val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

	private val _isReady = MutableStateFlow(false)
	val isReady: StateFlow<Boolean> = _isReady.asStateFlow()

	// Package broadcasts refresh on an IO coroutine while repositories resolve sources from other
	// threads. Publish complete immutable snapshots atomically so a refresh never exposes Mihon
	// sources as briefly uninstalled (or races a mutable HashMap read).
	@Volatile
	private var sourceCache: Map<Long, SourceT> = emptyMap()
	@Volatile
	private var wrappedSourceCache: Map<Long, WrappedSourceT> = emptyMap()
	@Volatile
	private var isPackageObserverRegistered = false
	@Volatile
	private var isInitialized = false
	private val loadMutex = Mutex()

	@Synchronized
	fun initialize(isRelevantPackage: (String) -> Boolean, loadAction: suspend () -> Unit) {
		if (isInitialized) return
		isInitialized = true
		registerPackageObserver(isRelevantPackage, loadAction)
		scope.launch { loadAction() }
	}

	suspend fun loadExtensions(
		loadResults: suspend (Context) -> List<ResultT>,
		processResults: (List<ResultT>) -> ProcessedExternalExtensions<SuccessT, ErrorT, SourceT, WrappedSourceT>,
	) {
		// Package-added/replaced broadcasts can arrive together. StateFlow is not a lock; use an
		// atomic tryLock so two classloader scans cannot race and publish stale source instances.
		// When one is already running, wait it out rather than returning: callers treat this as
		// "sources are ready afterwards", and returning early left them reading an empty cache —
		// which is what made extension icons fall back to the generic placeholder at random.
		if (!loadMutex.tryLock()) {
			loadMutex.withLock { }
			return
		}
		_isLoading.value = true
		try {
			val processed = processResults(loadResults(context))
			val newSourceCache = LinkedHashMap<Long, SourceT>(processed.sourceById.size)
			val newWrappedSourceCache = LinkedHashMap<Long, WrappedSourceT>(processed.wrappedSourceById.size)
			newSourceCache.putAll(processed.sourceById)
			newWrappedSourceCache.putAll(processed.wrappedSourceById)
			sourceCache = newSourceCache
			wrappedSourceCache = newWrappedSourceCache
			_installedExtensions.value = processed.successful
			_failedExtensions.value = processed.failed
			_isReady.value = true
		} finally {
			_isLoading.value = false
			loadMutex.unlock()
		}
	}

	fun getSourceById(sourceId: Long): SourceT? = sourceCache[sourceId]
	fun getWrappedSourceById(sourceId: Long): WrappedSourceT? = wrappedSourceCache[sourceId]
	fun getWrappedSources(): List<WrappedSourceT> = wrappedSourceCache.values.toList()
	fun getSourceCount(): Int = sourceCache.size
	fun hasExtensions(): Boolean = installedExtensions.value.isNotEmpty()

	private fun registerPackageObserver(isRelevantPackage: (String) -> Boolean, loadAction: suspend () -> Unit) {
		if (isPackageObserverRegistered) return
		registerExternalExtensionPackageObserver(context, scope, isRelevantPackage, loadAction)
		isPackageObserverRegistered = true
	}
}

class ExternalExtensionManagerFacade<ResultT, SuccessT, ErrorT, SourceT, CatalogueT : SourceT, WrappedSourceT>(
	private val context: Context,
	scope: CoroutineScope,
	private val loadResults: suspend (Context) -> List<ResultT>,
	/** Whether an installed package is an extension; checked on package broadcasts. */
	private val isExtensionPackage: (Context, String) -> Boolean,
	private val successOf: (ResultT) -> SuccessT?,
	private val errorOf: (ResultT) -> ErrorT?,
	private val untrustedPackageNameOf: (ResultT) -> String?,
	private val successSources: (SuccessT) -> List<SourceT>,
	private val successPackageName: (SuccessT) -> String,
	private val successContentWarning: (SuccessT) -> ContentWarning,
	private val successCatalogueSources: (SuccessT) -> List<CatalogueT>,
	private val sourceId: (SourceT) -> Long,
	private val asCatalogueSource: (SourceT) -> CatalogueT?,
	private val catalogueSourceName: (CatalogueT) -> String,
	private val catalogueSourceLang: (CatalogueT) -> String,
	private val buildWrappedSource: (CatalogueT, String, ContentWarning, Boolean) -> WrappedSourceT,
	private val sourceNamePrefix: String,
	private val errorPackageName: (ErrorT) -> String,
	private val errorMessage: (ErrorT) -> String,
	private val errorThrowable: (ErrorT) -> Throwable? = { null },
) {
	private val runtime = ExternalExtensionManagerRuntime<ResultT, SuccessT, ErrorT, SourceT, WrappedSourceT>(context, scope)

	val installedExtensions: StateFlow<List<SuccessT>> = runtime.installedExtensions
	val failedExtensions: StateFlow<List<ErrorT>> = runtime.failedExtensions
	val isLoading: StateFlow<Boolean> = runtime.isLoading
	val isReady: StateFlow<Boolean> = runtime.isReady

	fun initialize() {
		// A removed package can't be queried any more, so also match the ones currently loaded.
		runtime.initialize(
			isRelevantPackage = { pkgName ->
				installedExtensions.value.any { successPackageName(it) == pkgName } ||
					isExtensionPackage(context, pkgName)
			},
			loadAction = ::loadExtensions,
		)
	}

	suspend fun loadExtensions() {
		runtime.loadExtensions(loadResults) { results ->
			processExternalExtensionResults(
				results = results,
				successOf = successOf,
				errorOf = errorOf,
				untrustedPackageNameOf = untrustedPackageNameOf,
				successSources = successSources,
				successPackageName = successPackageName,
				successContentWarning = successContentWarning,
				sourceId = sourceId,
				asCatalogueSource = asCatalogueSource,
				catalogueSourceName = catalogueSourceName,
				buildWrappedSource = buildWrappedSource,
				onError = { error ->
					val throwable = errorThrowable(error)
					if (throwable == null) {
						android.util.Log.e("ExternalExtensionManager", "${errorPackageName(error)}: ${errorMessage(error)}")
					} else {
						android.util.Log.e("ExternalExtensionManager", "${errorPackageName(error)}: ${errorMessage(error)}", throwable)
					}
				},
			)
		}
	}

	fun getCatalogueSources(): List<CatalogueT> = installedExtensions.value.flatMap(successCatalogueSources)
	fun getWrappedSources(): List<WrappedSourceT> = runtime.getWrappedSources()
	fun getSourceById(sourceId: Long): SourceT? = runtime.getSourceById(sourceId)
	fun getCatalogueSourceById(sourceId: Long): CatalogueT? = runtime.getSourceById(sourceId)?.let(asCatalogueSource)
	fun getWrappedSourceById(sourceId: Long): WrappedSourceT? = runtime.getWrappedSourceById(sourceId)
	fun getWrappedSourceByName(name: String): WrappedSourceT? {
		if (!name.startsWith(sourceNamePrefix)) return null
		val sourceId = name.substringAfter(sourceNamePrefix).substringBefore(':').toLongOrNull() ?: return null
		return getWrappedSourceById(sourceId)
	}
	fun getSourcesByLanguage(): Map<String, List<CatalogueT>> = getCatalogueSources().groupBy(catalogueSourceLang)
	fun getSourceCount(): Int = runtime.getSourceCount()
	fun hasExtensions(): Boolean = runtime.hasExtensions()
}
