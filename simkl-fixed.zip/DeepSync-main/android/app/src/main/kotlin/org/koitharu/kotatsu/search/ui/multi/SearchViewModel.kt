package org.koitharu.kotatsu.search.ui.multi

import androidx.collection.ArraySet
import androidx.collection.LongSet
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.LocalMangaSource
import org.koitharu.kotatsu.core.model.UnknownMangaSource
import org.koitharu.kotatsu.core.model.isInMode
import org.koitharu.kotatsu.metadata.toVirtualManga
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.ListMode
import org.koitharu.kotatsu.core.ui.BaseViewModel
import org.koitharu.kotatsu.core.util.ext.append
import org.koitharu.kotatsu.core.util.ext.printStackTraceDebug
import org.koitharu.kotatsu.explore.data.MangaSourcesRepository
import org.koitharu.kotatsu.favourites.domain.FavouritesRepository
import org.koitharu.kotatsu.history.data.HistoryRepository
import org.koitharu.kotatsu.list.domain.MangaListMapper
import org.koitharu.kotatsu.list.ui.model.EmptyState
import org.koitharu.kotatsu.list.ui.model.ListModel
import org.koitharu.kotatsu.list.ui.model.ListHeader
import org.koitharu.kotatsu.list.ui.model.LoadingFooter
import org.koitharu.kotatsu.list.ui.model.LoadingState
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import org.koitharu.kotatsu.search.domain.SearchKind
import org.koitharu.kotatsu.search.domain.SearchV2Helper
import javax.inject.Inject

private const val MAX_PARALLELISM = 4

@HiltViewModel
class SearchViewModel @Inject constructor(
	savedStateHandle: SavedStateHandle,
	private val mangaListMapper: MangaListMapper,
	private val searchHelperFactory: SearchV2Helper.Factory,
	private val sourcesRepository: MangaSourcesRepository,
	private val historyRepository: HistoryRepository,
	private val favouritesRepository: FavouritesRepository,
	private val settings: AppSettings,
	private val metadataRepository: org.koitharu.kotatsu.metadata.MetadataRepository,
) : BaseViewModel() {

	val query = savedStateHandle.get<String>(AppRouter.KEY_QUERY).orEmpty()
	val kind = savedStateHandle.get<SearchKind>(AppRouter.KEY_KIND) ?: SearchKind.SIMPLE
	/** Manga vs novel sources. Picked from the chip row on this screen and remembered for next time. */
	val novelScope = MutableStateFlow(settings.isGlobalSearchNovelScope)

	/** Global search follows the mode: Manga searches manga, Novel novels, Anime anime. */
	private val mode: org.koitharu.kotatsu.home.ui.model.HomeMode
		get() = settings.homeMode

	/** Trackers picked in the search preferences (the sheet in the search bar's menu). */
	private val trackerScope = readTrackers()

	/**
	 * True when this search goes to trackers only (Discover). Those results are one poster grid, not a row per
	 * tracker with a "Show all" button; the screen builds its grid layout from this.
	 */
	val isTrackerGrid: Boolean = trackerScope.any { metadataRepository.supports(it, mode) }

	private fun readTrackers() = settings.globalSearchTrackers.mapNotNull {
		runCatching { org.koitharu.kotatsu.home.ui.model.HomeMetadata.valueOf(it) }.getOrNull()
	}.toSet()

	private val pinnedOnly = MutableStateFlow(settings.isSearchPinnedOnly)
	private val localOnly = MutableStateFlow(settings.isSearchLocalOnly)
	private val results = MutableStateFlow<List<SearchResultsListModel>>(emptyList())

	// Not `isLoading`: that StateFlow can flip true->false before this flow is even subscribed (a search
	// with no sources finishes in microseconds), and the collector would then wait forever for a `true`
	// that already happened, leaving the screen on its spinner.
	private val isSearching = MutableStateFlow(true)

	private var searchJob: Job? = null

	/** Bumped per search so a cancelled run's cleanup cannot clear the flag of the run replacing it. */
	private var searchGeneration = 0

	/** Whether any search filter is on, for the toolbar badge. */
	val hasActiveFilters: StateFlow<Boolean> = combine(pinnedOnly, localOnly) { pinned, local ->
		pinned || local
	}.stateIn(viewModelScope + Dispatchers.Default, SharingStarted.Eagerly, false)

	val list: StateFlow<List<ListModel>> = combine(
		results,
		isSearching,
	) { list, loading ->
		// Sources with no results are always hidden.
		val filteredList = list.filter { it.list.isNotEmpty() }
		val shown: List<ListModel> = if (isTrackerGrid) flattenForGrid(filteredList) else filteredList
		when {
			filteredList.isEmpty() -> listOf(
				when {
					loading -> LoadingState
					else -> EmptyState(
						icon = R.drawable.ic_empty_common,
						textPrimary = R.string.nothing_found,
						textSecondary = R.string.text_search_holder_secondary,
						actionStringRes = 0,
					)
				},
			)

			loading -> shown + LoadingFooter()
			else -> shown
		}
	}.stateIn(viewModelScope + Dispatchers.Default, SharingStarted.Eagerly, listOf(LoadingState))

	init {
		doSearch()
	}

	/** Posters of every searched tracker side by side; a small header only when more than one tracker answered. */
	private fun flattenForGrid(sections: List<SearchResultsListModel>): List<ListModel> = buildList {
		val titled = sections.size > 1
		sections.forEach { section ->
			if (titled && section.titleResId != 0) add(ListHeader(section.titleResId))
			addAll(section.list)
		}
	}

	fun getItems(ids: LongSet): Set<Manga> {
		val snapshot = results.value
		val result = ArraySet<Manga>(ids.size)
		snapshot.forEach { x ->
			for (item in x.list) {
				if (item.id in ids) {
					result.add(item.manga)
				}
			}
		}
		return result
	}

	fun retry() {
		searchJob?.cancel()
		results.value = emptyList()
		doSearch()
	}

	val isPinnedOnly: Boolean
		get() = pinnedOnly.value

	val isLocalOnly: Boolean
		get() = localOnly.value

	fun setPinnedOnly(value: Boolean) {
		if (pinnedOnly.value != value) {
			settings.isSearchPinnedOnly = value
			pinnedOnly.value = value
			retry()
		}
	}

	fun setNovelScope(value: Boolean) {
		if (novelScope.value != value) {
			settings.isGlobalSearchNovelScope = value
			novelScope.value = value
			retry()
		}
	}

	fun setLocalOnly(value: Boolean) {
		if (localOnly.value != value) {
			settings.isSearchLocalOnly = value
			localOnly.value = value
			retry()
		}
	}

	private fun doSearch() {
		val prevJob = searchJob
		val generation = ++searchGeneration
		isSearching.value = true
		searchJob = launchLoadingJob(Dispatchers.Default) {
			prevJob?.cancelAndJoin()
			try {
				// Source requests start right away instead of after the local phase (a full storage
				// scan with many downloads); their results still land below the local sections.
				val localDone = CompletableDeferred<Unit>()
				// A tracker chip (AniList, MyAnimeList...) scopes the search to that tracker alone: no
				// sources, favourites, history or local results next to it.
				val activeTrackers = trackerScope.filter { metadataRepository.supports(it, mode) }
				val trackersOnly = activeTrackers.isNotEmpty()
				val remoteJobs = if (localOnly.value || trackersOnly) {
					emptyList()
				} else {
					val sources = if (pinnedOnly.value) {
						sourcesRepository.getPinnedSources().toList()
					} else {
						sourcesRepository.getEnabledSources()
					}.filter { it.isInMode(mode, settings.streamingKind) }
					val semaphore = Semaphore(MAX_PARALLELISM)
					sources.map { source ->
						launch {
							val result = semaphore.withPermit { searchSource(source) }
							localDone.await()
							appendResult(result)
						}
					}
				}
				val trackerJobs = activeTrackers.map { provider ->
					launch {
						val result = searchTracker(provider)
						localDone.await()
						appendResult(result)
					}
				}
				if (!trackersOnly) {
					appendResult(searchFavorites())
					appendResult(searchHistory())
					appendResult(searchLocal())
				}
				localDone.complete(Unit)
				remoteJobs.joinAll()
				trackerJobs.joinAll()
			} finally {
				if (generation == searchGeneration) {
					isSearching.value = false
				}
			}
		}
	}

	// impl

	private suspend fun searchSource(source: MangaSource): SearchResultsListModel? = runCatchingCancellable {
		val searchHelper = searchHelperFactory.create(source)
		searchHelper(query, kind)
	}.fold(
		onSuccess = { result ->
			if (result == null || result.manga.isEmpty()) {
				null
			} else {
				val list = mangaListMapper.toListModelList(
					manga = result.manga,
					mode = ListMode.GRID,
				)
				SearchResultsListModel(
					titleResId = 0,
					source = source,
					list = list,
					error = null,
					listFilter = result.listFilter,
					sortOrder = result.sortOrder,
				)
			}
		},
		onFailure = { error ->
			error.printStackTraceDebug()
			SearchResultsListModel(0, source, null, null, emptyList(), error)
		},
	)

	private suspend fun searchTracker(provider: org.koitharu.kotatsu.home.ui.model.HomeMetadata): SearchResultsListModel? =
		runCatchingCancellable {
			metadataRepository.search(
				provider, query, mode,
				// A grid shows the whole page; the old carousel only ever showed a taste
				limit = if (isTrackerGrid) 30 else 14,
				hideAdult = settings.isNsfwContentDisabled,
			)
		}.fold(
			onSuccess = { titles ->
				if (titles.isEmpty()) {
					null
				} else {
					SearchResultsListModel(
						titleResId = provider.titleRes,
						source = org.koitharu.kotatsu.metadata.MetadataMangaSource(provider),
						list = mangaListMapper.toListModelList(
							manga = titles.map { it.toVirtualManga(provider, mode) },
							mode = ListMode.GRID,
							flags = MangaListMapper.NO_SAVED,
						),
						error = null,
						listFilter = null,
						sortOrder = null,
					)
				}
			},
			onFailure = { error ->
				error.printStackTraceDebug()
				null
			},
		)

	private suspend fun searchHistory(): SearchResultsListModel? = runCatchingCancellable {
		historyRepository.search(query, kind, Int.MAX_VALUE)
			.filter { it.source.isInMode(mode, settings.streamingKind) }
	}.fold(
		onSuccess = { result ->
			if (result.isNotEmpty()) {
				SearchResultsListModel(
					titleResId = R.string.history,
					source = UnknownMangaSource,
					list = mangaListMapper.toListModelList(manga = result, mode = ListMode.GRID),
					error = null,
					listFilter = null,
					sortOrder = null,
				)
			} else {
				null
			}
		},
		onFailure = { error ->
			SearchResultsListModel(
				titleResId = R.string.history,
				source = UnknownMangaSource,
				list = emptyList(),
				error = error,
				listFilter = null,
				sortOrder = null,
			)
		},
	)

	private suspend fun searchFavorites(): SearchResultsListModel? = runCatchingCancellable {
		favouritesRepository.search(query, kind, Int.MAX_VALUE)
			.filter { it.source.isInMode(mode, settings.streamingKind) }
	}.fold(
		onSuccess = { result ->
			if (result.isNotEmpty()) {
				SearchResultsListModel(
					titleResId = R.string.favourites,
					source = UnknownMangaSource,
					list = mangaListMapper.toListModelList(
						manga = result,
						mode = ListMode.GRID,
						flags = MangaListMapper.NO_FAVORITE,
					),
					error = null,
					listFilter = null,
					sortOrder = null,
				)
			} else {
				null
			}
		},
		onFailure = { error ->
			SearchResultsListModel(
				titleResId = R.string.favourites,
				source = UnknownMangaSource,
				list = emptyList(),
				error = error,
				listFilter = null,
				sortOrder = null,
			)
		},
	)

	private suspend fun searchLocal(): SearchResultsListModel? = if (mode != org.koitharu.kotatsu.home.ui.model.HomeMode.MANGA) {
		null
	} else runCatchingCancellable {
		searchHelperFactory.create(LocalMangaSource).invoke(query, kind)
	}.fold(
		onSuccess = { result ->
			if (!result?.manga.isNullOrEmpty()) {
				SearchResultsListModel(
					titleResId = 0,
					source = LocalMangaSource,
					list = mangaListMapper.toListModelList(
						manga = result.manga,
						mode = ListMode.GRID,
						flags = MangaListMapper.NO_SAVED,
					),
					error = null,
					listFilter = result.listFilter,
					sortOrder = result.sortOrder,
				)
			} else {
				null
			}
		},
		onFailure = { error ->
			SearchResultsListModel(
				titleResId = 0,
				source = LocalMangaSource,
				list = emptyList(),
				error = error,
				listFilter = null,
				sortOrder = null,
			)
		},
	)

	private fun appendResult(item: SearchResultsListModel?) {
		if (item != null) {
			results.append(item)
		}
	}

}
