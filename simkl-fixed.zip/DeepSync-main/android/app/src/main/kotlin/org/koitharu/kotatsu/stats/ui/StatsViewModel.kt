package org.koitharu.kotatsu.stats.ui

import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.model.FavouriteCategory
import org.koitharu.kotatsu.core.ui.BaseViewModel
import org.koitharu.kotatsu.core.ui.util.ReversibleAction
import org.koitharu.kotatsu.core.util.ext.MutableEventFlow
import org.koitharu.kotatsu.core.util.ext.call
import org.koitharu.kotatsu.favourites.domain.FavouritesRepository
import org.koitharu.kotatsu.stats.data.StatsRepository
import org.koitharu.kotatsu.stats.domain.ReadingStats
import org.koitharu.kotatsu.stats.domain.StatsPeriod
import javax.inject.Inject

@HiltViewModel
class StatsViewModel @Inject constructor(
	private val repository: StatsRepository,
	private val genreAffinity: org.koitharu.kotatsu.stats.domain.GenreAffinityRepository,
	favouritesRepository: FavouritesRepository,
	savedStateHandle: androidx.lifecycle.SavedStateHandle,
) : BaseViewModel() {

	/** The content mode the screen was opened for (null = everything, as from History). */
	val mode: org.koitharu.kotatsu.home.ui.model.HomeMode? = savedStateHandle.get<String>(StatsActivity.EXTRA_MODE)
		?.let { name -> org.koitharu.kotatsu.home.ui.model.HomeMode.entries.firstOrNull { it.name == name } }


	/** The Streaming half the screen opened in; only meaningful for the anime mode. */
	private val streamingKind = savedStateHandle.get<String>(StatsActivity.EXTRA_KIND)
		?.let { name -> org.koitharu.kotatsu.home.ui.model.StreamingKind.entries.firstOrNull { it.name == name } }

	val period = MutableStateFlow(StatsPeriod.ALL)
	val selectedCategories = MutableStateFlow<Set<Long>>(emptySet())
	val onActionDone = MutableEventFlow<ReversibleAction>()
	val favoriteCategories = favouritesRepository.observeCategories()

	val stats = MutableStateFlow(ReadingStats())

	/** The genres the user leans to, across the library, history and reading time. */
	val genres = MutableStateFlow<List<org.koitharu.kotatsu.stats.domain.GenreScore>>(emptyList())

	init {
		launchJob(Dispatchers.Default) {
			genres.value = genreAffinity.top(mode = mode, limit = 10, kind = streamingKind)
		}
		launchJob(Dispatchers.Default) {
			combine(period, selectedCategories, ::Pair).collectLatest { (p, categories) ->
				stats.value = withLoading { repository.getStatsSnapshot(p, categories, mode, streamingKind) }
			}
		}
	}

	fun toggleCategory(category: FavouriteCategory) {
		val snapshot = selectedCategories.value
		selectedCategories.value = if (category.id in snapshot) {
			snapshot - category.id
		} else {
			snapshot + category.id
		}
	}

	fun clearCategories() {
		selectedCategories.value = emptySet()
	}

	fun clearStats() {
		launchLoadingJob(Dispatchers.Default) {
			repository.clearStats()
			stats.value = ReadingStats(period = period.value)
			onActionDone.call(ReversibleAction(R.string.stats_cleared, null))
		}
	}
}
