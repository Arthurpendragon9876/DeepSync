package org.koitharu.kotatsu.history.data

import androidx.room.withTransaction
import dagger.Reusable
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.koitharu.kotatsu.core.db.MangaDatabase
import org.koitharu.kotatsu.core.db.entity.toEntity
import org.koitharu.kotatsu.core.db.entity.toManga
import org.koitharu.kotatsu.core.db.entity.toMangaList
import org.koitharu.kotatsu.core.db.entity.toMangaTags
import org.koitharu.kotatsu.core.db.entity.toMangaTagsList
import org.koitharu.kotatsu.core.model.MangaHistory
import org.koitharu.kotatsu.core.model.isInMode
import org.koitharu.kotatsu.core.model.isLocal
import org.koitharu.kotatsu.core.model.isNsfw
import org.koitharu.kotatsu.core.model.toMangaSources
import org.koitharu.kotatsu.core.parser.MangaDataRepository
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.ProgressIndicatorMode
import org.koitharu.kotatsu.core.ui.util.ReversibleHandle
import org.koitharu.kotatsu.core.util.ext.mapItems
import org.koitharu.kotatsu.core.util.ext.processLifecycleScope
import org.koitharu.kotatsu.history.domain.model.MangaWithHistory
import org.koitharu.kotatsu.list.domain.ListFilterOption
import org.koitharu.kotatsu.list.domain.ListSortOrder
import org.koitharu.kotatsu.list.domain.ReadingProgress
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.model.MangaChapter
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.model.MangaTag
import org.koitharu.kotatsu.parsers.util.findById
import org.koitharu.kotatsu.parsers.util.levenshteinDistance
import org.koitharu.kotatsu.scrobbling.common.domain.Scrobbler
import org.koitharu.kotatsu.scrobbling.common.domain.tryAutoLink
import org.koitharu.kotatsu.scrobbling.common.domain.tryScrobble
import org.koitharu.kotatsu.scrobbling.common.domain.model.AutoLinkResult
import org.koitharu.kotatsu.core.model.isNovelSource
import org.koitharu.kotatsu.scrobbling.common.domain.model.scrobblerType
import org.koitharu.kotatsu.scrobbling.common.domain.model.ScrobblerMangaType
import org.koitharu.kotatsu.scrobbling.common.domain.model.ScrobblingStatus
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import org.koitharu.kotatsu.scrobbling.common.ui.TrackPromptCoordinator
import org.koitharu.kotatsu.search.domain.SearchKind
import org.koitharu.kotatsu.tracker.domain.CheckNewChaptersUseCase
import kotlin.math.ceil
import javax.inject.Inject
import javax.inject.Provider

/** Process-wide: the repository is @Reusable, so instances aren't shared. */
private val writeMutex = Mutex()
private val scrobbleMutex = Mutex()

@Reusable
class HistoryRepository @Inject constructor(
	private val db: MangaDatabase,
	private val settings: AppSettings,
	private val scrobblers: Set<@JvmSuppressWildcards Scrobbler>,
	private val mangaRepository: MangaDataRepository,
	private val localObserver: HistoryLocalObserver,
	private val newChaptersUseCaseProvider: Provider<CheckNewChaptersUseCase>,
	private val trackPrompt: TrackPromptCoordinator,
) {

	suspend fun getList(offset: Int, limit: Int): List<Manga> {
		val entities = db.getHistoryDao().findAll(offset, limit)
		return entities.map { it.toManga() }
	}

	suspend fun search(query: String, kind: SearchKind, limit: Int): List<Manga> {
		val dao = db.getHistoryDao()
		val q = "%$query%"
		val entities = when (kind) {
			SearchKind.SIMPLE,
			SearchKind.TITLE -> dao.searchByTitle(q, limit).sortedBy { it.manga.title.levenshteinDistance(query) }

			SearchKind.AUTHOR -> dao.searchByAuthor(q, limit)
			SearchKind.TAG -> dao.searchByTag(q, limit)
		}
		return entities.toMangaList()
	}

	suspend fun getLastOrNull(): Manga? {
		val entity = db.getHistoryDao().findAll(0, 1).firstOrNull() ?: return null
		return entity.toManga()
	}

	/** The most recent title of one mode (Anime / Manga / Novel), looking a little way down the history. */
	suspend fun getLastOrNull(mode: org.koitharu.kotatsu.home.ui.model.HomeMode): Manga? =
		getList(0, MODE_LOOKUP_LIMIT).firstOrNull { it.source.isInMode(mode, settings.streamingKind) }

	fun observeLast(mode: org.koitharu.kotatsu.home.ui.model.HomeMode): Flow<Manga?> =
		observeAll(MODE_LOOKUP_LIMIT).map { list -> list.firstOrNull { it.source.isInMode(mode, settings.streamingKind) } }

	fun observeLast(): Flow<Manga?> {
		return db.getHistoryDao().observeAll(1).map {
			val first = it.firstOrNull()
			first?.toManga()
		}
	}

	fun observeAll(): Flow<List<Manga>> {
		return db.getHistoryDao().observeAll().mapItems {
			it.toManga()
		}
	}

	fun observeAll(limit: Int): Flow<List<Manga>> {
		return db.getHistoryDao().observeAll(limit).mapItems {
			it.toManga()
		}
	}

	fun observeAllWithHistory(
		order: ListSortOrder,
		filterOptions: Set<ListFilterOption>,
		limit: Int
	): Flow<List<MangaWithHistory>> {
		if (ListFilterOption.Downloaded in filterOptions) {
			return localObserver.observeAll(order, filterOptions, limit)
		}
		return db.getHistoryDao().observeAll(order, filterOptions, limit).mapItems {
			MangaWithHistory(
				it.toManga(),
				it.history.toMangaHistory(),
			)
		}
	}

	fun observeOne(id: Long): Flow<MangaHistory?> {
		return db.getHistoryDao().observe(id).map {
			it?.toMangaHistory()
		}
	}

	/**
	 * @param notify run the new-chapters check and the scrobblers afterwards. Both only look at the
	 * chapter, so the reader's in-chapter autosaves skip them instead of hitting trackers every few seconds.
	 */
	suspend fun addOrUpdate(
		manga: Manga,
		chapterId: Long,
		page: Int,
		scroll: Int,
		percent: Float,
		force: Boolean,
		notify: Boolean = true,
		/** `false` still refreshes the new-chapters state but neither pushes progress to trackers nor asks to track. */
		trackers: Boolean = true,
	) {
		if (!force && shouldSkip(manga)) {
			return
		}
		assert(manga.chapters != null)
		// One write at a time, in the order they were asked for: a reader autosave landing after the
		// pause save that replaced it would roll the position back. Trackers run outside the lock.
		val isChapterChanged = writeMutex.withLock {
			// cancelled while waiting = superseded by a newer save of the same position
			currentCoroutineContext().ensureActive()
			withContext(NonCancellable) {
				db.withTransaction {
					val previousChapterId = db.getHistoryDao().find(manga.id)?.chapterId
					addOrUpdateLocked(manga, chapterId, page, scroll, percent)
					previousChapterId != chapterId
				}
			}
		}
		if (notify) {
			// trackers only store the chapter, so re-sending an unchanged one is a wasted network round trip
			onHistoryChanged(manga, chapterId, updateScrobblers = trackers && isChapterChanged, chapterOpened = trackers)
		}
	}

	/**
	 * Saves only the position inside the chapter that is already stored. Rewriting the manga, its
	 * tags and the feed on every reader autosave made the library, history and feed reload while
	 * reading. Falls back to [addOrUpdate] when there is no entry for this chapter yet.
	 */
	suspend fun updatePosition(
		manga: Manga,
		chapterId: Long,
		page: Int,
		scroll: Int,
		percent: Float,
	) {
		if (shouldSkip(manga)) {
			return
		}
		val updated = writeMutex.withLock {
			currentCoroutineContext().ensureActive()
			withContext(NonCancellable) {
				db.getHistoryDao().updatePosition(
					mangaId = manga.id,
					chapterId = chapterId,
					page = page,
					scroll = scroll.toFloat(),
					percent = percent,
					updatedAt = System.currentTimeMillis(),
				)
			}
		}
		if (updated == 0) {
			addOrUpdate(manga, chapterId, page, scroll, percent, force = false, notify = false)
		}
	}

	suspend fun advanceFromTracking(
		manga: Manga,
		chapters: List<MangaChapter>,
		targetIndex: Int,
	): Boolean {
		if (shouldSkip(manga) || targetIndex !in chapters.indices) {
			return false
		}
		val advanced = db.withTransaction {
			val history = db.getHistoryDao().findIncludingDeleted(manga.id)
			if (!canAdvanceFromTracking(history, chapters, targetIndex, manga.chapters.orEmpty())) {
				return@withTransaction false
			}
			addOrUpdateLocked(
				manga = manga,
				chapterId = chapters[targetIndex].id,
				page = 0,
				scroll = 0,
				percent = (targetIndex + 1) / chapters.size.toFloat(),
			)
			true
		}
		if (advanced) {
			onHistoryChanged(manga, chapters[targetIndex].id, updateScrobblers = false)
		}
		return advanced
	}

	private suspend fun addOrUpdateLocked(
		manga: Manga,
		chapterId: Long,
		page: Int,
		scroll: Int,
		percent: Float,
	) {
		// The reader passes a branch-filtered manga: persisting its chapter list would replace
		// the cached chapters table with only the selected scanlator's chapters (or an empty
		// list on a branch mismatch), permanently erasing the other branches. History never has
		// fresher chapters than the details pipeline, so store metadata only.
		mangaRepository.storeManga(manga.copy(chapters = null), replaceExisting = true)
		val branch = manga.chapters?.findById(chapterId)?.branch
		db.getHistoryDao().upsert(
			HistoryEntity(
				mangaId = manga.id,
				createdAt = System.currentTimeMillis(),
				updatedAt = System.currentTimeMillis(),
				chapterId = chapterId,
				page = page,
				scroll = scroll.toFloat(), // we migrate to int, but decide to not update database
				percent = percent,
				chaptersCount = manga.chapters?.count { it.branch == branch } ?: 0,
				deletedAt = 0L,
			),
		)
		db.markFeedReadUpTo(manga.id, chapterId)
	}

	/**
	 * Runs after the history transaction commits. Inside it, the new-chapters check waited for its
	 * per-manga lock while holding the database - the background checker takes that lock first and
	 * then needs the database, so the two could deadlock every write in the app. Scrobblers make
	 * network calls, which must neither hold the database nor make the caller wait.
	 */
	private suspend fun onHistoryChanged(
		manga: Manga,
		chapterId: Long,
		updateScrobblers: Boolean,
		chapterOpened: Boolean = false,
	) {
		newChaptersUseCaseProvider.get()(manga, chapterId)
		// Novels are never asked about: most of them are not on AniList and the question is just noise
		val canPrompt = chapterOpened && !manga.isLocal && !manga.source.isNovelSource
		val ask = canPrompt && settings.isScrobblingAskEnabled
		// Closest-match linking no longer depends on the Ask switch: the two are exclusive settings
		val autoBest = canPrompt && settings.isScrobblingAutoTrackBestEnabled
		if (!updateScrobblers && !ask && !autoBest) return
		// Fire and forget: opening the reader used to wait on every tracker's network write.
		// UNDISPATCHED queues on the mutex in call order, so an older chapter never lands last.
		processLifecycleScope.launch(Dispatchers.Default, CoroutineStart.UNDISPATCHED) {
			scrobbleMutex.withLock {
				// Simkl is the TV & Movies tracker: it takes no part for anime or manga
				val active = scrobblers.filter { it.isEnabled && it.handles(manga) }
				if (active.isEmpty()) return@withLock
				val anyLinked = active.any { db.getScrobblingDao().find(it.scrobblerService.id, manga.id) != null }
				// Every tap on a chapter of a title no tracker knows asks "track this?". Titles that
				// are already linked just sync, and the user can opt a title out for good.
				if ((ask || autoBest) && !anyLinked) {
					if (manga.id !in settings.scrobblingNeverAsk) {
						if (autoBest) {
							autoTrackBestMatch(active, manga, chapterId)
						} else {
							trackPrompt.request(manga, chapterId)
						}
					}
					return@withLock
				}
				if (!updateScrobblers) return@withLock
				// Silent exact-title linking: the setting already excludes Ask and closest-match
				val autoLink = settings.isScrobblingAutoLinkEnabled
				active.forEach { scrobbler ->
					// If the tracker already had a further-along entry, leave its count alone: progress
					// sync pulls it down instead of local history dragging it back.
					val linked = if (autoLink) {
						scrobbler.tryAutoLink(manga, manga.source.isNovelSource)
					} else {
						AutoLinkResult.NOT_NEEDED
					}
					if (linked != AutoLinkResult.LINKED_TRACKER_AHEAD) {
						scrobbler.tryScrobble(manga, chapterId)
					}
				}
			}
		}
	}

	/** Links [manga] to the closest title on every signed-in tracker, when one is close enough. Never asks. */
	private suspend fun autoTrackBestMatch(active: List<Scrobbler>, manga: Manga, chapterId: Long) {
		val names = (listOf(manga.title) + manga.altTitles).filter { it.isNotBlank() }.distinct()
		val type = manga.source.scrobblerType
		for (scrobbler in active) {
			runCatchingCancellable {
				val profile = org.koitharu.kotatsu.metadata.SourceProfile.of(manga)
				val best = scrobbler.searchSmart(names, type, manga)
					.firstOrNull { it.score >= AUTO_TRACK_MIN_SCORE && !with(scrobbler) { it.conflictsWith(profile) } }
					?: return@runCatchingCancellable
				if (scrobbler.linkManga(manga.id, best.manga.id, ScrobblingStatus.READING)) {
					scrobbler.tryScrobble(manga, chapterId)
				}
			}
		}
	}

	suspend fun getOne(manga: Manga): MangaHistory? {
		return db.getHistoryDao().find(manga.id)?.recoverIfNeeded(manga)?.toMangaHistory()
	}

	suspend fun getProgress(mangaId: Long, mode: ProgressIndicatorMode): ReadingProgress? {
		val entity = db.getHistoryDao().find(mangaId) ?: return null
		val fixedPercent = if (ReadingProgress.isCompleted(entity.percent)) 1f else entity.percent
		return ReadingProgress(
			percent = fixedPercent,
			totalChapters = entity.chaptersCount,
			mode = mode,
		).takeIf { it.isValid() }
	}

	suspend fun clear() {
		db.getHistoryDao().clear()
	}

	suspend fun delete(manga: Manga) = db.withTransaction {
		db.getHistoryDao().delete(manga.id)
		mangaRepository.gcChaptersCache()
	}

	suspend fun deleteAfter(minDate: Long) = db.withTransaction {
		db.getHistoryDao().deleteAfter(minDate)
		mangaRepository.gcChaptersCache()
	}

	suspend fun deleteNotFavorite() = db.withTransaction {
		db.getHistoryDao().deleteNotFavorite()
		mangaRepository.gcChaptersCache()
	}

	suspend fun delete(ids: Collection<Long>): ReversibleHandle {
		db.withTransaction {
			for (id in ids) {
				db.getHistoryDao().delete(id)
			}
			mangaRepository.gcChaptersCache()
		}
		return ReversibleHandle {
			recover(ids)
		}
	}

	/**
	 * Try to replace one manga with another one
	 * Useful for replacing saved manga on deleting it with remote source
	 */
	suspend fun deleteOrSwap(manga: Manga, alternative: Manga?) {
		if (alternative == null || db.getMangaDao().update(alternative.toEntity()) <= 0) {
			delete(manga)
		}
	}

	suspend fun getPopularTags(limit: Int): List<MangaTag> {
		return db.getHistoryDao().findPopularTags(limit).toMangaTagsList()
	}

	suspend fun getPopularSources(limit: Int): List<MangaSource> {
		return db.getHistoryDao().findPopularSources(limit).toMangaSources()
	}

	fun shouldSkip(manga: Manga): Boolean = settings.isIncognitoModeEnabled(manga.isNsfw())

	fun observeShouldSkip(manga: Manga): Flow<Boolean> {
		return settings.observe(AppSettings.KEY_INCOGNITO_MODE, AppSettings.KEY_INCOGNITO_NSFW)
			.map { shouldSkip(manga) }
			.distinctUntilChanged()
	}

	private suspend fun recover(ids: Collection<Long>) {
		db.withTransaction {
			for (id in ids) {
				db.getHistoryDao().recover(id)
			}
		}
	}

	private suspend fun HistoryEntity.recoverIfNeeded(manga: Manga): HistoryEntity {
		val chapters = manga.chapters
		if (manga.isLocal || chapters.isNullOrEmpty() || chapters.findById(chapterId) != null) {
			return this
		}
		val index = recoveredChapterIndex(percent, chaptersCount, chapters.size)
		val newChapterId = chapters.getOrNull(index)?.id ?: return this
		val newEntity = copy(chapterId = newChapterId)
		db.getHistoryDao().update(newEntity)
		return newEntity
	}

	private fun HistoryWithManga.toManga() = manga.toManga(tags.toMangaTags(), null)
}

/** Marks feed entries whose chapters all lie at or before [chapterId] as read. DB-only. */
suspend fun MangaDatabase.markFeedReadUpTo(mangaId: Long, chapterId: Long) {
	val unreadLogs = getTrackLogsDao().findUnreadByManga(mangaId)
	if (unreadLogs.isEmpty()) {
		return
	}
	val allChapters = getChaptersDao().findAll(mangaId)
	val lastReadChapterIndex = allChapters.indexOfFirst { it.chapterId == chapterId }
	if (lastReadChapterIndex == -1) {
		return
	}
	for (log in unreadLogs) {
		val logChapterIds = log.chapterIds.split('\n').mapNotNull { it.toLongOrNull() }
		val allLogChaptersRead = logChapterIds.all { chId ->
			val chIndex = allChapters.indexOfFirst { it.chapterId == chId }
			chIndex != -1 && chIndex <= lastReadChapterIndex
		}
		if (allLogChaptersRead) {
			getTrackLogsDao().markLogAsRead(log.id)
		}
	}
}

/**
 * Where a saved position sits in a chapter list that no longer contains the chapter it was saved on
 * (the source re-keyed its chapters, or the list was replaced).
 *
 * [percent] was measured against the list as it was when the position was saved, which [savedCount]
 * remembers. Measuring it against the current list instead moves the position forward whenever new
 * chapters have arrived: someone on 6 of 6 would land on 7 of 7 the moment episode 7 is published, with
 * no update in the feed and no notification. New chapters are appended after the old ones, so the saved
 * count is the right yardstick; the current size is only used for rows saved without a count.
 */
internal fun recoveredChapterIndex(percent: Float, savedCount: Int, currentSize: Int): Int {
	val base = if (savedCount > 0) savedCount else currentSize
	// The small offset keeps float noise (6 / 7f * 7 = 6.0000005) from rounding up to the next chapter
	val index = ceil(base * percent.toDouble() - 1e-4).toInt() - 1
	return index.coerceIn(0, (currentSize - 1).coerceAtLeast(0))
}

internal fun canAdvanceFromTracking(
	history: HistoryEntity?,
	chapters: List<MangaChapter>,
	targetIndex: Int,
	allChapters: List<MangaChapter> = chapters,
): Boolean {
	if (targetIndex !in chapters.indices || history?.deletedAt?.let { it != 0L } == true) {
		return false
	}
	if (history == null) {
		return true
	}
	val currentIndex = chapters.indexOfFirst { it.id == history.chapterId }
	if (currentIndex >= 0) {
		return targetIndex > currentIndex
	}
	// The checkpoint is not in this branch: either the user is reading another scanlator, or the
	// chapter no longer exists in the source at all — the usual state of a library migrated from
	// another app. Compare chapter numbers instead, and when the checkpoint cannot be resolved
	// anywhere the tracker is the only progress left, so let it win.
	val currentNumber = allChapters.firstOrNull { it.id == history.chapterId }?.number ?: return true
	return currentNumber <= 0f || chapters[targetIndex].number > currentNumber
}

/** How far down the history to look for the latest title of a given mode. */
private const val MODE_LOOKUP_LIMIT = 100

private const val AUTO_TRACK_MIN_SCORE = 0.6f
