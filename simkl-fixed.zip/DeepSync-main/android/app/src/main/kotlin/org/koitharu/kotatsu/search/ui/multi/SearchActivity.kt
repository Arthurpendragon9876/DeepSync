package org.koitharu.kotatsu.search.ui.multi

import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.view.ActionMode
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.recyclerview.widget.GridLayoutManager
import com.google.android.material.badge.BadgeDrawable
import com.google.android.material.badge.BadgeUtils
import com.google.android.material.color.MaterialColors
import dagger.hilt.android.AndroidEntryPoint
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.util.ext.roundTopCorners
import org.koitharu.kotatsu.core.exceptions.resolve.SnackbarErrorObserver
import org.koitharu.kotatsu.core.nav.router
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.ui.BaseActivity
import org.koitharu.kotatsu.core.ui.list.ListSelectionController
import org.koitharu.kotatsu.core.ui.list.OnListItemClickListener
import org.koitharu.kotatsu.core.ui.util.StatusBarScrim
import org.koitharu.kotatsu.core.ui.widgets.TipView
import org.koitharu.kotatsu.core.util.ShareHelper
import org.koitharu.kotatsu.core.util.ext.consumeAllSystemBarsInsets
import org.koitharu.kotatsu.core.util.ext.invalidateNestedItemDecorations
import org.koitharu.kotatsu.core.util.ext.observe
import org.koitharu.kotatsu.core.util.ext.observeEvent
import org.koitharu.kotatsu.core.util.ext.systemBarsInsets
import org.koitharu.kotatsu.databinding.ActivitySearchBinding
import org.koitharu.kotatsu.list.domain.ListFilterOption
import org.koitharu.kotatsu.list.ui.GridSpanResolver
import org.koitharu.kotatsu.list.ui.MangaSelectionDecoration
import org.koitharu.kotatsu.list.ui.adapter.ListItemType
import org.koitharu.kotatsu.list.ui.adapter.MangaListListener
import org.koitharu.kotatsu.metadata.metaRef
import kotlinx.coroutines.launch
import androidx.lifecycle.lifecycleScope
import org.koitharu.kotatsu.list.ui.adapter.TypedListSpacingDecoration
import org.koitharu.kotatsu.list.ui.model.ListHeader
import org.koitharu.kotatsu.list.ui.model.MangaListModel
import org.koitharu.kotatsu.list.ui.size.DynamicItemSizeResolver
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.model.MangaTag
import org.koitharu.kotatsu.search.domain.SearchKind
import org.koitharu.kotatsu.search.ui.multi.adapter.SearchAdapter
import javax.inject.Inject
import kotlin.math.roundToInt
import androidx.appcompat.R as appcompatR
import com.google.android.material.R as materialR

@AndroidEntryPoint
class SearchActivity :
	BaseActivity<ActivitySearchBinding>(),
	MangaListListener,
	ListSelectionController.Callback {

	@Inject
	lateinit var settings: AppSettings

	@Inject
	lateinit var metadataOpener: org.koitharu.kotatsu.metadata.MetadataOpener

	private val viewModel by viewModels<SearchViewModel>()
	private lateinit var selectionController: ListSelectionController
	private var filterBadge: BadgeDrawable? = null

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(ActivitySearchBinding.inflate(layoutInflater))
		title = when (viewModel.kind) {
			SearchKind.SIMPLE,
			SearchKind.TITLE -> viewModel.query

			SearchKind.AUTHOR -> getString(
				R.string.inline_preference_pattern,
				getString(R.string.author),
				viewModel.query,
			)

			SearchKind.TAG -> getString(R.string.inline_preference_pattern, getString(R.string.genre), viewModel.query)
		}

		val itemClickListener = OnListItemClickListener<SearchResultsListModel> { item, view ->
			if (item.source is org.koitharu.kotatsu.metadata.MetadataMangaSource) {
				// A tracker section: "more" continues in that tracker's own search screen.
				startActivity(org.koitharu.kotatsu.metadata.MetadataSearchActivity.intent(this, viewModel.query))
			} else if (item.listFilter == null) {
				router.openSearch(item.source, viewModel.query)
			} else {
				router.openList(item.source, item.listFilter, item.sortOrder)
			}
		}
		val sizeResolver = DynamicItemSizeResolver(resources, this, settings, adjustWidth = true)
		val gridSizeResolver = DynamicItemSizeResolver(resources, this, settings, adjustWidth = false)
		val selectionDecoration = MangaSelectionDecoration(this)
		selectionController = ListSelectionController(
			appCompatDelegate = delegate,
			decoration = selectionDecoration,
			registryOwner = this,
			callback = this,
		)
		val adapter = SearchAdapter(
			listener = this,
			itemClickListener = itemClickListener,
			sizeResolver = sizeResolver,
			gridSizeResolver = gridSizeResolver,
			selectionDecoration = selectionDecoration,
		)
		// Source rows: covers sit behind two grid_spacing_outer gaps (the row's SpacingItemDecoration + the
		// card's own margin), so the rounded cut is pulled in by both. The Discover grid has the card margin only.
		viewBinding.recyclerView.roundTopCorners(
			radius = resources.getDimension(R.dimen.cover_corner_large),
			extraInset = resources.getDimensionPixelOffset(R.dimen.grid_spacing_outer) * if (viewModel.isTrackerGrid) 1 else 2,
		)
		viewBinding.recyclerView.adapter = adapter
		viewBinding.recyclerView.setHasFixedSize(true)
		viewBinding.recyclerView.addItemDecoration(TypedListSpacingDecoration(this, true))
		if (viewModel.isTrackerGrid) setupGrid(adapter, selectionDecoration)

		setDisplayHomeAsUp(isEnabled = true, showUpAsClose = false)
		supportActionBar?.setSubtitle(R.string.search_results)

		addMenuProvider(SearchMenuProvider(this, viewModel))
		viewBinding.statusBarScrim.background = StatusBarScrim.drawable(this)
		viewModel.hasActiveFilters.observe(this, ::onActiveFiltersChanged)

		viewModel.list.observe(this, adapter)
		viewModel.onError.observeEvent(this, SnackbarErrorObserver(viewBinding.recyclerView, null))
	}

	/**
	 * Discover results (the trackers) are one poster grid, as in every other list in the app, instead of a
	 * carousel per tracker. Posters take one cell; headers and the loading / empty states take the whole row.
	 */
	private fun setupGrid(adapter: SearchAdapter, selectionDecoration: MangaSelectionDecoration) {
		val spanResolver = GridSpanResolver(resources)
		val layoutManager = GridLayoutManager(this, spanResolver.spanCount)
		layoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
			override fun getSpanSize(position: Int): Int = when (adapter.getItemViewType(position)) {
				ListItemType.MANGA_GRID.ordinal -> 1
				else -> layoutManager.spanCount
			}
		}
		viewBinding.recyclerView.layoutManager = layoutManager
		viewBinding.recyclerView.addItemDecoration(selectionDecoration)
		viewBinding.recyclerView.addOnLayoutChangeListener(spanResolver)
		spanResolver.setGridSize(settings.gridSize / 100f, viewBinding.recyclerView)
	}

	override fun onApplyWindowInsets(v: View, insets: WindowInsetsCompat): WindowInsetsCompat {
		val barsInsets = insets.systemBarsInsets
		viewBinding.toolbar.updatePadding(
			top = barsInsets.top,
			left = barsInsets.left,
			right = barsInsets.right,
		)
		viewBinding.statusBarScrim.updateLayoutParams {
			// No status bar to protect when it is hidden (the inset can still be non-zero on
			// cutout devices), so the scrim would just be a stray band at the top.
			height = if (settings.isStatusBarHidden) {
				0
			} else {
				(barsInsets.top * StatusBarScrim.HEIGHT_FACTOR).roundToInt()
			}
		}
		viewBinding.recyclerView.setPadding(
			barsInsets.left,
			0,
			barsInsets.right,
			barsInsets.bottom,
		)
		return insets.consumeAllSystemBarsInsets()
	}

	// Posted: the menu is inflated after this first fires, and BadgeUtils needs the real item view.
	private fun onActiveFiltersChanged(hasFilters: Boolean) {
		viewBinding.toolbar.post { applyFilterBadge(hasFilters) }
	}

	private fun applyFilterBadge(hasFilters: Boolean) {
		val item = viewBinding.toolbar.menu.findItem(R.id.action_search_kind) ?: return
		// detach reads the custom parent back off the badge itself, so it needs no parent argument.
		filterBadge?.let { BadgeUtils.detachBadgeDrawable(it, viewBinding.toolbar, R.id.action_search_kind) }
		filterBadge = if (hasFilters) {
			// A plain dot: BadgeDrawable draws one whenever it has no number. Size, corner and offsets
			// all live in the xml.
			BadgeDrawable.createFromResource(this, R.xml.badge_search_filter).also {
				BadgeUtils.attachBadgeDrawable(it, viewBinding.toolbar, R.id.action_search_kind, viewBinding.toolbarContainer)
			}
		} else {
			null
		}
		// The icon itself also picks up the accent, so the state reads at a glance.
		item.icon?.mutate()?.setTint(
			MaterialColors.getColor(
				viewBinding.toolbar,
				if (hasFilters) appcompatR.attr.colorPrimary else materialR.attr.colorOnSurfaceVariant,
			),
		)
	}

	override fun onItemClick(item: MangaListModel, view: View) {
		if (!selectionController.onItemClick(view, item.id)) {
			val manga = item.toMangaWithOverride()
			val meta = manga.metaRef()
			if (meta == null) {
				router.openDetails(manga)
			} else {
				// A tracker result: when info comes from the tracker its page opens at once and the source is found there.
				if (settings.isMetadataFromTracker) {
					router.openMetaDetails(meta, manga.title, manga.coverUrl, manga.largeCoverUrl)
					return
				}
				// Otherwise open the source title behind it, or let the user choose one.
				lifecycleScope.launch {
					val names = listOf(manga.title) + manga.altTitles
					when (val result = metadataOpener.resolve(meta, names, manga.title)) {
						is org.koitharu.kotatsu.metadata.MetaOpenResult.Open -> router.openDetails(result.manga)
						is org.koitharu.kotatsu.metadata.MetaOpenResult.ChooseSource -> startActivity(
							org.koitharu.kotatsu.metadata.SourceChooserActivity.intent(
								this@SearchActivity, result.query, meta.mode,
								org.koitharu.kotatsu.metadata.MetadataLinks.key(meta),
							),
						)
					}
				}
			}
		}
	}

	override fun onItemLongClick(item: MangaListModel, view: View): Boolean {
		return selectionController.onItemLongClick(view, item.id)
	}

	override fun onItemContextClick(item: MangaListModel, view: View): Boolean {
		return selectionController.onItemContextClick(view, item.id)
	}

	override fun onReadClick(manga: Manga, view: View) {
		if (!selectionController.onItemClick(view, manga.id)) {
			router.openReader(manga)
		}
	}

	override fun onTagClick(manga: Manga, tag: MangaTag, view: View) {
		if (!selectionController.onItemClick(view, manga.id)) {
			router.openList(tag)
		}
	}

	override fun onRetryClick(error: Throwable) {
		viewModel.retry()
	}

	override fun onFilterOptionClick(option: ListFilterOption) = Unit

	override fun onFilterClick(view: View?) = Unit

	override fun onEmptyActionClick() = Unit

	override fun onListHeaderClick(item: ListHeader, view: View) = Unit

	override fun onFooterButtonClick() = Unit

	override fun onPrimaryButtonClick(tipView: TipView) = Unit

	override fun onSecondaryButtonClick(tipView: TipView) = Unit

	override fun onSelectionChanged(controller: ListSelectionController, count: Int) {
		viewBinding.recyclerView.invalidateNestedItemDecorations()
	}

	override fun onCreateActionMode(
		controller: ListSelectionController,
		menuInflater: MenuInflater,
		menu: Menu
	): Boolean {
		menuInflater.inflate(R.menu.mode_remote, menu)
		return true
	}

	override fun onActionItemClicked(controller: ListSelectionController, mode: ActionMode?, item: MenuItem): Boolean {
		return when (item.itemId) {
			R.id.action_share -> {
				ShareHelper(this).shareMangaLinks(collectSelectedItems())
				mode?.finish()
				true
			}

			R.id.action_favourite -> {
				router.showFavoriteDialog(collectSelectedItems())
				mode?.finish()
				true
			}

			R.id.action_save -> {
				router.showDownloadDialog(collectSelectedItems(), viewBinding.recyclerView)
				mode?.finish()
				true
			}

			else -> false
		}
	}

	private fun collectSelectedItems(): Set<Manga> {
		return viewModel.getItems(selectionController.peekCheckedIds())
	}
}
