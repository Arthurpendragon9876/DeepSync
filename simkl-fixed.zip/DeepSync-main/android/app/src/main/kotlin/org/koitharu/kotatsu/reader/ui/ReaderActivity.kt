package org.koitharu.kotatsu.reader.ui

import android.app.assist.AssistContent
import android.content.Intent
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import androidx.activity.OnBackPressedCallback
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.os.SystemClock
import android.view.ViewGroup
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.compose.ui.unit.dp
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.activity.viewModels
import org.koitharu.kotatsu.core.ui.menu.MenuPopup
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import androidx.core.view.updatePadding
import androidx.core.view.isInvisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import org.koitharu.kotatsu.settings.compose.DropSauceTheme
import androidx.lifecycle.lifecycleScope
import androidx.transition.Fade
import androidx.transition.Slide
import androidx.transition.Transition
import androidx.transition.TransitionListenerAdapter
import androidx.transition.TransitionManager
import androidx.transition.TransitionSet
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.R as materialR
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.bookmarks.domain.Bookmark
import org.koitharu.kotatsu.bookmarks.domain.epubHighlight
import org.koitharu.kotatsu.core.exceptions.resolve.DialogErrorObserver
import org.koitharu.kotatsu.core.exceptions.resolve.SnackbarErrorObserver
import org.koitharu.kotatsu.core.model.isLocal
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.nav.router
import org.koitharu.kotatsu.core.prefs.AppSettings
import org.koitharu.kotatsu.core.prefs.ReaderMode
import org.koitharu.kotatsu.core.prefs.observeAsFlow
import org.koitharu.kotatsu.core.ui.BaseFullscreenActivity
import org.koitharu.kotatsu.core.ui.dialog.setCheckbox
import org.koitharu.kotatsu.core.ui.util.MenuInvalidator
import org.koitharu.kotatsu.core.ui.widgets.ZoomControl
import org.koitharu.kotatsu.core.util.IdlingDetector
import org.koitharu.kotatsu.core.util.ShareHelper
import org.koitharu.kotatsu.core.util.ext.HapticEffect
import org.koitharu.kotatsu.core.util.ext.hapticFeedback
import org.koitharu.kotatsu.core.util.ext.getThemeColor
import org.koitharu.kotatsu.core.util.ext.getThemeDimensionPixelOffset
import org.koitharu.kotatsu.core.util.ext.hasGlobalPoint
import org.koitharu.kotatsu.core.util.ext.isAnimationsEnabled
import org.koitharu.kotatsu.core.util.ext.observe
import org.koitharu.kotatsu.core.util.ext.observeEvent
import org.koitharu.kotatsu.core.util.ext.postDelayed
import org.koitharu.kotatsu.core.util.ext.toUriOrNull
import org.koitharu.kotatsu.core.util.ext.zipWithPrevious
import org.koitharu.kotatsu.databinding.ActivityReaderBinding
import org.koitharu.kotatsu.details.ui.pager.ChaptersPagesViewModel
import org.koitharu.kotatsu.details.ui.pager.pages.PagesSavedObserver
import org.koitharu.kotatsu.local.data.isEpub
import org.koitharu.kotatsu.parsers.model.MangaChapter
import org.koitharu.kotatsu.reader.data.TapGridSettings
import org.koitharu.kotatsu.reader.domain.TapGridArea
import org.koitharu.kotatsu.reader.domain.UpscaleEffect
import org.koitharu.kotatsu.reader.ui.upscale.UpscalePreviewDialog
import org.koitharu.kotatsu.reader.ui.config.MangaQuickSettings
import org.koitharu.kotatsu.reader.ui.config.ReaderConfigSheet
import org.koitharu.kotatsu.reader.ui.epub.EpubReaderFragment
import org.koitharu.kotatsu.reader.ui.epub.NovelChromeState
import org.koitharu.kotatsu.reader.ui.epub.NovelReaderChrome
import org.koitharu.kotatsu.reader.ui.tts.ReaderTts
import org.koitharu.kotatsu.reader.ui.tts.ReaderTtsService
import org.koitharu.kotatsu.reader.ui.pager.ReaderPage
import org.koitharu.kotatsu.reader.ui.pager.ReaderUiState
import org.koitharu.kotatsu.reader.ui.tapgrid.TapGridDispatcher
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import androidx.appcompat.R as appcompatR

@AndroidEntryPoint
class ReaderActivity :
    BaseFullscreenActivity<ActivityReaderBinding>(),
    TapGridDispatcher.OnGridTouchListener,
    ReaderConfigSheet.Callback,
    ReaderControlDelegate.OnInteractionListener,
    ReaderNavigationCallback,
    IdlingDetector.Callback,
    ZoomControl.ZoomControlListener,
    View.OnClickListener,
    ScrollTimerControlView.OnVisibilityChangeListener {

    @Inject
    lateinit var settings: AppSettings

    @Inject
    lateinit var tapGridSettings: TapGridSettings

    @Inject
    lateinit var pageSaveHelperFactory: PageSaveHelper.Factory

    @Inject
    lateinit var scrollTimerFactory: ScrollTimer.Factory

    @Inject
    lateinit var screenOrientationHelper: ScreenOrientationHelper

    private val idlingDetector = IdlingDetector(TimeUnit.SECONDS.toMillis(10), this)

    private val viewModel: ReaderViewModel by viewModels()

    override val readerMode: ReaderMode?
        get() = readerManager.currentMode

    private lateinit var scrollTimer: ScrollTimer

    @Inject
    lateinit var tts: ReaderTts
    private lateinit var pageSaveHelper: PageSaveHelper
    private lateinit var touchHelper: TapGridDispatcher
    private lateinit var controlDelegate: ReaderControlDelegate
    private var gestureInsets: Insets = Insets.NONE
    private var dockedToolbarHeight = 0
    private var isPanelOffsetAnimating = false
    // Set when a long-press action consumed the gesture; the remainder of the touch stream is
    // delivered to the content as ACTION_CANCEL so the pager doesn't scroll under the opened sheet.
    private var isTouchCancelled = false
    private lateinit var readerManager: ReaderManager
    private val hideUiRunnable = Runnable { setUiIsVisible(false) }

    /** State of the Novery-style Compose bars that replace the toolbar/dock for novels. */
    private val novelChrome = NovelChromeState()

    // Manga quick settings: an inline panel above the bottom bar (see MangaQuickSettings)
    private var quickSettingsVisible by mutableStateOf(false)
    private var quickSettingsMode by mutableStateOf(ReaderMode.STANDARD)
    private var quickSettingsOverlay: ComposeView? = null
    private val quickSettingsBackCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            updateQuickSettingsVisibility(false)
        }
    }
    private var isScrollPausedByEyeReminder = false
    private var isTtsPausedByEyeReminder = false
    private var isTimerFabShown = false

    // Tracks whether the foldable device is in an unfolded state (half-opened or flat)
    private var isFoldUnfolded: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(ActivityReaderBinding.inflate(layoutInflater))
        readerManager = ReaderManager(supportFragmentManager, viewBinding.container, settings)
        setDisplayHomeAsUp(isEnabled = true, showUpAsClose = false)
        applyTranslucentReaderBars()
        touchHelper = TapGridDispatcher(viewBinding.root, this)
        scrollTimer = scrollTimerFactory.create(resources, this, this)
        pageSaveHelper = pageSaveHelperFactory.create(this)
        controlDelegate = ReaderControlDelegate(resources, settings, tapGridSettings, this)
        viewBinding.zoomControl.listener = this
        viewBinding.actionsView.listener = this
        viewBinding.buttonTimerFab?.setOnClickListener(this)
        idlingDetector.bindToLifecycle(this)
        screenOrientationHelper.applySettings()
        viewModel.isBookmarkAdded.observe(this) { viewBinding.actionsView.isBookmarkAdded = it }
        viewModel.isHighlightPicking.observe(this) {
            novelChrome.isHighlightArmed = it
            viewBinding.actionsView.isHighlightPicking = it
            if (it) viewBinding.toastView.show(R.string.tap_sentence_to_highlight) else viewBinding.toastView.hide()
        }
        scrollTimer.isActive.observe(this) {
            updateScrollTimerButton()
            viewBinding.actionsView.setTimerActive(it)
        }
        viewBinding.timerControl.onVisibilityChangeListener = this
        viewBinding.timerControl.attach(scrollTimer, this)
        viewBinding.ttsControl.onVisibilityChangeListener = this
        viewBinding.ttsControl.attach(tts, this)
        tts.isPlaying.observe(this) {
            updateScrollTimerButton()
            if (it) {
                scrollTimer.setActive(false)
                ReaderTtsService.start(this, viewModel.getMangaOrNull())
            }
        }
        if (resources.getBoolean(R.bool.is_tablet)) {
            viewBinding.timerControl.updateLayoutParams<CoordinatorLayout.LayoutParams> {
                topMargin = marginEnd + getThemeDimensionPixelOffset(appcompatR.attr.actionBarSize)
            }
        }

        viewModel.onLoadingError.observeEvent(
            this,
            DialogErrorObserver(
                host = viewBinding.container,
                fragment = null,
                resolver = exceptionResolver,
                onResolved = { isResolved ->
                    if (isResolved) {
                        viewModel.reload()
                    } else if (viewModel.content.value.pages.isEmpty()) {
                        dispatchNavigateUp()
                    }
                },
            ),
        )
        viewModel.onError.observeEvent(
            this,
            SnackbarErrorObserver(
                host = viewBinding.container,
                fragment = null,
                resolver = exceptionResolver,
                onResolved = null,
            ),
        )
        viewModel.readerMode.observe(this, Lifecycle.State.STARTED, this::onInitReader)
        settings.observeAsFlow(AppSettings.KEY_EPUB_RTL) { isEpubRtl }.observe(this) {
            if (readerManager.isEpub) viewBinding.actionsView.setSliderReversed(it)
        }
        viewModel.onPageSaved.observeEvent(this, PagesSavedObserver(viewBinding.container))
        viewModel.onPageReadyToShare.observeEvent(this) { ShareHelper(this).shareImage(it) }
        viewModel.uiState.zipWithPrevious().observe(this, this::onUiStateChanged)
        combine(
            viewModel.isLoading,
            viewModel.content.map { it.pages.isNotEmpty() }.distinctUntilChanged(),
            ::Pair,
        ).flowOn(Dispatchers.Default)
            .observe(this, this::onLoadingStateChanged)
        viewModel.isKeepScreenOnEnabled.observe(this, this::setKeepScreenOn)
        viewModel.isInfoBarEnabled.observe(this, ::onReaderBarChanged)
        viewModel.isBookmarkAdded.observe(this, MenuInvalidator(this))
        viewModel.onAskNsfwIncognito.observeEvent(this) { askForIncognitoMode() }
        viewModel.onShowToast.observeEvent(this) { msgId ->
            Snackbar.make(viewBinding.container, msgId, Snackbar.LENGTH_SHORT)
                .setAnchorView(viewBinding.toolbarDocked)
                .show()
        }
        viewModel.readerSettingsProducer.observe(this) {
            viewBinding.infoBar.applyColorScheme(isBlackOnWhite = it.background.isLight(this))
        }
        viewModel.isZoomControlsEnabled.observe(this) {
            viewBinding.zoomControl.isVisible = it
        }
        addMenuProvider(
            ReaderMenuProvider(
                onBookmark = ::onBookmarkClick,
                isBookmarkAdded = { viewModel.isBookmarkAdded.value == true },
                onSearchBook = ::openEpubSearch,
                onShowUpscalePreview = ::showUpscalePreview,
                isEpub = { readerManager.isEpub },
                isUpscaleActive = { UpscaleEffect.activePages.value.isNotEmpty() },
                isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE,
                canOpenWeb = { viewModel.getSourceMangaOrNull()?.isLocal == false },
                onOpenWeb = { viewModel.getCurrentState()?.chapterId?.let { viewModel.openChapterInBrowser(it) } },
                onOpenExternal = { viewModel.getCurrentState()?.chapterId?.let { viewModel.openChapterInBrowser(it, external = true) } },
            ),
        )
        UpscaleEffect.activePages.map { it.isNotEmpty() }.distinctUntilChanged()
            .observe(this, MenuInvalidator(this))
        viewModel.onOpenChapterInBrowser.observeEvent(this) { url ->
            val manga = viewModel.getMangaOrNull()
            router.openBrowser(url = url, source = manga?.source, title = manga?.title)
        }
        viewModel.onOpenChapterExternally.observeEvent(this) { url ->
            val manga = viewModel.getMangaOrNull()
            router.openBrowserExternally(url = url, source = manga?.source, title = manga?.title)
        }

        observeWindowLayout()
        if (settings.isEyeReminderEnabled) setupEyeReminder()
        setupNovelChrome()
        setupQuickSettingsOverlay()

        // Apply initial double-mode considering foldable setting
        applyDoubleModeAuto()
    }

    /**
     * Novels get Novery's look: a Compose top bar, floating Chapters/Listen/Settings bar and inline
     * settings panel. The XML toolbar and dock stay in the layout (so insets and show/hide logic keep
     * working) but are made invisible and untouchable while a novel is open.
     */
    private fun setupNovelChrome() {
        novelChrome.onBack = { onBackPressedDispatcher.onBackPressed() }
        novelChrome.onHighlightClick = ::onBookmarkClick
        novelChrome.canOpenWeb = { viewModel.getSourceMangaOrNull()?.isLocal == false }
        novelChrome.onWebClick = {
            viewModel.getCurrentState()?.chapterId?.let { viewModel.openChapterInBrowser(it) }
        }
        // Holding the web button, or its sibling, opens the page in the phone's browser
        novelChrome.onWebLongClick = {
            viewModel.getCurrentState()?.chapterId?.let { viewModel.openChapterInBrowser(it, external = true) }
        }
        novelChrome.onChaptersClick = { router.showChapterPagesSheet() }
        novelChrome.onRotateClick = ::toggleScreenOrientation
        novelChrome.isRotationLocked = { screenOrientationHelper.isLocked }
        novelChrome.onPrevChapter = { (readerManager.currentReader as? EpubReaderFragment)?.skipChapter(-1) }
        novelChrome.onNextChapter = { (readerManager.currentReader as? EpubReaderFragment)?.skipChapter(1) }
        novelChrome.onSeekChapter = { permille -> (readerManager.currentReader as? EpubReaderFragment)?.seekChapterPermille(permille) }
        novelChrome.onListenClick = ::onTextToSpeechClick
        novelChrome.onSearchClick = ::openEpubSearch
        novelChrome.onAutoScrollClick = { onScrollTimerClick(isLongClick = true) }
        novelChrome.onTtsClose = ::closeNovelTts
        novelChrome.onTtsChapter = { delta -> (readerManager.currentReader as? EpubReaderFragment)?.ttsSkipChapter(delta) }
        val overlay = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            translationZ = 32 * resources.displayMetrics.density // above the XML bars
            setContent {
                DropSauceTheme {
                    NovelReaderChrome(novelChrome, settings, tts)
                }
            }
        }
        viewBinding.root.addView(
            overlay,
            CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        viewModel.epubChapterProgress.observe(this) { (permille, minutes) ->
            novelChrome.progressPermille = permille
            novelChrome.minutesLeft = minutes
        }
    }

    private fun setupQuickSettingsOverlay() {
        val overlay = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            translationZ = 32 * resources.displayMetrics.density // above the XML bars
            // Swallow every touch that lands on the panel so nothing reaches the pages behind it
            isClickable = true
            setContent {
                DropSauceTheme {
                    MangaQuickSettings(
                        visible = quickSettingsVisible,
                        mode = quickSettingsMode,
                        settings = settings,
                        viewModel = viewModel,
                        orientationHelper = screenOrientationHelper,
                        callback = this@ReaderActivity,
                        router = this@ReaderActivity.router,
                        onDismiss = { updateQuickSettingsVisibility(false) },
                    )
                }
            }
        }
        viewBinding.root.addView(
            overlay,
            CoordinatorLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { gravity = Gravity.BOTTOM },
        )
        quickSettingsOverlay = overlay
        onBackPressedDispatcher.addCallback(this, quickSettingsBackCallback)
        // The panel sits right above the dock, so follow it when it moves (rotation, insets)
        viewBinding.toolbarDocked?.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (quickSettingsVisible) updateQuickSettingsPosition()
        }
    }

    private fun updateQuickSettingsVisibility(visible: Boolean) {
        if (quickSettingsVisible == visible) return
        if (visible) {
            quickSettingsMode = readerManager.currentMode ?: return
            viewModel.saveCurrentState(readerManager.currentReader?.getCurrentState())
            updateQuickSettingsPosition()
        }
        quickSettingsVisible = visible
        quickSettingsBackCallback.isEnabled = visible
        viewBinding.actionsView.isSettingsOpen = visible
    }

    /** Puts the panel just above the bottom bar, with the same side margins as the bar. */
    private fun updateQuickSettingsPosition() {
        val overlay = quickSettingsOverlay ?: return
        val gap = resources.getDimensionPixelSize(R.dimen.margin_small)
        val dock = viewBinding.toolbarDocked
        overlay.updateLayoutParams<CoordinatorLayout.LayoutParams> {
            if (dock != null) {
                val dockParams = dock.layoutParams as ViewGroup.MarginLayoutParams
                bottomMargin = viewBinding.root.height - dock.top + gap
                leftMargin = dockParams.leftMargin
                rightMargin = dockParams.rightMargin
            } else {
                // Wide layouts keep the bar in the top bar: the panel just rests at the bottom
                val margin = resources.getDimensionPixelSize(R.dimen.screen_padding)
                val navBar = ViewCompat.getRootWindowInsets(viewBinding.root)
                    ?.getInsets(WindowInsetsCompat.Type.navigationBars())?.bottom ?: 0
                bottomMargin = margin + navBar
                leftMargin = margin
                rightMargin = margin
            }
        }
    }

    /** Stops listening and takes the Listen player down. */
    private fun closeNovelTts() {
        tts.stop()
        ReaderTtsService.stop(this)
        novelChrome.ttsOpen = false
        (readerManager.currentReader as? EpubReaderFragment)?.setTtsPickMode(false)
        updateScrollTimerButton()
    }

    private fun applyNovelChrome(isEpub: Boolean) {
        novelChrome.active = isEpub
        if (isEpub) novelChrome.visible = viewBinding.appbarTop.isVisible
        viewBinding.toolbar.isInvisible = isEpub
        viewBinding.actionsView.isInvisible = isEpub
        viewBinding.appbarTop.alpha = if (isEpub) 0f else 1f
        viewBinding.toolbarDocked?.alpha = if (isEpub) 0f else 1f
    }

    private fun setupEyeReminder() {
        val overlay = ComposeView(this).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            translationZ = 64 * resources.displayMetrics.density // above the app bars
            setContent {
                DropSauceTheme {
                    val visible by viewModel.isEyeReminderVisible.collectAsState()
                    EyeReminderOverlay(
                        visible = visible,
                        intervalSeconds = settings.eyeReminderIntervalSeconds,
                        onDismiss = ::dismissEyeReminder,
                    )
                }
            }
        }
        viewBinding.root.addView(
            overlay,
            CoordinatorLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT),
        )
        // Counts only while the reader is on screen; the clock starts again after each dismiss.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                val interval = settings.eyeReminderIntervalSeconds
                EyeReminderClock.onReaderShown()
                try {
                    while (true) {
                        viewModel.isEyeReminderVisible.first { !it }
                        val start = SystemClock.elapsedRealtime()
                        try {
                            delay(interval * 1000L - EyeReminderClock.readMs)
                        } finally {
                            EyeReminderClock.readMs += SystemClock.elapsedRealtime() - start
                        }
                        EyeReminderClock.readMs = 0
                        isScrollPausedByEyeReminder = scrollTimer.isActive.value
                        isTtsPausedByEyeReminder = tts.isPlaying.value
                        scrollTimer.setActive(false)
                        tts.pause()
                        viewModel.isEyeReminderVisible.value = true
                    }
                } finally {
                    EyeReminderClock.onReaderHidden()
                }
            }
        }
    }

    private fun dismissEyeReminder() {
        viewModel.isEyeReminderVisible.value = false
        if (isScrollPausedByEyeReminder) scrollTimer.setActive(true)
        if (isTtsPausedByEyeReminder) tts.play()
        isScrollPausedByEyeReminder = false
        isTtsPausedByEyeReminder = false
    }

    override fun getParentActivityIntent(): Intent? {
        val manga = viewModel.getMangaOrNull() ?: return null
        return AppRouter.detailsIntent(this, manga)
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (!viewBinding.timerControl.isVisible) {
            scrollTimer.onUserInteraction()
        }
        idlingDetector.onUserInteraction()
    }

    override fun onPause() {
        super.onPause()
        viewModel.onPause()
    }

    override fun onStop() {
        super.onStop()
        viewModel.onStop()
    }

    override fun onDestroy() {
        // Backgrounding the reader keeps speaking; leaving it does not. A rotation is neither.
        if (isFinishing) {
            tts.stop()
            ReaderTtsService.stop(this)
        }
        super.onDestroy()
    }

    override fun onProvideAssistContent(outContent: AssistContent) {
        super.onProvideAssistContent(outContent)
        viewModel.getMangaOrNull()?.publicUrl?.toUriOrNull()?.let { outContent.webUri = it }
    }

    override fun isNsfwContent(): Flow<Boolean> = viewModel.isMangaNsfw

    override fun onIdle() {
        viewModel.saveCurrentState(readerManager.currentReader?.getCurrentState())
        viewModel.onIdle()
    }

    override fun onVisibilityChanged(v: View, visibility: Int) {
        // Set the offset before the panel's own slide captures its end value, so it slides in at
        // the right height instead of appearing at the bottom edge and jumping up afterwards.
        updateTimerPanelOffset(animate = false)
        updateScrollTimerButton()
        (readerManager.currentReader as? EpubReaderFragment)?.setTtsPickMode(novelChrome.ttsOpen)
    }

    override fun onZoomIn() {
        readerManager.currentReader?.onZoomIn()
    }

    override fun onZoomOut() {
        readerManager.currentReader?.onZoomOut()
    }

    override fun onClick(v: View) {
        when (v.id) {
            // One floating button for both: whichever of the two is running owns it.
            R.id.button_timer_fab -> if (isTtsFab()) {
                onTextToSpeechClick()
            } else {
                onScrollTimerClick(isLongClick = false)
            }
        }
    }

    private fun onInitReader(mode: ReaderMode?) {
        if (mode == null) {
            return
        }
        readerManager.isEpub = viewModel.getMangaOrNull()?.isEpub == true
        applyNovelChrome(readerManager.isEpub)
        viewBinding.timerControl.setEpubReader(readerManager.isEpub)
        updateScrollTimerButton()
        if (readerManager.currentMode != mode) {
            readerManager.replace(mode)
        }
        invalidateOptionsMenu()
        if (viewBinding.appbarTop.isVisible) {
            lifecycle.postDelayed(TimeUnit.SECONDS.toMillis(1), hideUiRunnable)
        }
        viewBinding.actionsView.setSliderReversed(
            if (readerManager.isEpub) settings.isEpubRtl else mode == ReaderMode.REVERSED,
        )
        viewBinding.timerControl.onReaderModeChanged(mode)
    }

    private fun onLoadingStateChanged(value: Pair<Boolean, Boolean>) {
        val (isLoading, hasPages) = value
        val showLoadingLayout = isLoading && !hasPages
        if (viewBinding.layoutLoading.isVisible != showLoadingLayout) {
            val transition = Fade().addTarget(viewBinding.layoutLoading)
            TransitionManager.beginDelayedTransition(viewBinding.root, transition)
            viewBinding.layoutLoading.isVisible = showLoadingLayout
        }
        if (isLoading && hasPages) {
            viewBinding.toastView.show(R.string.loading_)
        } else if (viewModel.isHighlightPicking.value) {
            viewBinding.toastView.show(R.string.tap_sentence_to_highlight)
        } else {
            viewBinding.toastView.hide()
        }
        invalidateOptionsMenu()
    }

    override fun onGridTouch(area: TapGridArea, horizontalFraction: Float): Boolean {
        if (!isReaderResumed()) return false
        return if (readerManager.isEpub) {
            if (settings.isEpubPagedTapGesturesEnabled && settings.epubReadingMode != EPUB_MODE_SCROLL) {
                // RTL pages advance leftwards, so the side zones swap.
                val forward = if (settings.isEpubRtl) -1 else 1
                when {
                    horizontalFraction < 1f / 3f -> switchPageBy(-forward)
                    horizontalFraction > 2f / 3f -> switchPageBy(forward)
                    else -> toggleUiVisibility()
                }
            } else {
                toggleUiVisibility()
            }
            true
        } else {
            controlDelegate.onGridTouch(area)
        }
    }

    override fun onGridLongTouch(area: TapGridArea): Boolean {
        val handled = !readerManager.isEpub && isReaderResumed() && controlDelegate.onGridLongTouch(area)
        // The finger is still down when the long-press action fires (e.g. the config sheet opens),
        // and the ongoing gesture keeps feeding the pager underneath — any drift after the
        // long-press scrolls the page abruptly. Cancel the rest of this gesture for the content.
        if (handled) {
            isTouchCancelled = true
        }
        return handled
    }

    override fun onProcessTouch(rawX: Int, rawY: Int): Boolean {
        return if (
            rawX <= gestureInsets.left ||
            rawY <= gestureInsets.top ||
            rawX >= viewBinding.root.width - gestureInsets.right ||
            rawY >= viewBinding.root.height - gestureInsets.bottom ||
            viewBinding.appbarTop.hasGlobalPoint(rawX, rawY) ||
            viewBinding.toolbarDocked?.hasGlobalPoint(rawX, rawY) == true ||
            (quickSettingsVisible && quickSettingsOverlay?.hasGlobalPoint(rawX, rawY) == true) ||
            novelChrome.isOnChrome(rawX, rawY)
        ) {
            false
        } else {
            val touchables = window.peekDecorView()?.touchables
            touchables?.none {
                it.hasGlobalPoint(rawX, rawY) && it.getTag(R.id.tag_epub_selectable_text) != true
            } != false
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (viewModel.isEyeReminderVisible.value) return super.dispatchTouchEvent(ev)
        touchHelper.dispatchTouchEvent(ev)
        if (!viewBinding.timerControl.hasGlobalPoint(ev.rawX.toInt(), ev.rawY.toInt())) {
            scrollTimer.onTouchEvent(ev)
        }
        if (isTouchCancelled) {
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                isTouchCancelled = false
            }
            val cancel = MotionEvent.obtain(ev)
            cancel.action = MotionEvent.ACTION_CANCEL
            val result = super.dispatchTouchEvent(cancel)
            cancel.recycle()
            return result
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (viewModel.isEyeReminderVisible.value) return super.onKeyDown(keyCode, event)
        return controlDelegate.onKeyDown(keyCode, event) || super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        return controlDelegate.onKeyUp(keyCode, event) || super.onKeyUp(keyCode, event)
    }

    override fun onChapterSelected(chapter: MangaChapter): Boolean {
        jumpToChapter(chapter.id, page = 0, scroll = 0, isPeekPreferred = false)
        return true
    }

    override fun onBookmarkSelected(bookmark: Bookmark): Boolean {
        return if (bookmark.epubHighlight != null) {
            // epub highlights keep the exact character offset in `page`; scroll is only a coarse permille
            jumpToChapter(
                bookmark.chapterId,
                page = ReaderState.EPUB_PAGE_CENTERED,
                scroll = ReaderState.encodeEpubOffset(bookmark.page),
                isPeekPreferred = true,
            )
            true
        } else {
            onPageSelectedImpl(ReaderPage(bookmark.toMangaPage(), bookmark.page, bookmark.chapterId), isPeekPreferred = true)
        }
    }

    override fun onPageSelected(page: ReaderPage): Boolean = onPageSelectedImpl(page, isPeekPreferred = false)

    private fun onPageSelectedImpl(page: ReaderPage, isPeekPreferred: Boolean): Boolean {
        lifecycleScope.launch(Dispatchers.Default) {
            val pages = viewModel.content.value.pages
            val index = pages.indexOfFirst { it.chapterId == page.chapterId && it.id == page.id }
            if (index != -1) {
                withContext(Dispatchers.Main) {
                    readerManager.currentReader?.switchPageTo(index, true)
                }
            } else withContext(Dispatchers.Main) {
                jumpToChapter(page.chapterId, page.index, scroll = 0, isPeekPreferred = isPeekPreferred)
            }
        }
        return true
    }

    /**
     * Routes an explicit chapter jump through the progress guard: normal continuation switches
     * as usual, jumps away from the saved progress either peek (keeping history untouched) or
     * ask the user. [isPeekPreferred] (bookmarks) resolves ambiguous jumps to a silent peek.
     */
    private fun jumpToChapter(chapterId: Long, page: Int, scroll: Int, isPeekPreferred: Boolean) {
        lifecycleScope.launch {
            when (viewModel.getChapterOpenMode(chapterId)) {
                ChaptersPagesViewModel.ChapterOpenMode.NORMAL -> {
                    viewModel.setPeekMode(false)
                    viewModel.switchChapter(chapterId, page, scroll)
                }

                ChaptersPagesViewModel.ChapterOpenMode.ASK -> if (isPeekPreferred) {
                    viewModel.setPeekMode(true)
                    viewModel.switchChapter(chapterId, page, scroll)
                } else {
                    showChapterJumpDialog(
                        activity = this@ReaderActivity,
                        onPeek = {
                            viewModel.setPeekMode(true)
                            viewModel.switchChapter(chapterId, page, scroll)
                        },
                        onMoveProgress = {
                            viewModel.setPeekMode(false)
                            viewModel.switchChapter(chapterId, page, scroll)
                        },
                        onDisable = { viewModel.disableChapterJumpDialog() },
                    )
                }
            }
        }
    }

    override fun onReaderModeChanged(mode: ReaderMode) {
        viewModel.saveCurrentState(readerManager.currentReader?.getCurrentState())
        viewModel.switchMode(mode)
        viewBinding.timerControl.onReaderModeChanged(mode)
    }

    override fun onDoubleModeChanged(isEnabled: Boolean) {
        // Combine manual toggle with foldable auto setting
        applyDoubleModeAuto(isEnabled)
    }

    private fun applyDoubleModeAuto(manualEnabled: Boolean? = null) {
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        // Auto double-page on foldable when device is unfolded (half-opened or flat)
        val autoFoldable = settings.isReaderDoubleOnFoldable && isFoldUnfolded
        val manualLandscape = (manualEnabled ?: settings.isReaderDoubleOnLandscape) && isLandscape
        val autoEnabled = autoFoldable || manualLandscape
        readerManager.setDoubleReaderMode(autoEnabled)
    }

    private fun setKeepScreenOn(isKeep: Boolean) {
        if (isKeep) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // Keep the top bar translucent while the bottom floating toolbar stays opaque.
    private fun applyTranslucentReaderBars() {
        viewBinding.appbarTop.setBackgroundColor(getThemeColor(materialR.attr.colorSurface, TOP_READER_BAR_ALPHA))
        viewBinding.toolbar.background = null
        viewBinding.toolbarDocked?.background = viewBinding.toolbarDocked?.background?.mutate()?.apply {
            alpha = 0xFF
        }
    }

    private fun setUiIsVisible(isUiVisible: Boolean) {
        novelChrome.visible = isUiVisible
        if (!isUiVisible) updateQuickSettingsVisibility(false)
        if (viewBinding.appbarTop.isVisible != isUiVisible) {
            var isAnimated = false
            if (isAnimationsEnabled) {
                val transition = TransitionSet()
                    .setOrdering(TransitionSet.ORDERING_TOGETHER)
                    .addTransition(Slide(Gravity.TOP).addTarget(viewBinding.appbarTop))
                    .addTransition(Fade().addTarget(viewBinding.infoBar))
                viewBinding.toolbarDocked?.let {
                    transition.addTransition(Slide(Gravity.BOTTOM).addTarget(it))
                }
                // Re-dispatching insets changes the reader's own padding and the toolbar margins,
                // which forces a full re-layout of the page view *while* the bars are sliding —
                // that is the stutter. Hold it back until the slide is done.
                transition.addListener(object : TransitionListenerAdapter() {
                    override fun onTransitionEnd(transition: Transition) {
                        viewBinding.root.requestApplyInsets()
                    }
                })
                TransitionManager.beginDelayedTransition(viewBinding.root, transition)
                isAnimated = true
            }
            val isFullscreen = settings.isReaderFullscreenEnabled
            viewBinding.appbarTop.isVisible = isUiVisible
            viewBinding.toolbarDocked?.isVisible = isUiVisible
            viewBinding.infoBar.isGone = isUiVisible || (!viewModel.isInfoBarEnabled.value)
            viewBinding.infoBar.isTimeVisible = isFullscreen
            updateScrollTimerButton()
            updateTimerPanelOffset(animate = isAnimated)
            systemUiController.setSystemUiVisible(isUiVisible || !isFullscreen)
            if (!isAnimated) {
                viewBinding.root.requestApplyInsets()
            }
        }
    }

    override fun onApplyWindowInsets(v: View, insets: WindowInsetsCompat): WindowInsetsCompat {
        gestureInsets = insets.getInsets(WindowInsetsCompat.Type.systemGestures())
        val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        val tappableInsets = insets.getInsets(WindowInsetsCompat.Type.tappableElement())
        novelChrome.topInset = (systemBars.top / resources.displayMetrics.density).dp
        novelChrome.bottomInset = (maxOf(systemBars.bottom, tappableInsets.bottom) / resources.displayMetrics.density).dp
        viewBinding.toolbar.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            topMargin = systemBars.top
            rightMargin = systemBars.right
            leftMargin = systemBars.left
        }
        viewBinding.toolbarDocked?.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            val dockedMargin = resources.getDimensionPixelSize(R.dimen.screen_padding)
            bottomMargin = tappableInsets.bottom + dockedMargin
            rightMargin = systemBars.right + dockedMargin
            leftMargin = systemBars.left + dockedMargin
        } ?: viewBinding.actionsView.updateLayoutParams<ViewGroup.MarginLayoutParams> {
            bottomMargin = tappableInsets.bottom
            rightMargin = systemBars.right
            leftMargin = systemBars.left
        }
        viewBinding.toolbarDocked?.let { docked ->
            dockedToolbarHeight = maxOf(dockedToolbarHeight, docked.height)
            val panelMargin = tappableInsets.bottom + resources.getDimensionPixelSize(R.dimen.screen_padding)
            viewBinding.timerControl.updateLayoutParams<ViewGroup.MarginLayoutParams> {
                if (bottomMargin != panelMargin) {
                    bottomMargin = panelMargin
                }
            }
            updateTimerPanelOffset(animate = false)
        }
        // The info bar must hug the real top edge: BaseActivity inflates the top inset with the
        // hidden status bar's height (so toolbars keep their place), but this bar replaces the
        // status bar, so pad it with the actual visible inset only.
        viewBinding.infoBar.updatePadding(
            top = ViewCompat.getRootWindowInsets(v)
                ?.getInsets(WindowInsetsCompat.Type.systemBars())?.top
                ?: systemBars.top,
        )
        val innerInsets = Insets.of(
            systemBars.left,
            if (viewBinding.appbarTop.isVisible) viewBinding.appbarTop.height else systemBars.top,
            systemBars.right,
            viewBinding.toolbarDocked?.takeIf { it.isVisible }?.height ?: systemBars.bottom,
        )
        return WindowInsetsCompat.Builder(insets)
            .setInsets(WindowInsetsCompat.Type.systemBars(), innerInsets)
            .build()
    }

    override fun switchPageBy(delta: Int) {
        readerManager.currentReader?.switchPageBy(delta)
    }

    override fun switchChapterBy(delta: Int) {
        viewModel.switchChapterBy(delta)
    }

    override fun openMenu() {
        if (readerManager.isEpub) {
            novelChrome.ttsOpen = false
            novelChrome.visible = true
            novelChrome.openSettingsTick++
            return
        }
        if (readerManager.currentMode == null) return
        // The Settings button of the bar is a toggle: a second tap closes the panel
        if (quickSettingsVisible) {
            updateQuickSettingsVisibility(false)
            return
        }
        // The panel opens above the bar, so the bar has to be on screen (and laid out) first
        if (!viewBinding.appbarTop.isVisible) setUiIsVisible(true)
        viewBinding.root.post { updateQuickSettingsVisibility(true) }
    }

    override fun scrollBy(delta: Int, smooth: Boolean): Boolean {
        return readerManager.currentReader?.scrollBy(delta, smooth) == true
    }

    override fun toggleUiVisibility() {
        setUiIsVisible(!viewBinding.appbarTop.isVisible)
    }

    override fun isReaderResumed(): Boolean {
        val reader = readerManager.currentReader ?: return false
        return reader.isResumed && supportFragmentManager.fragments.lastOrNull() === reader
    }

    override fun onBookmarkClick() {
        // Novels have no pages to bookmark: the button arms highlight pick mode instead.
        if (readerManager.isEpub) {
            viewModel.isHighlightPicking.value = !viewModel.isHighlightPicking.value
            return
        }
        // Only buzz when adding a bookmark (not when removing one).
        if (viewModel.isBookmarkAdded.value != true) {
            viewBinding.actionsView.hapticFeedback(HapticEffect.CONFIRM)
        }
        viewModel.toggleBookmark()
    }

    override fun onSavePageClick() {
        viewModel.saveCurrentPage(pageSaveHelper)
    }

    override fun onSharePageClick() {
        viewModel.shareCurrentPage(pageSaveHelper)
    }

    override fun onScrollTimerClick(isLongClick: Boolean) {
        viewBinding.ttsControl.hide()
        novelChrome.ttsOpen = false
        (readerManager.currentReader as? EpubReaderFragment)?.setTtsPickMode(false)
        if (isLongClick) {
            scrollTimer.setActive(!scrollTimer.isActive.value)
        } else {
            viewBinding.timerControl.showOrHide()
        }
    }

    override fun onTextToSpeechClick() {
        val reader = readerManager.currentReader as? EpubReaderFragment ?: return
        viewBinding.timerControl.hide()
        novelChrome.ttsOpen = true
        reader.setTtsPickMode(true)
        updateScrollTimerButton()
        if (!tts.isAttached) {
            reader.startTts()
        }
    }

	private fun openEpubSearch() {
		(readerManager.currentReader as? EpubReaderFragment)?.showBookSearch()
	}

	private fun showUpscalePreview() {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
			UpscalePreviewDialog.show(supportFragmentManager)
		}
	}

    override fun toggleScreenOrientation() {
        if (screenOrientationHelper.toggleScreenOrientation()) {
            Snackbar.make(
                viewBinding.container,
                if (screenOrientationHelper.isLocked) {
                    R.string.screen_rotation_locked
                } else {
                    R.string.screen_rotation_unlocked
                },
                Snackbar.LENGTH_SHORT,
            ).setAnchorView(viewBinding.toolbarDocked)
                .show()
        }
    }

    override fun switchPageTo(index: Int) {
        if (readerManager.isEpub) {
            // slider scrubs through the chapter as a percentage
            readerManager.currentReader?.switchPageTo(index, true)
            return
        }
        onPageSelected(getPageAt(index) ?: return)
    }

    override fun getPageAt(index: Int): ReaderPage? {
        // EPUB chapters are one scrolling document - there are no per-page images to resolve.
        if (readerManager.isEpub) {
            return null
        }
        val page = viewModel.getCurrentChapterPages()?.getOrNull(index) ?: return null
        val chapterId = viewModel.getCurrentState()?.chapterId ?: return null
        return ReaderPage(page, index, chapterId)
    }

    private fun onReaderBarChanged(isBarEnabled: Boolean) {
        viewBinding.infoBar.isVisible = isBarEnabled && viewBinding.appbarTop.isGone
    }

    private fun onUiStateChanged(pair: Pair<ReaderUiState?, ReaderUiState?>) {
        val (previous: ReaderUiState?, uiState: ReaderUiState?) = pair
        title = uiState?.mangaName ?: getString(R.string.loading_)
        viewBinding.infoBar.update(uiState)
        if (uiState == null) {
            supportActionBar?.subtitle = null
            viewBinding.actionsView.setSliderValue(0, 1)
            viewBinding.actionsView.isSliderEnabled = false
            viewBinding.actionsView.isScrubPreviewEnabled = false
            return
        }
        viewBinding.actionsView.isSliderSmooth = uiState.isEpub && !uiState.isEpubPaged
        viewBinding.actionsView.isHighlightMode = uiState.isEpub
        // Only trade Material's value label for the thumbnail when the pages are really resolvable;
        // otherwise the scrub would show neither.
        viewBinding.actionsView.isScrubPreviewEnabled = uiState.isSliderAvailable() &&
            getPageAt(uiState.currentPage) != null
        val chapterTitle = uiState.getChapterTitle(resources)
        novelChrome.chapterTitle = chapterTitle
        novelChrome.chapterNumber = uiState.chapterNumber
        novelChrome.totalChapters = uiState.chaptersTotal
        supportActionBar?.subtitle = when {
            uiState.incognito -> getString(R.string.incognito_mode)
            uiState.isPeek -> getString(R.string.peek_mode)
            else -> chapterTitle
        }
        if (
            chapterTitle != previous?.getChapterTitle(resources) &&
            chapterTitle.isNotEmpty()
        ) {
            viewBinding.toastView.showTemporary(chapterTitle, TOAST_DURATION)
        }
        if (uiState.isSliderAvailable()) {
            viewBinding.actionsView.setSliderValue(
                value = uiState.currentPage,
                max = uiState.totalPages - 1,
            )
        } else {
            viewBinding.actionsView.setSliderValue(0, 1)
        }
        viewBinding.actionsView.isSliderEnabled = uiState.isSliderAvailable()
        viewBinding.actionsView.isNextEnabled = uiState.hasNextChapter()
        viewBinding.actionsView.isPrevEnabled = uiState.hasPreviousChapter()
    }

    /**
     * Keeps the autoscroll panel just above the docked toolbar. CoordinatorLayout's
     * `dodgeInsetEdges` used to do this, but dodging is resolved in a single layout pass — it
     * teleported the panel instead of animating it. Driving translationY ourselves lets it glide
     * in step with the toolbar's slide.
     */
    private fun updateTimerPanelOffset(animate: Boolean) {
        // Tablet layouts anchor the panel to the top app bar, so there is nothing to dodge.
        if (viewBinding.toolbarDocked == null) return
        // The floating button rides along: with the dock up it would otherwise sit behind it.
        val panels = listOfNotNull<View>(viewBinding.timerControl, viewBinding.ttsControl, viewBinding.buttonTimerFab)
        // Hiding the system bars makes insets settle over several frames, and every one of those
        // callbacks lands here. Without this guard they snap translationY straight to the target
        // mid-flight, so the panel appears to jump while the toolbar is still sliding.
        if (!animate && isPanelOffsetAnimating) return
        val target = if (viewBinding.appbarTop.isVisible) {
            -(dockedToolbarHeight + resources.getDimensionPixelSize(R.dimen.screen_padding)).toFloat()
        } else {
            0f
        }
        panels.forEach { it.animate().cancel() }
        if (animate && isAnimationsEnabled) {
            isPanelOffsetAnimating = true
            panels.forEach { panel ->
                panel.animate()
                    .translationY(target)
                    .setDuration(PANEL_SLIDE_DURATION)
                    // same curve the toolbar's Slide uses, so the two travel as one
                    .setInterpolator(AccelerateDecelerateInterpolator())
                    .withEndAction { isPanelOffsetAnimating = false }
                    .start()
            }
        } else {
            isPanelOffsetAnimating = false
            panels.forEach { it.translationY = target }
        }
    }

    private fun updateScrollTimerButton() {
        val button = viewBinding.buttonTimerFab ?: return
        val isTts = isTtsFab()
        val isButtonVisible = (scrollTimer.isActive.value || isTts)
            && settings.isReaderAutoscrollFabVisible
            && !viewBinding.timerControl.isVisible
            && !viewBinding.ttsControl.isVisible
        button.setIconResource(if (isTts) R.drawable.ic_voice_over else R.drawable.ic_timelapse)
        // Compare against where the button is heading, not isVisible: mid fade-out it is still
        // visible, so a "show" arriving then was dropped and the fade finished hiding it for good.
        if (isTimerFabShown == isButtonVisible) {
            return
        }
        isTimerFabShown = isButtonVisible
        // Nothing to fade before the view is attached: ViewPropertyAnimator would never run its
        // end action, leaving the button stuck at whatever the layout started it as.
        if (!isAnimationsEnabled || !button.isAttachedToWindow) {
            button.animate().cancel()
            button.alpha = 1f
            button.isVisible = isButtonVisible
            return
        }
        // Fade the FAB with its own animator instead of staging another delayed transition:
        // this runs from inside the panel-slide and toolbar-slide code paths, and a second
        // beginDelayedTransition() on the same scene root cancels the one the caller just
        // queued — which is what made the bottom area flash instead of animating.
        button.animate().cancel()
        if (isButtonVisible) {
            if (!button.isVisible) button.alpha = 0f
            button.isVisible = true
            button.animate().alpha(1f).setDuration(FAB_FADE_DURATION).start()
        } else {
            button.animate().alpha(0f).setDuration(FAB_FADE_DURATION).withEndAction {
                button.isVisible = false
                button.alpha = 1f
            }.start()
        }
    }

    /**
     * The TTS face of the FAB is sticky: once speech has been started it stays for the whole session
     * (paused, between chapters) and on every novel until it is explicitly stopped.
     */
    private fun isTtsFab() = false // novels have the Compose Listen player instead of the floating TTS button

    // Observe foldable window layout to auto-enable double-page if configured
    private fun observeWindowLayout() {
        WindowInfoTracker.getOrCreate(this)
            .windowLayoutInfo(this)
            .onEach { info ->
                val fold = info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull()
                val unfolded = when (fold?.state) {
                    FoldingFeature.State.HALF_OPENED, FoldingFeature.State.FLAT -> true
                    else -> false
                }
                if (unfolded != isFoldUnfolded) {
                    isFoldUnfolded = unfolded
                    applyDoubleModeAuto()
                }
            }
            .launchIn(lifecycleScope)
    }

    private fun askForIncognitoMode() {
        showIncognitoModeDialog(
            activity = this,
            onResult = { incognito, dontAskAgain -> viewModel.setIncognitoMode(incognito, dontAskAgain) },
            onCancel = { finishAfterTransition() },
        )
    }

    companion object {

        private const val TOAST_DURATION = 2000L
        private const val FAB_FADE_DURATION = 200L
        // matches androidx.transition's default duration, so the panel and the toolbar move together
        private const val PANEL_SLIDE_DURATION = 300L
		private const val EPUB_MODE_SCROLL = "scroll"

        private const val TOP_READER_BAR_ALPHA = 0.7f
    }
}
