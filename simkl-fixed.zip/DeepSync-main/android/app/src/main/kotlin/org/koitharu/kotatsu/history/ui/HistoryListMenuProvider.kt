package org.koitharu.kotatsu.history.ui

import android.content.Context
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.core.view.MenuProvider
import org.koitharu.kotatsu.R
import org.koitharu.kotatsu.core.nav.AppRouter
import org.koitharu.kotatsu.core.ui.dialog.showSingleChoiceDialog
import org.koitharu.kotatsu.home.ui.model.HomeMode
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

class HistoryListMenuProvider(
	private val context: Context,
	private val router: AppRouter,
	private val viewModel: HistoryListViewModel,
) : MenuProvider {

	override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
		menuInflater.inflate(R.menu.opt_history, menu)
	}

	override fun onPrepareMenu(menu: Menu) {
		super.onPrepareMenu(menu)
		menu.findItem(R.id.action_stats)?.apply {
			isVisible = viewModel.isStatsAvailableForMode
			setTitle(
				if (viewModel.statsMode == HomeMode.ANIME) R.string.watching_stats else R.string.reading_stats,
			)
		}
	}

	override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
		return when (menuItem.itemId) {
			R.id.action_clear_history -> {
				showClearHistoryDialog()
				true
			}

			R.id.action_stats -> {
				router.openStatistic(viewModel.statsMode)
				true
			}

			else -> false
		}
	}

	private fun showClearHistoryDialog() {
		showSingleChoiceDialog(
			context = context,
			icon = R.drawable.ic_delete_all,
			title = context.getString(R.string.clear_history),
			options = listOf(
				context.getString(R.string.last_2_hours),
				context.getString(R.string.today),
				context.getString(R.string.not_in_favorites),
				context.getString(R.string.clear_all_history),
			),
			selectedIndex = 1,
			confirmLabel = context.getString(R.string.clear),
			destructive = true,
		) { selection ->
			when (selection) {
				0 -> viewModel.clearHistory(Instant.now().minus(2, ChronoUnit.HOURS))
				1 -> viewModel.clearHistory(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant())
				2 -> viewModel.removeNotFavorite()
				3 -> viewModel.clearHistory(null)
			}
		}
	}
}
